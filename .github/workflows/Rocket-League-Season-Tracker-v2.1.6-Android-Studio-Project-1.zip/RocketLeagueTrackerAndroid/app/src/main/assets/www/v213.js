'use strict';
/* Rocket League Season Tracker v2.1.2: Turbo Hunt, verified storage,
   appearance consistency, dedicated season accounting, cinematic reveals. */
const RL213_HUNT_META='__hunt_meta_v212';
let rl213Run=null,rl213StatsCache=null,rl213LastConfirmed=0;
const rl213BaseInvalidate=rl211Invalidate;
rl211Invalidate=function(){rl213StatsCache=null;return rl213BaseInvalidate()};

// Every listed roster member actually appears whenever that roster's Custom
// team has a completed match. A missing stat entry is NOT a missed appearance:
// never synthesize that player's goals, saves, shots or assists.
rl212AllPlayerStats=function(scope='season'){
 if(scope==='career'&&rl213StatsCache?.db===db&&rl213StatsCache.count===db.seasons.length&&rl213StatsCache.lastId===db.seasons.at(-1)?.id)return rl213StatsCache.rows;
 const personsMap=new Map(),seasons=scope==='career'?db.seasons:[season()];
 const empty=()=>({goals:0,assists:0,saves:0,shots:0,matches:0,best:{goals:0,assists:0,saves:0,shots:0},history:[],sim:0,manual:0,unrecorded:0});
 function add(s,people,week,kind,block){
  const source=block?.__source==='simulated'?'simulated':'manual';
  for(let i=0;i<people.length;i++){
   const nameValue=people[i],id=scope==='career'?(i===0?'human':`mate:${nameValue}`):String(i);
   if(!personsMap.has(id))personsMap.set(id,{...empty(),id,name:i===0&&scope==='career'?roster(season())[0]:nameValue,i});
   const rec=personsMap.get(id);rec.matches++;
   const value=block?.[i];
   if(!value){rec.unrecorded++;continue}
   rec[source==='simulated'?'sim':'manual']++;
   const v={season:s.id,week,kind,source};
   for(const k of ['goals','assists','saves','shots']){v[k]=Number(value[k]||0);rec[k]+=v[k];rec.best[k]=Math.max(rec.best[k],v[k])}
   rec.history.push(v);
  }
 }
 for(const s of seasons){
  if(s.customAbsent)continue;
  const people=roster(s);
  for(let w=1,until=latest(s);w<=until;w++){
   const i=fixtures(s,w).findIndex(pair=>pair.includes('Custom'));
   if(i<0||!Array.isArray(s.results?.[w]?.[i]))continue;
   add(s,people,w,'Regular',s.playerStats?.[w]);
  }
  if(latest(s)!==s.weeks)continue;
  playoffRounds(s).forEach((round,roundIndex)=>round.matches.forEach(m=>{
   if(m.winner&&m.score&&[m.a,m.b].includes('Custom')){
    const week=s.weeks+roundIndex+1;
    const block=s.playoffPlayerStats?.[week];
    add(s,people,week,'Playoff',block);
   }
  }));
 }
 const rows=[...personsMap.values()];
 if(scope==='career')rl213StatsCache={db,rows,count:db.seasons.length,lastId:db.seasons.at(-1)?.id};
 return rows;
};

// Display dedicated *SEASONS* (not button presses / run count).
rl212HuntStatistics=function(){
 return ['Mythic','Godly'].map(kind=>{
  const runs=(db.huntHistory||[]).filter(x=>x?.target===kind);
  let seasons=runs.reduce((n,r)=>n+Math.max(0,Number(r.seasons)||0),0);
  let successes=runs.filter(r=>r.success===true).length;
  if(rl213Run?.target===kind){seasons+=rl213Run.completed;}
  const rate=seasons?100*successes/seasons:0;
  return {kind,totalSeasons:seasons,successes,rate:seasons?(rate>0&&rate<.1?rate.toFixed(2):rate.toFixed(1))+'%':'0.0%',avg:null,n:successes,total:runs.length,success:seasons?(rate>0&&rate<.1?rate.toFixed(2):rate.toFixed(1))+'%':'0.0%'};
 });
};
const rl213OriginalHuntSettingsHTML=rl212HuntSettingsHTML;
rl212HuntSettingsHTML=function(){
 const html=rl213OriginalHuntSettingsHTML(),stats=rl212HuntStatistics();
 // Replace the old run-count widgets; avoid mismatched field semantics.
 const tag='<h4>Average Seasons to Discovery</h4>';
 const i=html.indexOf(tag),end=html.indexOf('</section>',i);
 if(i<0||end<0)return html;
 const cards=`<h4>Dedicated Hunt Statistics</h4><div class="rl212-stat-grid">${stats.map(r=>
  `<div class="rl212-stat"><small>${r.kind}-only</small><b id="rl213Dedicated${r.kind}">${r.totalSeasons.toLocaleString()}</b><small>dedicated seasons</small><p class="muted"><span id="rl213DedicatedSummary${r.kind}">${r.totalSeasons.toLocaleString()} dedicated seasons · ${r.rate} success rate</span></p><small>${r.successes.toLocaleString()} successful dedicated seasons</small></div>`).join('')}</div>`;
 const perf=`<div class="rl213-telemetry"><h4>⚡ Live Turbo Hunter</h4><div class="rl213-telemetry-grid"><span>Verified throughput <strong id="rl213Speed">${rl213Run?rl213Run.speed.toFixed(1):'—'} seasons/s</strong></span><span>Completed this Hunt <strong id="rl213Completed">${rl213Run?rl213Run.completed.toLocaleString():'—'}</strong></span><span>Last confirmed save <strong id="rl213Saved">${rl213LastConfirmed||db.seasons.at(-1)?.id||'—'}</strong></span><span>Storage status <strong id="rl213StorageState">${rl213Run?'Checking…':'Idle'}</strong></span><span>Device storage <strong id="rl213StorageUsage">Estimating…</strong></span></div><p class="muted">Actual speed includes verified storage writes. No artificial simulation speed cap. Storage capacity and device performance determine sustainable speed.</p></div>`;
 return html.slice(0,i)+cards+perf+html.slice(end).replace('Averages use successful completed hunts. Capped and cancelled hunts are excluded from the simple average; success rates reflect completed dedicated runs. Mixed hunts may stop at the other rarity and are not equivalent to dedicated hunts.','Dedicated seasons include completed seasons across separate Mythic-only or Godly-only Hunts. Mixed hunts are excluded from dedicated counters.');
};
function rl213UpdateTelemetry(message){
 const run=rl213Run;
 const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
 set('rl213Speed',run?run.speed.toFixed(1)+' seasons/s':'—');
 set('rl213Completed',run?run.completed.toLocaleString():'—');
 set('rl213Saved',rl213LastConfirmed.toLocaleString());
 set('rl213StorageState',message||'Verified');
 for(const stat of rl212HuntStatistics()){set('rl213Dedicated'+stat.kind,stat.totalSeasons.toLocaleString());set('rl213DedicatedSummary'+stat.kind,stat.totalSeasons.toLocaleString()+' dedicated seasons · '+stat.rate+' success rate')}
 if(run){const suffix=run.cap==='unlimited'?'':` / ${Number(run.cap).toLocaleString()}`;
  rl212HuntStatus(`Turbo Hunter · ${run.completed.toLocaleString()} seasons${suffix} · ${run.speed.toFixed(1)} saved seasons/s · last saved S${rl213LastConfirmed} · milestone details secret`);
 }
}
function rl213IDBTx(idb,action){
 return new Promise((resolve,reject)=>{
  let tx;
  try{tx=idb.transaction([RL212_IDB_STORE,RL211_JOURNAL_STORE],'readwrite');action(tx)}
  catch(e){reject(e);return}
  tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||Error('IndexedDB transaction error'));
  tx.onabort=()=>reject(tx.error||Error('IndexedDB transaction aborted'));
 });
}
async function rl213Baseline(){
 const idb=await rl212OpenStorage();if(!idb)throw Error('IndexedDB unavailable: please use a browser with persistent IndexedDB storage.');
 // Eliminate pending *older* snapshots before committing this authoritative base.
 if(rl212WriteTimer!==null){clearTimeout(rl212WriteTimer);rl212WriteTimer=null;rl212PendingSnapshot=null}
 while(rl212WriteInProgress||rl211JournalPending>0)await new Promise(r=>setTimeout(r,30));
 if(rl211JournalFailed)throw Error('An earlier season journal write failed; export a backup before restarting the Hunt.');
 const raw=JSON.stringify(db);
 await rl213IDBTx(idb,tx=>{
  tx.objectStore(RL212_IDB_STORE).put(raw,'latest');
  tx.objectStore(RL211_JOURNAL_STORE).clear();
 });
 return idb;
}
async function rl213CommitBatch(run,message){
 const seasons=message.completed||[],extra=message.extra;
 if(!seasons.length&&!extra&&!message.outcome)return;
 const last=seasons.at(-1)?.id||run.lastCommitted;
 const metadata={lastCommittedId:last,activeId:extra?.id||last,
  huntHistory:message.outcome?[...(db.huntHistory||[]),{
   target:run.target,seasons:message.outcome.seasons,success:message.outcome.success,
   rarity:message.outcome.rarity||null,seasonId:message.outcome.seasonId,
   sealed:!!message.outcome.success,reason:message.outcome.reason||null
  }]:db.huntHistory||[]};
 await rl213IDBTx(run.idb,tx=>{
  const store=tx.objectStore(RL211_JOURNAL_STORE);
  for(const s of seasons)store.put(s,s.id);
  if(extra)store.put(extra,extra.id);
  store.put(metadata,RL213_HUNT_META);
 });
 for(const s of seasons){
  const idx=run.indexById.get(s.id);
  if(idx===undefined){run.indexById.set(s.id,db.seasons.length);db.seasons.push(s)}else db.seasons[idx]=s;
 }
 if(extra){const idx=run.indexById.get(extra.id);if(idx===undefined){run.indexById.set(extra.id,db.seasons.length);db.seasons.push(extra)}else db.seasons[idx]=extra}
 db.active=db.seasons.length-1;
 run.lastCommitted=last;
 rl213LastConfirmed=last;
 if(message.outcome)db.huntHistory=metadata.huntHistory;
}
function messageDummySelectedWeek(){const s=season();return !s||latest(s)===0?0:Math.min(s.weeks+playoffWeekCount(s)+1,latest(s)+1)}
function rl213Finish(run,outcome){
 if(rl213Run!==run)return;
 const success=!!outcome.success;
 if(success){
  selectedWeek=season().weeks+playoffWeekCount(season())+1;
  rl212HuntMessage='Target reached — Awards Night is ready. Rarity and recipient remain secret until the ceremony.';
 }else{selectedWeek=messageDummySelectedWeek();rl212HuntMessage=outcome.reason||'Hunt stopped safely.'}
 run.worker.terminate();rl213Run=null;rl212Hunt=null;
 rl211Invalidate();if(currentPage==='home')render();else renderOther();if(currentPage==='settings')rl212HuntStatus(rl212HuntMessage);
}
function rl213HuntError(run,reason){
 if(rl213Run!==run)return;
 const message=`Turbo Hunter stopped: ${reason}. Confirmed save ends at Season ${rl213LastConfirmed}. Export a JSON backup before continuing.`;
 run.worker.terminate();rl213Run=null;rl212Hunt=null;
 rl212HuntMessage=message;
 rl211Invalidate();if(currentPage==='home')render();else renderOther();if(currentPage==='settings')rl212HuntStatus(message);
 alert(message);
}
async function rl213OnBatch(run,m){
 if(rl213Run!==run)return;
 try{
  rl213UpdateTelemetry('Saving…');
  await rl213CommitBatch(run,m);
  if(rl213Run!==run)return;
  run.completed=m.completedTotal||0;
  if(rl212Hunt)rl212Hunt.seasons=run.completed;
  const duration=Math.max(.001,(performance.now()-run.started)/1000);
  run.speed=run.completed/duration;
  rl213UpdateTelemetry('Verified');
  if(m.outcome){rl213Finish(run,m.outcome);return}
  // The worker's time slice is adaptive, never a season-count cap.
  const work=Math.max(1,Number(m.workerComputeMs)||48);
  run.budgetMs=Math.max(32,Math.min(320,Math.round(run.budgetMs*(work>run.budgetMs*.96?1.15:.96))));
  run.worker.postMessage({type:'next',budgetMs:run.budgetMs});
 }catch(e){console.error('Turbo Hunt save failed',e);rl213HuntError(run,e.message||String(e))}
}
rl212StartHunt=async function(){
 if(rl213Run||rl212Hunt||worker||testBatchRunning||calibrationWorker||scenarioWorker)return;
 if(!confirm('TURBO MYTHIC & GODLY HUNT\n\nThis permanently creates complete seasons in your career. Fast simulations may consume substantial browser storage. Export your JSON backup before starting.\n\nStart Turbo Hunt?'))return;
 const target=['Mythic','Godly','either'].includes(db.huntTarget)?db.huntTarget:'either';
 const cap=RL212_CAPS.includes(db.huntCap)?db.huntCap:1000;
 rl212Hunt={target,cap,seasons:0,stopped:false};
 rl212HuntStatus('Preparing verified storage and the dedicated simulation worker…');
 try{
  const idb=await rl213Baseline();
  const run={idb,target,cap,completed:0,speed:0,started:performance.now(),worker:new Worker('./hunt-worker.js'),budgetMs:48,lastEstimate:0,indexById:new Map(db.seasons.map((s,i)=>[s.id,i])),
   lastCommitted:(playoffChampion(db.seasons.at(-1))?db.seasons.at(-1).id:db.seasons.at(-2)?.id||0),ready:false};
  rl213Run=run;rl213LastConfirmed=run.lastCommitted;
  run.worker.onmessage=e=>{
   const m=e.data||{};
   if(rl213Run!==run)return;
   if(m.type==='ready'){run.ready=true;run.started=performance.now();rl213UpdateTelemetry('Ready');run.worker.postMessage({type:'next',budgetMs:run.budgetMs})}
   else if(m.type==='batch')rl213OnBatch(run,m);
   else if(m.type==='fatal')rl213HuntError(run,m.message);
  };
  run.worker.onerror=e=>{console.error('Turbo Hunt worker crashed',e);rl213HuntError(run,e.message||'Worker error')};
  run.worker.postMessage(rl214WorkerStartMessage(target,cap));
  renderOther();
 }catch(e){
  rl212Hunt=null;rl213Run=null;
  rl212HuntMessage='Cannot start Turbo Hunter: '+(e.message||e)+'. Export your backup and check storage availability.';
  rl212HuntStatus(rl212HuntMessage);alert(rl212HuntMessage);
 }
};
rl212StopHunt=function(){
 if(rl213Run){rl213Run.worker.postMessage({type:'stop'});rl212HuntStatus('Stopping after the current season is fully simulated and saved…');return}
 if(rl212Hunt)rl212Hunt.stopped=true;
};

// Rarity-sensitive historical first badges; unaffected tiers remain gold.
rl210FirstBadge=function(tier){
 const cls=tier==='Godly'?' rl213-first-godly':tier==='Mythic'?' rl213-first-mythic':'';
 return `<span class="rl210-first${cls}" title="First team in league history to earn this milestone">No1</span>`;
};

// The original compact pages already draw the prestige ring on the logo.
// Suppress ONLY the redundant beside-the-name gem/sun in fixtures/leaderboard.
const rl213BasePrestigeMark=rl210PrestigeMark;
rl210PrestigeMark=function(t,seasonId=Infinity,week=Infinity){
 if(rl213CompactMarks)return '';
 return rl213BasePrestigeMark(t,seasonId,week);
};
let rl213CompactMarks=false;
const rl213BaseRender=render;
render=function(){
 const was=rl213CompactMarks;rl213CompactMarks=currentPage==='home';
 try{return rl213BaseRender()}finally{rl213CompactMarks=was}
};
// In standalone home rendering, avoid changing prestige details elsewhere.
const rl213BaseLeagueTableHTML=leagueTableHTML;
leagueTableHTML=function(...args){rl213CompactMarks=true;try{return rl213BaseLeagueTableHTML(...args)}finally{rl213CompactMarks=false}};

// Award reveal: do not insert award/team names into the document before their
// scheduled stage. A visual-only, skip-friendly cinematic (no audio files).
let rl213RevealTimers=[];
function rl213ClearRevealTimers(){for(const t of rl213RevealTimers)clearTimeout(t);rl213RevealTimers=[]}
function rl213RevealPhase(phase){
 const st=rl210SecretState,step=st?.groups?.[st.index],stage=document.querySelector('.rl213-cinema');
 if(!step||!stage)return;
 const team=stage.querySelector('.rl213-team'),awards=stage.querySelector('.rl213-awards');
 stage.dataset.phase=String(phase);
 if(phase>=1)stage.querySelector('.rl213-announcement').textContent=`A ${step.tier.toUpperCase()} ACHIEVEMENT HAS BEEN DISCOVERED`;
 if(phase>=2)stage.querySelector('.rl213-glyph').innerHTML=step.tier==='Godly'?rl210Sun():'◆';
 if(phase>=3)team.innerHTML=`<div class="rl210-reveal-logo">${rl210LogoWrap(rl210PlainIcon(step.t),step.tier.toLowerCase())}</div><h2>${rlTitle(step.t)}</h2>`;
 if(phase>=4){
  awards.innerHTML=step.events.map(e=>`<div class="rl210-reveal-award">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong>${e.first?rl210FirstBadge(e.tier):''}</div>`).join('');
  stage.querySelector('.rl213-next').disabled=false;
  stage.querySelector('.rl213-next').hidden=false;
  stage.querySelector('.rl213-skip').hidden=true;
 }
}
function rl213SkipSecret(){rl213ClearRevealTimers();rl213RevealPhase(4)}
const rl213OldFinishSecret=rlFinishMythicReveal;
rlFinishMythicReveal=function(){rl213ClearRevealTimers();return rl213OldFinishSecret()};
rl210RenderSecret=function(){
 const st=rl210SecretState,step=st?.groups?.[st.index];if(!step)return false;
 rl213ClearRevealTimers();
 const godly=step.tier==='Godly',s=season(),reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 const particles=Array.from({length:16},(_,i)=>`<i style="--particle:${i};--delay:${(i%7)*.31}s"></i>`).join('');
 $('other').innerHTML=`<div class="ceremony-stage rl213-cinema ${godly?'rl213-godly':'rl213-mythic'}" role="dialog" aria-modal="true" aria-label="Secret milestone reveal" data-phase="0"><div class="rl213-particles">${particles}</div><div class="rl213-beam"></div><div class="ceremony-top"><span>SEASON ${s.id} · SECRET HONOURS</span><span>REVEAL ${st.index+1} / ${st.groups.length}</span></div><div class="ceremony-center rl213-cinema-center"><div class="rl213-announcement"></div><div class="rl213-glyph"></div><div class="rl213-team"></div><div class="rl213-awards"></div></div><div class="ceremony-actions rl213-actions"><span>Permanent prestige unlocks after the ceremony</span><button class="rl213-skip" onclick="rl213SkipSecret()">Skip reveal</button><button class="ceremony-primary rl213-next" onclick="rlFinishMythicReveal()" disabled hidden>${st.index===st.groups.length-1?'Complete Secret Reveals':'Next Reveal'} ▶</button></div></div>`;
 const phases=reduced?[0,20,40,60]:godly?[1700,5700,10900,15000]:[900,2900,6100,8700];
 phases.forEach((delay,i)=>rl213RevealTimers.push(setTimeout(()=>rl213RevealPhase(i+1),delay)));
 return true;
};
