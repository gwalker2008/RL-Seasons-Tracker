'use strict';
/* Rocket League Season Tracker v2.1.3 — historical ceremonies, expandable
   records, safer large-career exports and durable Hunt preparation.
   This augments the original v2.1.2 site; saved career schema is unchanged. */

// An archive replay is read-only: it never issues an award, changes prestige,
// starts a season or marks an existing season's ceremony as completed.
let rl214Replay=null;
function rl214ReplayCeremony(id){
 if(rl213Run||rl212Hunt){alert('Finish or stop the Hunt before replaying a historical ceremony.');return}
 const idx=db.seasons.findIndex(s=>s.id===Number(id)),s=db.seasons[idx];
 if(!s||!playoffChampion(s)){alert('Only completed seasons have an Awards Ceremony.');return}
 if(rl214Replay){rl214Replay=null;rl210SecretState=null}
 rl214Replay={seasonId:s.id,previousActive:db.active,previousWeek:selectedWeek};
 db.active=idx;selectedWeek=s.weeks+playoffWeekCount(s)+1;
 rl210SecretState=null;ceremonyState={season:s.id,index:0,phase:0};
 showPage('awards');
}
function rl214ReturnToArchive(){showPage('archive')}
const rl214ShowPage=showPage;
showPage=function(page){
 if(rl214Replay&&page!=='awards'){
  const prior=rl214Replay;rl214Replay=null;rl210SecretState=null;
  db.active=prior.previousActive;selectedWeek=prior.previousWeek;
 }
 return rl214ShowPage(page);
};
const rl214Advance=ceremonyAdvance;
ceremonyAdvance=function(){
 if(!rl214Replay)return rl214Advance();
 ceremonyCancel();
 const awards=ceremonyAwards(season());
 if(ceremonyState.index<awards.length-1){ceremonyState.index++;ceremonyState.phase=0}
 else ceremonyState.phase=6;
 renderAwards(season());
};
const rl214MythicReveal=rlMythicReveal;
rlMythicReveal=function(s){
 if(!rl214Replay)return rl214MythicReveal(s);
 // Never reveal unopened secret honours in a history-only replay.
 if(!db.mythicRevealed?.[s.id])return false;
 if(!rl210SecretState||rl210SecretState.season!==s.id){
  const groups=rl210RevealSequence(s);
  if(!groups.length)return false;
  rl210SecretState={season:s.id,index:0,groups};
 }
 return rl210RenderSecret();
};
const rl214FinishReveal=rlFinishMythicReveal;
rlFinishMythicReveal=function(){
 if(!rl214Replay)return rl214FinishReveal();
 rl213ClearRevealTimers();
 if(!rl210SecretState){ceremonyState.phase=7;renderAwards(season());return}
 rl210SecretState.index++;
 if(rl210SecretState.index<rl210SecretState.groups.length){rl210RenderSecret();return}
 rl210SecretState=null;ceremonyState.phase=7;renderAwards(season());
};
// Reading an older ceremony's award order must never create a snapshot write.
const rl214CeremonyAwardsOriginal=ceremonyAwards;
ceremonyAwards=function(s){
 if(!rl214Replay||rl214Replay.seasonId!==s.id)return rl214CeremonyAwardsOriginal(s);
 if(Array.isArray(s.ceremonyArchiveV2)&&s.ceremonyArchiveV2.length)return s.ceremonyArchiveV2;
 if(!rl214Replay.awards)rl214Replay.awards=calculateCeremonyAwards(s);
 return rl214Replay.awards;
};
const rl214RenderAwards=renderAwards;
renderAwards=function(s){
 if(rl214Replay&&ceremonyState.phase>=6){
  if(ceremonyState.phase===6&&rlMythicReveal(s))return;
  $('other').innerHTML=`<div class="ceremony-stage"><div class="ceremony-center"><div class="ceremony-big">SEASON ${s.id} ARCHIVE</div><p>Historical ceremony replay finished. No new honours or prestige were issued.</p><button onclick="ceremonyState.index=0;ceremonyState.phase=0;rl210SecretState=null;renderAwards(season())">Replay this ceremony</button><button class="ceremony-primary" onclick="rl214ReturnToArchive()">Return to Season Archive</button></div></div>`;
  return;
 }
 return rl214RenderAwards(s);
};
const rl214ArchiveOriginal=rlSeasonArchivePage;
rlSeasonArchivePage=function(){
 const base=rl214ArchiveOriginal();
 const wanted=Number(window.rlArchiveSeason)||season().id;
 const s=db.seasons.find(x=>x.id===wanted)||season();
 if(!playoffChampion(s))return base;
 const all=rl210Data().events.filter(e=>e.season===s.id&&['Mythic','Godly'].includes(e.tier));
 const unveiled=!!db.mythicRevealed?.[s.id];
 const secret=all.length?(unveiled?
  `<div class="rl214-history-awards">${all.map(e=>`<div class="notice">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong> ${e.first?rl210FirstBadge(e.tier):''}<p>${safe(name(e.t,s))} · Season ${s.id} · Week ${e.week}</p></div>`).join('')}</div>`:
  '<p class="muted">Secret honours from this season remain sealed until their original Awards Night reveal.</p>'):
  '<p class="muted">No Mythic or Godly achievements were earned in this season.</p>';
 return base+`<section class="rl212-panel rl214-archive-awards"><h3>💜 Historical Mythic & Godly Honours</h3>${secret}<button onclick="rl214ReplayCeremony(${s.id})">▶ Replay Season ${s.id} Awards Ceremony</button><p class="muted">Replays are read-only; trophies, prestige and milestone histories never count a second time.</p></section>`;
};
function rl214JumpArchive(id){
 const n=Number(id);if(!Number.isInteger(n)||!db.seasons.some(s=>s.id===n)){alert('Season not found in this career.');return}
 window.rlArchiveSeason=n;renderOther();
}

// The v2.1.2 panel called the old v2.0.12 record cards and could build a
// multi-million-match intermediate array. Compute in bounded batches instead.
let rl214RecordGeneration=0;
function rl214RecordRow(title,value,details){return `<tr><td>${safe(title)}</td><td>${Number(value).toLocaleString()}</td><td>${details||'—'}</td></tr>`}
function rl214TiesDisplay(entries){
 if(!entries.length)return '—';
 const max=18;
 const first=entries.slice(0,max).map(x=>safe(x)).join('<br>');
 if(entries.length<=max)return first;
 // Collapse large tied lists to avoid inserting thousands of rows on mobile.
 return `${first}<details><summary>Show ${entries.length-max} additional tied records</summary><div class="rl214-tie-list">${entries.slice(max).map(x=>safe(x)).join('<br>')}</div></details>`;
}
function rl211LoadCareerExtras(el){
 if(!el.open||el.dataset.loaded==='yes'||el.dataset.loading==='yes')return;
 const holder=el.querySelector('.rl211-lazy-content');if(!holder)return;
 holder.innerHTML='<p class="muted" role="status">Calculating historical records… 0%</p>';
 el.dataset.loading='yes';const generation=++rl214RecordGeneration;
 const snapshot=db.seasons.slice();let i=0;
 const matchRecords=[{title:'Highest combined-score match',value:-1,holders:[]},{title:'Biggest winning margin',value:-1,holders:[]}];
 const byLength={};for(const n of [9,18,27,36])byLength[n]={count:0,w:{max:-Infinity,holders:[]},gf:{max:-Infinity,holders:[]},ga:{max:Infinity,holders:[]}};
 const track=(record,value,label,minimum=false)=>{
  const best=record.max;
  if((minimum&&value<best)||(!minimum&&value>best)){record.max=value;record.holders=[label]}
  else if(value===best)record.holders.push(label);
 };
 function process(){
  if(generation!==rl214RecordGeneration||!el.isConnected||!el.open){el.dataset.loading='';return}
  try{
   const start=performance.now();let processed=0;
   while(i<snapshot.length&&processed<70&&performance.now()-start<14){
    const s=snapshot[i++];processed++;
    const games=rlTimelineForSeason(s);
    for(const g of games){
     const info=`Season ${s.id} · Week ${g.w}: ${name(g.a,s)} ${g.x}–${g.y} ${name(g.b,s)}`;
     track(matchRecords[0],g.x+g.y,info);
     track(matchRecords[1],Math.abs(g.x-g.y),info);
    }
    if(latest(s)===s.weeks&&byLength[s.weeks]){
     const block=byLength[s.weeks];block.count++;
     for(const t of stats(s,s.weeks)){
      const label=`${name(t.t,s)} · Season ${s.id}`;
      track(block.w,t.w,label);track(block.gf,t.gf,label);track(block.ga,t.ga,label,true);
     }
    }
   }
   if(i<snapshot.length){
    if(i%350<70)holder.innerHTML=`<p class="muted" role="status">Calculating historical records… ${Math.floor(100*i/snapshot.length)}% (${i.toLocaleString()}/${snapshot.length.toLocaleString()} seasons)</p>`;
    setTimeout(process,0);return;
   }
   const milestone=rl210Data().team,active=Object.values(milestone).filter(x=>x.played>0);
   const best=(label,fn)=>{
    let value=0;for(const t of active)value=Math.max(value,fn(t));
    return rl214RecordRow(label,value,rl214TiesDisplay(value?active.filter(x=>fn(x)===value).map(x=>rlLabel(x.id)):[]));
   };
   const rows=[best('Most match wins',x=>x.wins),best('Most career goals scored',x=>x.gf),best('Most career clean sheets',x=>x.clean),best('Longest match-winning streak',x=>x.best),best('Most playoff appearances',x=>x.playoffs.length),best('Most Championship Final appearances',x=>x.finals.length),best('Most League titles',x=>x.league.length),best('Most Championships',x=>x.champ.length),
    ...matchRecords.map(r=>rl214RecordRow(r.title,Math.max(0,r.value),rl214TiesDisplay(r.holders)))];
   const formats=Object.entries(byLength).filter(([n,v])=>v.count).map(([n,v])=>`<h4>${n}-Week Seasons · ${v.count.toLocaleString()} completed</h4><div class="career-table-wrap"><table><tr><th>Record</th><th>Value</th><th>All tied holders</th></tr>${rl214RecordRow('Most league wins',v.w.max,rl214TiesDisplay(v.w.holders))}${rl214RecordRow('Most league goals',v.gf.max,rl214TiesDisplay(v.gf.holders))}${rl214RecordRow('Fewest goals conceded',v.ga.max,rl214TiesDisplay(v.ga.holders))}</table></div>`).join('');
   holder.innerHTML=`<h3>Career Milestone Records</h3><p class="muted">Calculated from ${snapshot.length.toLocaleString()} seasons, including completed playoff matches. All ties are retained; long tied lists are collapsed.</p><div class="career-table-wrap"><table><tr><th>Record</th><th>Value</th><th>All tied holders</th></tr>${rows.join('')}</table></div><h3>Season-Length-Specific Records</h3>${formats||'<p class="muted">Complete a season to see its records.</p>'}`;
   el.dataset.loaded='yes';el.dataset.loading='';
  }catch(error){console.error('Historical records calculation failed',error);el.dataset.loading='';holder.innerHTML=`<div class="notice" role="alert">Historical records could not be calculated: ${safe(error.message||error)} <button onclick="this.closest('details').dataset.loaded='';rl211LoadCareerExtras(this.closest('details'))">Retry</button></div>`}
 }
 setTimeout(process,0);
}

// Export on mobile without creating one enormous JSON.stringify(db) string.
// The download is equivalent to the longstanding full JSON backup format.
let rl214ExportBusy=false;
async function exportData(){
 if(rl214ExportBusy)return;
 if(rl213Run||rl212Hunt){alert('Stop the Hunt before exporting so your backup contains a consistent completed checkpoint.');return}
 rl214ExportBusy=true;
 const button=document.getElementById('rl214ExportProgress');
 const report=msg=>{if(button)button.textContent=msg};
 const filename=`rocket-league-tracker-v2.1.3-season-${db.seasons.at(-1)?.id||0}-career-backup.json`;
 let chunks=[],bytes=0,writer=null,handle=null;
 try{
  // Some desktop browsers support direct file writing (minimal extra RAM).
  if(typeof window.showSaveFilePicker==='function'){
   try{handle=await window.showSaveFilePicker({suggestedName:filename,types:[{description:'JSON career backup',accept:{'application/json':['.json']}}]});writer=await handle.createWritable()}
   catch(e){if(e.name==='AbortError')return;handle=null;writer=null}
  }
  const emit=async part=>{
   bytes+=part.length;
   if(writer)await writer.write(part);else chunks.push(part);
  };
  const target=db,copyCount=target.seasons.length;
  await emit('{"seasons":[');
  for(let i=0;i<copyCount;i++){
   await emit((i?',':'')+JSON.stringify(target.seasons[i]));
   if(i%60===0){report(`Preparing backup… ${Math.floor(100*(i+1)/copyCount)}%`);await new Promise(r=>setTimeout(r,0))}
  }
  await emit(']');
  for(const k of Object.keys(target))if(k!=='seasons')await emit(','+JSON.stringify(k)+':'+JSON.stringify(target[k]));
  await emit('}');
  if(writer){await writer.close();writer=null}
  else{
   const blob=new Blob(chunks,{type:'application/json'});
   chunks=[];
   const url=URL.createObjectURL(blob),a=document.createElement('a');
   a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
   // Android browsers may take longer than three seconds to start a large file.
   setTimeout(()=>URL.revokeObjectURL(url),120000);
  }
  report(`Backup prepared · ${(bytes/1048576).toFixed(1)} MiB`);
 }catch(e){
  console.error('Career export failed',e);
  if(writer)try{await writer.abort()}catch(_){}
  report('Export failed — please retry');alert('Backup export failed: '+(e.message||e));
 }finally{rl214ExportBusy=false}
}

// Avoid an unnecessary full-career stringify/clone before every new Hunt.
// Existing IndexedDB full snapshot + atomic per-season journal stay in place.
rl213Baseline=async function(){
 const idb=await rl212OpenStorage();
 if(!idb)throw Error('IndexedDB is unavailable; a verified Turbo Hunt cannot begin.');
 if(rl212WriteTimer!==null){clearTimeout(rl212WriteTimer);rl212WriteTimer=null}
 if(rl212PendingSnapshot&&!rl212WriteInProgress)rl212FlushWrite();
 let count=0;
 while(rl212WriteInProgress||rl211JournalPending>0||rl212PendingSnapshot){
  if(rl212PendingSnapshot&&!rl212WriteInProgress)rl212FlushWrite();
  if(++count>1500)throw Error('Previous save has not finished; check device storage.');
  await new Promise(r=>setTimeout(r,20));
 }
 if(rl211JournalFailed)throw Error('A prior journal save failed. Export a backup before hunting.');
 if(rl212LastSnapshotFailure)throw Error('A previous IndexedDB snapshot write failed; export a backup before hunting.');
 const exists=await new Promise((resolve,reject)=>{
  const tx=idb.transaction(RL212_IDB_STORE,'readonly'),req=tx.objectStore(RL212_IDB_STORE).get('latest');
  req.onsuccess=()=>resolve(!!req.result);req.onerror=()=>reject(req.error);
 });
 if(!exists){
  // First upgrade / new career only: establish the initial durable base.
  const raw=JSON.stringify(db);
  await rl213IDBTx(idb,tx=>tx.objectStore(RL212_IDB_STORE).put(raw,'latest'));
 }
 return idb;
};

// Make backup progress visible wherever the standard Export button appears.
const rl214SettingsMarkup=rl212HuntSettingsHTML;
rl212HuntSettingsHTML=function(){return rl214SettingsMarkup().replace('onclick="exportData()">Export backup</button>', 'onclick="exportData()">Export backup</button><span id="rl214ExportProgress" class="muted" role="status"></span>')};

// Transferring 18,000 complete seasons to the worker would duplicate the
// entire career in RAM. A bounded history plus accurately seeded runs has the
// same current-season simulation rules and catches streaks across the boundary.
function rl214HundredAlreadyEarnedThisSeason(s){
 if(!s||playoffChampion(s))return false;
 const previous=rlStreakBefore(s,1),running={...previous};
 for(const g of rlTimelineForSeason(s))for(const t of [g.a,g.b]){
  const [gf,ga]=rlResultFrom(g,t);
  running[t]=gf>ga?(running[t]||0)+1:0;
  if(running[t]===100)return true;
 }
 return false;
}
function rl214WorkerStartMessage(target,cap){
 const full=db.seasons,last=full.at(-1),prior=playoffChampion(last)?last:full.at(-2);
 const kinds=['league','champ','doubles','perfect'],seedRuns={};
 const qualifies=(s,kind,t)=>{
  if(!s||latest(s)!==s.weeks)return false;
  const league=stats(s,s.weeks)[0]?.t,champ=playoffChampion(s);
  if(kind==='league')return league===t;
  if(kind==='champ')return champ===t;
  if(league!==t||champ!==t)return false;
  if(kind==='doubles')return true;
  const games=rlTimelineForSeason(s).filter(g=>g.a===t||g.b===t);
  return games.length===s.weeks+2&&games.every(g=>{const [gf,ga]=rlResultFrom(g,t);return gf>ga&&ga===0});
 };
 if(prior){
  const league=stats(prior,prior.weeks)[0]?.t,champ=playoffChampion(prior);
  for(const kind of kinds){
   const t=kind==='league'?league:kind==='champ'?champ:league===champ?champ:null;
   if(!t||!qualifies(prior,kind,t))continue;
   let len=0,expected=prior.id;
   for(let i=full.findIndex(s=>s===prior);i>=0;i--){
    const s=full[i];if(s.id!==expected||!qualifies(s,kind,t))break;
    len++;expected--;
   }
   seedRuns[kind]={id:prior.id,t,len};
  }
 }
 const streaks=rlStreakBefore(last,Infinity);
 // Season and format settings retained; no images, archive or milestone HTML
 // are needed to calculate match scores in the Worker.
 const ignore=new Set(['seasons','huntHistory','milestoneNotified','logos','customLogo']);
 const compact=Object.fromEntries(Object.entries(db).filter(([key])=>!ignore.has(key)));
 compact.seasons=full.slice(-40);
 compact.active=compact.seasons.length-1;
 compact.huntHistory=[];compact.logos={};compact.customLogo='';
 return {type:'start',career:compact,target,cap,seedRuns,streaks,currentHundred:rl214HundredAlreadyEarnedThisSeason(last)};
}

function rl214CompareJump(selectId,value){
 const id=Number(value),target=db.seasons.find(s=>s.id===id&&latest(s)===s.weeks&&!!playoffChampion(s));
 if(!Number.isInteger(id)||!target){alert('That completed season was not found.');return}
 const select=document.getElementById(selectId);if(!select)return;
 if(![...select.options].some(o=>Number(o.value)===id))select.add(new Option('Season '+id,String(id)));
 select.value=String(id);rlCompareRender();
}

const rl214BeforeStreakInvalidate=rl211Invalidate;
rl211Invalidate=function(){rl213StreakMemo=null;return rl214BeforeStreakInvalidate()};
