'use strict';
const AI=['Bombers','Cyclones','Dragons','Express','Guardians','Mammoths','Monarchs','Rebels','Rovers','Seekers','Skyhawks'];
// Bot selector can be expanded as the game's full bot list is verified.
const BOTS=['Bandit','Beast','Boomer','Buzz','Casper','Caveman','Centice','Chipper','C-Block','Cougar','Dude','Foamer','Fury','Gerwin','Goose','Heater','Hollywood','Hound','Iceman','Imp','Jester','Junker','Khan','Maverick','Merlin','Middles','Mountain','Myrtle','Outlaw','Poncho','Raja','Rainmaker','Rex','Roundhouse','Sabretooth','Saltie','Samara','Scout','Shepard','Slider','Squire','Stinger','Sundown','Swabbie','Tusk','Viper','Wolfman','Yuri'];
const OFFICIAL_LOGO_BASE='';
function officialLogo(t){return './team-logos/'+t+'_season_team_logo.webp'}
const KEY='rl_tracker_save_v3',OLD='rl_tracker_save_v2';
const SIM_CHOICES=[25000,50000,100000,250000,500000];
function simulationCount(){const n=Number(db?.simulationCount);return SIM_CHOICES.includes(n)?n:100000}
function seasonFormat(){return db?.seasonNumberFormat==='full'?'full':'compact'}
function seasonLabel(n){return seasonFormat()==='full'?'Season '+n:'S'+n}
function seasonList(nums){return seasonFormat()==='full'?'Seasons '+nums.join(', '):nums.map(n=>'S'+n).join(', ')}
function saveSeasonFormat(v){db.seasonNumberFormat=v==='full'?'full':'compact';persist();renderOther()}
function saveSimulationCount(value){const n=Number(value);if(!SIM_CHOICES.includes(n))return;db.simulationCount=n;persist();renderOther()}

const $=id=>document.getElementById(id);
const RECOVERY_KEY='rl_tracker_recovery_v1';
let db,saveLoadError=false;
function validCareer(v){return !!v&&Array.isArray(v.seasons)&&v.seasons.length>0&&v.seasons.every(s=>s&&Array.isArray(s.ai)&&(s.customAbsent===true ? s.ai.length===10 : s.ai.length===9))}
try{
 const primary=localStorage.getItem(KEY),legacy=localStorage.getItem(OLD),recovery=localStorage.getItem(RECOVERY_KEY);
 for(const raw of [primary,legacy,recovery]){
  if(!raw)continue;
  try{const parsed=JSON.parse(raw);if(validCareer(parsed)){db=parsed;break}if(primary===raw)saveLoadError=true}catch(e){saveLoadError=true}
 }
}catch(e){saveLoadError=true}
if(!db)db={customName:'My Team',customLogo:'',logos:{},seasons:[],active:0};
const hadSave=db.seasons.length>0; let setup=null,setupStep=0;
db.logos ||= {}; db.customName ||= 'My Team';db.customLogo ||= '';
let selectedWeek=1,oddsMode='title',currentPage='home',worker=null,editing=false,sortStat='goals';
let historyMetric='champ',historyTeams=[],historyHover=null,historyWeek=null,historyFullScale=false;
const HISTORY_COLORS=['#60a5fa','#fbbf24','#6ee7b7','#f472b6','#c4b5fd','#fb923c','#a3e635','#22d3ee','#f87171','#e5e7eb'];
function safe(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let saveWarningShown=false;
function persist(){
 try{
  const raw=JSON.stringify(db);
  localStorage.setItem(KEY,raw);
  // A second local copy is best-effort. Keep the primary even if storage is nearly full.
  try{localStorage.setItem(RECOVERY_KEY,raw)}catch(e){}
  saveLoadError=false;
  return true;
 }catch(e){
  if(!saveWarningShown){saveWarningShown=true;alert('Could not save your career in browser storage. Export a JSON backup now. Check browser storage permissions and available space.');}
  return false;
 }
}
function season(){return db.seasons[db.active]}
const SLOT_KEY='rl_tracker_career_slots_v1';
function listCareerSlots(){try{return JSON.parse(localStorage.getItem(SLOT_KEY)||'{}')}catch(e){return {}}}
function saveCareerSlot(){const label=prompt('Name this career save slot (e.g. Season 1 test):','Career '+new Date().toLocaleDateString());if(!label?.trim())return;try{const slots=listCareerSlots(),id=String(Date.now());slots[id]={name:label.trim().slice(0,60),saved:new Date().toISOString(),data:JSON.stringify(db)};localStorage.setItem(SLOT_KEY,JSON.stringify(slots));alert('Career slot saved. Export a JSON backup too for protection against browser data loss.');renderOther()}catch(e){alert('Could not save slot: browser storage may be full. Export a JSON backup instead.')}}
function loadCareerSlot(id){if(rl211HuntGuard())return;const slot=listCareerSlots()[id];if(!slot||!confirm('Load '+slot.name+'? Unsaved changes to your current career may be lost.'))return;try{const next=JSON.parse(slot.data);if(!validCareer(next))throw Error('Invalid save');rl211PrepareReplacement();db=next;db.seasons.forEach(initSeason);rlRecalculateHistoricalMatches();db.active=Math.max(0,Math.min(db.active,db.seasons.length-1));selectedWeek=0;if(!persist())throw Error('Browser storage full');showPage('home')}catch(e){alert('Unable to load this career slot: '+e.message)}}
function deleteCareerSlot(id){const slots=listCareerSlots();if(!slots[id]||!confirm('Delete slot '+slots[id].name+'?'))return;delete slots[id];try{localStorage.setItem(SLOT_KEY,JSON.stringify(slots));renderOther()}catch(e){alert('Could not delete slot')}}
function careerSlotsHTML(){const slots=listCareerSlots();return `<h3>Career save slots</h3><p class="muted">Store separate career snapshots on this device. Save a slot after making changes; slots do not automatically update. Browser data clearing can remove all slots, so export JSON backups too.</p><button onclick="saveCareerSlot()">Save current career to a new slot</button>`+Object.entries(slots).map(([id,slot])=>`<div class="notice"><strong>${safe(slot.name)}</strong><p class="muted">Saved ${safe(new Date(slot.saved).toLocaleString())}</p><button onclick="loadCareerSlot('${id}')">Load</button> <button class="danger" onclick="deleteCareerSlot('${id}')">Delete</button></div>`).join('')}

function initSeason(s){for(const k of Object.keys(db))if(/rival/i.test(k))delete db[k];for(const k of Object.keys(s))if(/rival/i.test(k))delete s[k];s.mode=Number(s.mode)||4;s.humanName ??='';s.botNames ||= BOTS.slice(0,3);s.playerStats ||= {};s.fixtures ||= {};s.results ||= {};s.odds ||= {};s.ai ||= AI.slice(0,9);s.customName ||= db.customName;s.playoffs ||= [];s.champion ??= null;s.weeks ||=36;s.playoffCount ||=6;s.badge ||=null;
 // v1.0 final hotfix: put the player-controlled team first in every league fixture.
 // Convert old score arrays together with their fixture orientation, so no result changes.
 if(!s.customAlwaysHomeV1){
  for(let w=1;w<=s.weeks;w++){
   const pairList=s.fixtures[w]||standardFixtures(s,w);
   let changed=false;
   const normalized=pairList.map(([a,b],i)=>{
    if(b!=='Custom')return [a,b];
    changed=true;
    const score=s.results[w]?.[i];
    if(Array.isArray(score)&&score.length===2)s.results[w][i]=[score[1],score[0]];
    return [b,a];
   });
   if(changed)s.fixtures[w]=normalized;
  }
  s.customAlwaysHomeV1=true;
 }
 return s}
function makeSeason(ai,mode){return initSeason({id:(db.seasons.at(-1)?.id||0)+1,ai:[...ai],mode,customName:db.customName,humanName:'',botNames:BOTS.slice(0,3),results:{},fixtures:{},playerStats:{},odds:{},playoffs:[],champion:null})}
if(!db.seasons.length){db.seasons.push(makeSeason(['Rebels','Monarchs','Rovers','Seekers','Guardians','Express','Dragons','Cyclones','Bombers'],4));db.active=0}
db.seasons.forEach(initSeason);
selectedWeek=Math.max(0,Math.min(db.seasons[db.active]?.weeks||36,latest(db.seasons[db.active]||db.seasons[0])+1));
function teams(s){return ['Custom',...s.ai]};function name(t,s){return t==='Custom'?s.customName:t}
function icon(t){
 const url=t==='Custom'?(season()?.badge||db.customLogo):(db.logos[t]||'./team-logos/'+t+'_season_team_logo.webp');
 const initial=safe((t==='Custom'?db.customName:t).charAt(0)||'?');
 const fallback=`<span class="logo-fallback" hidden>${initial}</span>`;
 if(!url)return `<span class="logo-fallback">${initial}</span>`;
 const badgeMatch=String(url).match(/badge-(\d+)\.png(?:[?#]|$)/i);
 const largeBadges=new Set([1,10,11,13,14,16,17,18,19,20]);
 const enlarged=badgeMatch&&largeBadges.has(Number(badgeMatch[1]));
 return `<span class="logo-slot${t==='Custom'?' logo-custom':''}${enlarged?' logo-badge-boost':''}"><img class="logo" src="${safe(url)}" alt="" loading="lazy" onerror="this.hidden=true;this.nextElementSibling.hidden=false">${fallback}</span>`;
}
function standardFixtures(s,w){let a=['Custom',...s.ai],rounds=[];for(let r=0;r<9;r++){let pairs=[];for(let i=0;i<5;i++)pairs.push([a[i],a[9-i]]);rounds.push(pairs);a=[a[0],a[9],...a.slice(1,9)]}return rounds[(w-1)%9].map(p=>{const q=Math.floor((w-1)/9)%2?[p[1],p[0]]:[...p];return q[1]==='Custom'?[q[1],q[0]]:q})}
function fixtures(s,w){return s.fixtures[w]||standardFixtures(s,w)}
function schedule(s){let out=[];for(let w=1;w<=s.weeks;w++)fixtures(s,w).forEach(([a,b])=>out.push({w,a,b}));return out}
function complete(s,w){return Array.isArray(s.results[w])&&s.results[w].length===5}
function latest(s){let w=0;while(w<s.weeks&&complete(s,w+1))w++;return w}
function stats(s,w){let t=Object.fromEntries(teams(s).map(x=>[x,{t:x,w:0,l:0,gf:0,ga:0,form:[]}]));for(let k=1;k<=Math.min(w,s.weeks);k++){let res=s.results[k];if(!res)continue;fixtures(s,k).forEach(([a,b],i)=>{let v=res[i];if(!v||!t[a]||!t[b])return;let [x,y]=v,A=t[a],B=t[b];A.gf+=x;A.ga+=y;B.gf+=y;B.ga+=x;A.w+=x>y;A.l+=x<y;B.w+=y>x;B.l+=y<x;A.form.push(x>y?'W':'L');B.form.push(y>x?'W':'L')})}return Object.values(t).sort((a,b)=>b.w-a.w||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||name(a.t,s).localeCompare(name(b.t,s)))}
function rlToggleMore(){const m=document.getElementById('moreNavMenu');const open=m.classList.toggle('hidden')===false;document.getElementById('moreNavButton').setAttribute('aria-expanded',String(open))}
function rlSyncTheme(){const s=season();const championship=selectedWeek>s.weeks;document.body.classList.toggle('rl-championship',championship);const meta=document.querySelector('meta[name=theme-color]');if(meta)meta.content=championship?'#191715':'#12171d';document.querySelectorAll('#siteNav>button[data-page]').forEach(b=>b.classList.toggle('nav-current',b.dataset.page===currentPage));const more=document.getElementById('moreNavButton');if(more)more.classList.toggle('nav-current',['teams','history','archive','awards','settings'].includes(currentPage))}
let rlTakeoverTimer=null;
let rlTakeoverLocked=false;
function rlPlayTakeover(reverse,onCovered){
 const overlay=document.getElementById('takeover');
 if(!overlay||window.matchMedia('(prefers-reduced-motion: reduce)').matches){onCovered();return}
 rlTakeoverLocked=true;
 clearTimeout(rlTakeoverTimer);
 overlay.classList.remove('takeover-running','takeover-reverse');
 overlay.querySelector('.takeover-emblem').innerHTML=reverse?'⚡<span>BACK TO THE LEAGUE</span><small>REGULAR SEASON</small>':'♛<span>THE CHAMPIONSHIP</span><small>BEGINS NOW</small>';
 if(reverse)overlay.classList.add('takeover-reverse');
 void overlay.offsetWidth;
 overlay.classList.add('takeover-running');
 // The original league stays on screen until the curtain is fully closed (38% of 2500ms).
 // Switching at the halfway hold avoids a one-frame flash of the destination theme.
 setTimeout(()=>{onCovered()},1250);
 rlTakeoverTimer=setTimeout(()=>{overlay.classList.remove('takeover-running','takeover-reverse');rlTakeoverLocked=false},2600);
}
function showPage(p){if(p==='analytics')p='players';document.getElementById('moreNavMenu')?.classList.add('hidden');document.getElementById('moreNavButton')?.setAttribute('aria-expanded','false');if(p!=='awards'&&typeof ceremonyCancel==='function')ceremonyCancel();currentPage=p;$('home').classList.toggle('hidden',p!=='home');$('other').classList.toggle('hidden',p==='home');editing=false;render()}
function chooseSeason(){db.active=Number($('seasonPick').value);selectedWeek=Math.min(selectedWeek,maxViewWeek(season()));persist();render()}
function playoffWeekCount(s){return s.playoffCount===4?2:3}
function maxViewWeek(s){return playoffChampion(s)?s.weeks+playoffWeekCount(s)+2:latest(s)===s.weeks?s.weeks+playoffWeekCount(s):s.weeks}
function changeWeek(d){if(rlTakeoverLocked)return;const old=selectedWeek;const next=Math.max(0,Math.min(maxViewWeek(season()),old+d));if(d>0&&next===season().weeks+playoffWeekCount(season())+2&&old!==next){selectedWeek=next;editing=false;rlOpenCeremony();return}const crossing=currentPage==='home'&&((old===season().weeks&&next===season().weeks+1)||(old===season().weeks+1&&next===season().weeks));const commit=()=>{selectedWeek=next;editing=false;render()};if(crossing)rlPlayTakeover(next===season().weeks,commit);else commit()}
function setOddsMode(m){oddsMode=m;render()}
const ODDS_COLORS={champ:'#eab308',bye:'#c0c0c0',title:'#3b82f6',top6:'#22c55e',elim:'#ef4444'};
function oddsValue(row,metric){return metric==='elim'?100-(row?.top6||0):Number(row?.[metric]||0)}
function setHistoryMetric(m){historyMetric=m;renderOdds(season())}
function toggleHistoryTeam(t){historyTeams=historyTeams.includes(t)?historyTeams.filter(x=>x!==t):[...historyTeams,t];renderOdds(season())}
// Conservative mathematical statuses: ambiguous ties remain uncoloured until resolved.
function leagueRowStatuses(s,through){
 const w=Math.max(0,Math.min(s.weeks,through)),table=stats(s,w),slots=s.playoffCount;
 const remaining=s.weeks-w,out={};
 if(w===s.weeks){table.forEach((r,i)=>out[r.t]=i===0?'champion':i<slots?'qualified':'eliminated');return out}
 for(const r of table){
  const guaranteedAbove=table.filter(x=>x.t!==r.t&&x.w>r.w+remaining).length;
  const possibleAbove=table.filter(x=>x.t!==r.t&&x.w+remaining>=r.w).length;
  const certainChampion=table.every(x=>x.t===r.t||r.w>x.w+remaining);
  out[r.t]=certainChampion?'champion':guaranteedAbove>=slots?'eliminated':possibleAbove<slots?'qualified':'';
 }
 return out;
}
// Derived from the saved previous season on every render, including imported and ongoing careers.
function previousSeasonHonours(s){
 const prior=db.seasons.find(x=>x.id===s.id-1);
 if(!prior)return null;
 const honours={champion:null,league:null,runner:null};
 if(latest(prior)===prior.weeks){
  const first=stats(prior,prior.weeks)[0];
  if(first)honours.league=name(first.t,prior);
 }
 const champion=playoffChampion(prior);
 if(champion){
  honours.champion=name(champion,prior);
  const final=playoffRounds(prior).at(-1)?.matches?.[0];
  if(final?.winner&&final.a&&final.b){
   const loser=final.winner===final.a?final.b:final.a;
   honours.runner=name(loser,prior);
  }
 }
 return honours;
}
function leagueTableHTML(s,through){
 const rows=stats(s,through),statuses=leagueRowStatuses(s,through),honours=previousSeasonHonours(s);
 return '<table class="league-status-table"><tr><th>#</th><th>Team</th><th>W</th><th>L</th><th>GF</th><th>GA</th><th>GD</th></tr>'+rows.map((r,i)=>{
 const cls=statuses[r.t]?' status-'+statuses[r.t]:'';
 const prevPos=through>1?stats(s,through-1).findIndex(x=>x.t===r.t)+1:0;const movement=prevPos?prevPos-(i+1):0;const movementHTML=!prevPos?'':movement>0?`<span class="rank-movement rank-up" title="Up ${movement} places">▲${movement}</span>`:movement<0?`<span class="rank-movement rank-down" title="Down ${-movement} places">▼${-movement}</span>`:'<span class="rank-movement rank-flat" title="No change">–</span>';
 const teamName=name(r.t,s);
 const awards=[['champion','🏆','Previous season Championship winner'],['league','🥇','Previous season League winner'],['runner','🥈','Previous season Championship runner-up']];
 const trophy=honours?awards.filter(([key])=>honours[key]===teamName).map(([,emoji,label])=>` <span class="defending-trophy" title="${label}" aria-label="${label}">${emoji}</span>`).join(''):'';
 return `<tr class="league-status-row${cls}"><td>${i+1}${movementHTML}</td><td><span class="rl216-team-line">${icon(r.t)} <span class="league-team-name">${safe(name(r.t,s))}</span>${rl210PrestigeMark(r.t,s.id,through)}${trophy}${rlFire(r.t,s,Math.min(through+1,s.weeks+1))}</span></td><td>${r.w}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gf-r.ga}</td></tr>`;
 }).join('')+'</table>'+(honours&&(honours.champion||honours.league||honours.runner)?'<div class="standings-honours-key" aria-label="Previous season honours key"><strong>Previous season honours</strong><span>🏆 Championship winner</span><span>🥇 League winner</span><span>🥈 Championship runner-up</span></div>':'')+'<div class="standings-legend"><span class="legend-champion">League champion</span><span class="legend-qualified">Playoffs secured</span><span class="legend-eliminated">Eliminated</span></div>';
}
function render(){rlSyncTheme();let s=season();$('fixtureSectionTitle').textContent='Fixtures & Results';const seasonPicker=$('seasonPick');if(seasonPicker.dataset.seasonCount!==String(db.seasons.length)||seasonPicker.dataset.lastId!==String(db.seasons.at(-1)?.id)){seasonPicker.innerHTML=db.seasons.map((x,i)=>`<option value="${i}">Season ${x.id}</option>`).join('');seasonPicker.dataset.seasonCount=String(db.seasons.length);seasonPicker.dataset.lastId=String(db.seasons.at(-1)?.id)}seasonPicker.value=String(db.active);$('status').textContent=`${latest(s)}/${s.weeks} weeks · ${s.mode}v${s.mode} · Top ${s.playoffCount}`;if(currentPage!=='home'){renderOther();return}let w=selectedWeek,locked=w>latest(s)+1;renderBroadcastHeader(s,w);
 if(w===0){
  $('standingsTitle').classList.remove('hidden');$('standings').classList.remove('hidden');$('playoffPanel').classList.add('hidden');$('saveWeek').classList.add('hidden');
  const editButton=$('fixtureEditor').previousElementSibling;if(editButton)editButton.classList.add('hidden');
  $('weekTitle').textContent='Week 0 — Preseason';$('fixtures').innerHTML=rlPreseasonHTML(s);
  $('fixtureEditor').classList.add('hidden');$('playerEntry').innerHTML='';$('weekInfo').textContent='Preseason predictions are saved separately and do not change as the season progresses.';
  $('standingsTitle').textContent='Leaderboard — Week 0';$('standings').innerHTML=leagueTableHTML(s,0);renderOdds(s);renderHomeNews(s,0);return;
 }
 if(w>s.weeks+playoffWeekCount(s)){renderFinaleWeek(s,w);renderOdds(s);renderHomeNews(s,w);return}if(w>s.weeks){renderPlayoffWeek(s,w);renderOdds(s);renderHomeNews(s,w);return} $('standingsTitle').classList.remove('hidden');$('standings').classList.remove('hidden');$('playoffPanel').classList.add('hidden');$('saveWeek').classList.remove('hidden');const editButton=$('fixtureEditor').previousElementSibling;if(editButton)editButton.classList.remove('hidden');$('weekTitle').textContent=`Week ${w}`;$('fixtures').innerHTML=fixtures(s,w).map(([a,b],i)=>{let v=s.results[w]?.[i];return `<div class="match"><div class="team right">${icon(a)}<span>${safe(name(a,s))}</span>${rl210PrestigeMark(a,s.id,w)}${rlFire(a,s,w)}${rlStreakShowdown(a,b,s,w)}</div><input id="a${i}" type="number" min="0" step="1" value="${v?.[0]??''}" ${locked?'disabled':''}><span>–</span><input id="b${i}" type="number" min="0" step="1" value="${v?.[1]??''}" ${locked?'disabled':''}><div class="team">${icon(b)}<span>${safe(name(b,s))}</span>${rl210PrestigeMark(b,s.id,w)}${rlFire(b,s,w)}</div></div>`}).join('');$('saveWeek').disabled=locked||!!worker;$('weekInfo').textContent=locked?'Complete earlier weeks first.':'Enter all five results. Blank score = 0; 0–0 is invalid. Player stats are entered separately below.';renderPlayerEntry(s,w,locked);$('fixtureEditor').classList.add('hidden');if(editing)showFixtureEditor();let st=stats(s,Math.min(w,latest(s)));$('standingsTitle').textContent=`Leaderboard — Week ${Math.min(w,latest(s))}`;$('standings').innerHTML=leagueTableHTML(s,Math.min(w,latest(s)));renderOdds(s);renderHomeNews(s,w)}

function renderBroadcastHeader(s,w){
 const el=$('broadcastHeader');if(!el)return;
 const known=Math.min(Math.max(0,w),latest(s)),leader=stats(s,known)[0];
 const prev=db.seasons.filter(z=>z.id<s.id).sort((a,b)=>b.id-a.id)[0];
 const champ=prev&&playoffChampion(prev)?name(playoffChampion(prev),prev):'To be decided';
 const defendingLeague=prev&&latest(prev)===prev.weeks?name(stats(prev,prev.weeks)[0]?.t,prev):'To be decided';
 const phase=w===0?'PRESEASON':w<=s.weeks?'REGULAR SEASON':w<=s.weeks+playoffWeekCount(s)?'CHAMPIONSHIP PLAYOFFS':w===s.weeks+playoffWeekCount(s)+1?'SEASON FINALE':'AWARDS NIGHT';
 const pct=Math.round(Math.min(1,known/s.weeks)*100);
 el.innerHTML=`<div class="broadcast-top"><span>SEASON ${s.id} · ${phase}</span><strong>${w===0?'PRESEASON':`WEEK ${w}`}</strong></div><div class="broadcast-metadata"><span>League leader: <b>${safe(leader?name(leader.t,s):'—')}</b></span><span>Defending League Champion: <b>${safe(defendingLeague)}</b></span><span>Defending Championship Champion: <b>${safe(champ)}</b></span><span>Regular season: <b>${known}/${s.weeks}</b></span></div><div class="broadcast-progress" role="progressbar" aria-label="Regular season progress" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><span style="width:${pct}%"></span></div>`;
}
function rlPreseasonHTML(s){const prior=db.seasons.filter(x=>x.id<s.id).sort((a,b)=>b.id-a.id)[0],pre=s.odds?.[0]?.rows||[];const prevNames=prior?teams(prior):[],now=teams(s);const title=prior&&latest(prior)===prior.weeks?name(stats(prior,prior.weeks)[0].t,prior):null,champ=prior?playoffChampion(prior):null;return `<div class="notice"><h3>🏁 Season ${s.id} Preseason Preview</h3>${prior?`<p><strong>Defending League Champions:</strong> ${safe(title||'Not confirmed')}</p><p><strong>Defending Championship Winners:</strong> ${safe(champ?name(champ,prior):'Not confirmed')}</p><p><strong>Returning:</strong> ${safe(now.filter(n=>prevNames.includes(n)).map(n=>name(n,s)).join(', ')||'None')}</p><p><strong>New or returning after absence:</strong> ${safe(now.filter(n=>!prevNames.includes(n)).map(n=>name(n,s)).join(', ')||'None')}</p>`:'<p>The inaugural season begins. Every team starts with a clean slate.</p>'}${pre.length?`<h3>Preseason Power Rankings & Odds</h3><p class="muted">Predictions saved before Week 1. Title / Top six / Championship probabilities.</p>${[...pre].sort((a,b)=>(b.title||0)-(a.title||0)).map((r,i)=>`<p>${i+1}. ${safe(name(r.t,s))} — ${Number(r.title||0).toFixed(1)}% / ${Number(r.top6||0).toFixed(1)}% / ${Number(r.champ||0).toFixed(1)}%</p>`).join('')}`:'<p>Preseason odds are calculating or have not been saved yet. Use the Odds column to view the first simulation snapshot.</p>'}<h3>Opening Week</h3>${fixtures(s,1).map(([a,b])=>`<p>${safe(name(a,s))} vs ${safe(name(b,s))}</p>`).join('')}<button onclick="selectedWeek=1;render()">Begin Season ${s.id} ▶</button></div>`}
function renderFinaleWeek(s,w){const awardWeek=s.weeks+playoffWeekCount(s)+2;const awards=w===awardWeek;$('weekTitle').textContent=`Week ${w} — ${awards?'Awards Ceremony':'Season Finale'}`;$('standingsTitle').classList.add('hidden');$('standings').classList.add('hidden');$('playoffPanel').classList.remove('hidden');$('saveWeek').classList.add('hidden');$('fixtureEditor').classList.add('hidden');$('playerEntry').innerHTML='';const edit=$('fixtureEditor').previousElementSibling;if(edit)edit.classList.add('hidden');renderPlayoffs(s);$('weekInfo').textContent=awards?'Season Awards — no fixtures':'Season review — no fixtures';$('fixtures').innerHTML=awards?`<div class="notice"><h3>🏆 Season ${s.id} Awards Ceremony</h3><p>All regular awards, followed by the League Title and Championship.</p><button onclick="rlOpenCeremony()">Open Awards Ceremony ▶</button></div>`:rlFinaleHTML(s)}
function rlOpenCeremony(){ceremonyState={season:season().id,index:0,phase:0};showPage('awards')}
function ceremonyWinnerSpeech(item,s){
 const t=item.teams?.[0],nom=(item.nominees||[]).find(n=>n.t===t)||{t};
 const reason=ceremonyNomineeReason(item,nom,s),title=String(item.title||'').toLowerCase();
 if(t===undefined)return reason;
 const table=stats(s,s.weeks),rank=table.findIndex(r=>r.t===t)+1,rounds=playoffRounds(s);
 const wins=rounds.flatMap(r=>r.matches.filter(m=>m.score&&(m.a===t||m.b===t)&&m.winner===t).map(m=>({m,r}))); 
 if(title.includes('surprise')&&t===playoffChampion(s))return `${name(t,s)} finished ${rank}${ordinalSuffix(rank)} in the league but won the Championship by defeating ${wins.map(x=>name(x.m.a===t?x.m.b:x.m.a,s)).join(', ')}. Their ${wins.length}-win knockout run made the difference.`;
 if(title.includes('match')&&nom.a!==undefined&&nom.b!==undefined)return `This result earned Match of the Season for its stakes and its scoreline. ${reason}`;
 return `${name(t,s)} take the ${item.title.toLowerCase()} honour. ${reason}`;
}
function rlFinaleHTML(s){
 const table=stats(s,s.weeks),half=stats(s,Math.max(1,Math.floor(s.weeks/2))),rounds=playoffRounds(s),champ=playoffChampion(s),leader=table[0],runner=table[1];
 const nm=t=>safe(name(t,s)),gd=r=>r.gf-r.ga,sign=n=>(n>=0?'+':'')+n,place=n=>`${n}${ordinalSuffix(n)}`;
 const games=[];for(let w=1;w<=s.weeks;w++)fixtures(s,w).forEach(([a,b],i)=>{const score=s.results[w]?.[i];if(score)games.push({a,b,score,w,total:score[0]+score[1],margin:Math.abs(score[0]-score[1])})});
 const finalRound=rounds[rounds.length-1],final=finalRound?.matches?.find(m=>m.score),highest=[...games].sort((a,b)=>b.total-a.total)[0];
 const close=games.filter(g=>g.margin===1).length,champRow=table.find(r=>r.t===champ),champSeed=table.findIndex(r=>r.t===champ)+1;
 const duel=(a,b,score,tag)=>`<div class="news-scorecard"><span class="news-score-team">${icon(a)}<b>${nm(a)}</b></span><strong class="news-score">${score[0]}<span>–</span>${score[1]}</strong><span class="news-score-team">${icon(b)}<b>${nm(b)}</b></span>${tag?`<small>${safe(tag)}</small>`:''}</div>`;
 const headline=champ&&champ!==leader.t?'TWO TITLES. TWO CHAMPIONS. ONE SEASON.':`${nm(leader.t).toUpperCase()} COMPLETE THE JOB`;
 const race=leader.w===runner.w?`${nm(leader.t)} and ${nm(runner.t)} ended the regular season level on ${leader.w} victories. ${gd(leader)>gd(runner)?`Goal difference made the decisive separation: ${sign(gd(leader))} for ${nm(leader.t)}, compared with ${sign(gd(runner))} for ${nm(runner.t)}.`:`The saved standings put ${nm(leader.t)} first; the teams' goal differences were ${sign(gd(leader))} and ${sign(gd(runner))}.`}`:`${nm(leader.t)} topped the standings with ${leader.w} victories, ${leader.w-runner.w} clear of ${nm(runner.t)}. Their goal differences were ${sign(gd(leader))} and ${sign(gd(runner))} respectively.`;
 const halfway=half[0].t===leader.t?`${nm(leader.t)} were also top at halfway and remained ahead at the finish.`:`${nm(half[0].t)} led at halfway, but ${nm(leader.t)} emerged on top after ${s.weeks} weeks.`;
 const champMatches=rounds.flatMap((round,i)=>round.matches.filter(m=>m.score&&(m.a===champ||m.b===champ)).map(m=>({m,round:round.title,i})));
 const champJourney=champMatches.map(({m,round,i})=>{const opp=m.a===champ?m.b:m.a,forGoals=m.a===champ?m.score[0]:m.score[1],against=m.a===champ?m.score[1]:m.score[0];return `<div class="news-journey-step"><span class="news-round-tag">${safe(round)}</span><div>${icon(champ)}<b>${nm(champ)}</b><strong>${forGoals}–${against}</strong>${icon(opp)}<b>${nm(opp)}</b></div><small>${i===rounds.length-1?'Championship secured':i===rounds.length-2?'Final place secured':'Semifinal place secured'}</small></div>`}).join('');
 const leadChanges=[];let previousLeader=null;for(let w=1;w<=s.weeks;w++){const top=stats(s,w)[0]?.t;if(top!==undefined&&top!==previousLeader){if(previousLeader!==null)leadChanges.push({w,t:top});previousLeader=top;}}
 const closeFinishes=games.filter(g=>g.margin===1).sort((a,b)=>b.total-a.total||b.w-a.w).slice(0,3);
 const biggest=[...games].sort((a,b)=>b.margin-a.margin||b.total-a.total)[0];
 const moments=`<div class="news-moments"><p>The league leadership changed hands ${leadChanges.length} time${leadChanges.length===1?'':'s'} after the opening week.${leadChanges.length?` Among the changes: ${leadChanges.slice(-5).map(x=>`${nm(x.t)} moved top after Week ${x.w}`).join('; ')}.`:''}</p>${biggest?`<p><strong>Largest victory:</strong> ${nm(biggest.a)} ${biggest.score[0]}–${biggest.score[1]} ${nm(biggest.b)} in Week ${biggest.w}, a ${biggest.margin}-goal margin.</p>`:''}${closeFinishes.map(g=>`<p><strong>Close contest, Week ${g.w}:</strong> ${nm(g.a)} ${g.score[0]}–${g.score[1]} ${nm(g.b)}. ${g.total} goals were scored, with a single goal separating the teams.</p>`).join('')}</div>`;
 const stories=table.map((r,i)=>{
  const mid=half.findIndex(z=>z.t===r.t)+1,delta=mid-(i+1),qual=i<s.playoffCount,late=(r.form||[]).slice(-5).filter(x=>x==='W').length;
  const heading=r.t===champ?'CHAMPIONSHIP WINNERS':i===0?'LEAGUE TITLE WINNERS':i===1?'TITLE CHALLENGERS':i===s.playoffCount?'JUST MISSED OUT':i===9?'BOTTOM OF THE TABLE':qual?'PLAYOFF QUALIFIERS':'LOOKING TO REBUILD';
  let story=r.t===champ?`Their ${place(i+1)}-place league finish earned a knockout opportunity; ${champMatches.length} playoff victories later, they had the Championship trophy.`:i===0?`Their ${r.w} wins and ${sign(gd(r))} goal difference put them at the summit of the regular-season table.`:i===1?`They finished ${r.w}–${r.l}, keeping pressure on the leaders${leader.w===r.w?' right to the final tie-breaker':''}.`:i===s.playoffCount?`They ended one position outside the playoff cut-off, with ${r.w} victories.`:i===9?`The campaign ended in tenth, with ${r.w} victories and ${r.ga} goals conceded.`:qual?`Their ${place(i+1)}-place finish secured a Championship berth after ${s.weeks} regular-season matches.`:`A ${place(i+1)}-place finish left them outside the Championship places.`;
  const played=rounds.flatMap((round,j)=>round.matches.filter(m=>m.score&&(m.a===r.t||m.b===r.t)).map(m=>({m,j})));
  const playoffWin=played.filter(({m})=>(m.score[0]>m.score[1]?m.a:m.b)===r.t);
  const playoffLoss=played.find(({m})=>(m.score[0]>m.score[1]?m.a:m.b)!==r.t);
  const lastLoss=playoffLoss;
  if(r.t===champ&&played.length){
   const path=played.map(({m,j})=>{const opp=m.a===r.t?m.b:m.a;const f=m.a===r.t?m.score[0]:m.score[1],against=m.a===r.t?m.score[1]:m.score[0];return `${nm(opp)} (${f}–${against}, ${safe(rounds[j].title)})`;});
   story+=` They overcame ${path.join('; ')}. The final victory secured the Championship after ${played.length} consecutive knockout wins.`;
  }else if(played.length){
   if(playoffWin.length){const wins=playoffWin.map(({m,j})=>{const opp=m.a===r.t?m.b:m.a;const f=m.a===r.t?m.score[0]:m.score[1],against=m.a===r.t?m.score[1]:m.score[0];return `${nm(opp)} ${f}–${against} in the ${safe(rounds[j].title)}`});story+=` Their playoff campaign included a victory over ${wins.join(' and ')}.`;}
   if(lastLoss){const m=lastLoss.m,opp=m.a===r.t?m.b:m.a,forGoals=m.a===r.t?m.score[0]:m.score[1],against=m.a===r.t?m.score[1]:m.score[0];story+=` They were eliminated by ${nm(opp)} in the ${safe(rounds[lastLoss.j].title)}, losing ${forGoals}–${against}.`;}
  }
  if(i===1&&leader.w===r.w)story+=` Equal on wins with ${nm(leader.t)}, they missed the League Title on goal difference (${sign(gd(r))} against ${sign(gd(leader))}).`;
  if(delta>=2)story+=` At halfway they were ${place(mid)}; by the final whistle they had climbed ${delta} places to ${place(i+1)}.`;
  else if(delta<=-2)story+=` A slide of ${-delta} places from ${place(mid)} at halfway left them ${place(i+1)}.`;
  else if(mid===i+1)story+=` Their finishing position matched their halfway ranking of ${place(mid)}.`;
  const seasonResults=games.filter(g=>g.a===r.t||g.b===r.t);
  const best=seasonResults.filter(g=>(g.a===r.t?g.score[0]>g.score[1]:g.score[1]>g.score[0])).sort((a,b)=>b.margin-a.margin||b.total-a.total)[0];
  const worst=seasonResults.filter(g=>(g.a===r.t?g.score[0]<g.score[1]:g.score[1]<g.score[0])).sort((a,b)=>b.margin-a.margin||b.total-a.total)[0];
  if(best){const opp=best.a===r.t?best.b:best.a,fg=best.a===r.t?best.score[0]:best.score[1],ag=best.a===r.t?best.score[1]:best.score[0];story+=` One standout league result was their ${fg}–${ag} win against ${nm(opp)} in Week ${best.w}.`;}
  if(worst){const opp=worst.a===r.t?worst.b:worst.a,fg=worst.a===r.t?worst.score[0]:worst.score[1],ag=worst.a===r.t?worst.score[1]:worst.score[0];story+=` Their heaviest defeat came against ${nm(opp)} (${fg}–${ag}, Week ${worst.w}).`;}
  story+=` They scored ${r.gf} and conceded ${r.ga} goals across ${s.weeks} league matches, with ${late} wins in their last five.`;
  return `<article class="news-team-card"><div class="news-team-top">${icon(r.t)}<div><span>${heading}</span><h4>${i+1}. ${nm(r.t)}</h4></div></div><div class="news-team-record">${r.w}W · ${r.l}L <span>GD ${sign(gd(r))}</span></div><p>${story}</p></article>`;
 }).join('');
 return `<div class="finale-broadcast"><header class="news-hero"><div class="news-kicker">SEASON ${s.id} · THE FINAL WHISTLE · SPECIAL REPORT</div><h2>${headline}</h2><p>${nm(leader.t)} take the League Title${champ?`; ${nm(champ)} lift the Championship`:''}. The title race, turning points, knockout drama and ten individual club stories from a completed season.</p><div class="news-hero-trophies"><div class="news-trophy"><span>🥇 LEAGUE CHAMPIONS</span>${icon(leader.t)}<strong>${nm(leader.t)}</strong><small>${leader.w}–${leader.l} · GD ${sign(gd(leader))}</small></div><div class="news-trophy"><span>🏆 CHAMPIONSHIP WINNERS</span>${champ?icon(champ):''}<strong>${champ?nm(champ):'Not decided'}</strong><small>${champ?`${place(champSeed)} seed · ${champMatches.length} playoff wins`:'Awaiting result'}</small></div></div></header>
 <section class="news-feature"><div class="news-section-kicker">01 / THE LEAGUE TITLE RACE</div><h3>The battle for first place</h3><p>${race}</p><p>${halfway} ${nm(table[2].t)} rounded out the top three with ${table[2].w} wins.</p><div class="news-stat-strip"><span><b>${leader.w}</b>Champion's wins</span><span><b>${sign(gd(leader))}</b>Champion's GD</span><span><b>${sign(gd(runner))}</b>Runner-up GD</span></div></section>
 <section class="news-feature news-feature-highlight"><div class="news-section-kicker">02 / THE CHAMPIONSHIP</div><h3>${champ?`${nm(champ)}'${name(champ,s).endsWith('s')?'':'s'} road to glory`:'The road to the Championship'}</h3>${champ?`<p>${nm(champ)} entered the knockouts from ${place(champSeed)} place with a ${champRow.w}–${champRow.l} league record. ${champ===leader.t?'They completed the double by also winning the Championship.':`They completed a ${champMatches.length}-match Championship winning run, defeating ${final?nm(final.a===champ?final.b:final.a):'their final opponent'} ${final?(final.a===champ?final.score[0]:final.score[1])+'–'+(final.a===champ?final.score[1]:final.score[0]):''} in the final. Every knockout match ended in victory.`}</p>`:''}${final?`<div class="news-final-label">THE CHAMPIONSHIP FINAL</div>${duel(final.a,final.b,final.score,'Championship Final')}`:''}<div class="news-journey">${champJourney}</div></section>
 <section class="news-feature"><div class="news-section-kicker">03 / DEFINING MOMENTS</div><h3>The results that shaped the season</h3>${moments}</section>
 <section class="news-feature"><div class="news-section-kicker">04 / THE ENTIRE LEAGUE</div><h3>Ten teams. Ten campaigns.</h3><div class="news-team-grid">${stories}</div></section>
 <section class="news-feature"><div class="news-section-kicker">05 / SEASON IN NUMBERS</div><h3>The results behind the headlines</h3><div class="news-stat-strip"><span><b>${games.length}</b>League matches</span><span><b>${close}</b>One-goal games</span><span><b>${highest?.total??0}</b>Most goals in a match</span></div>${highest?`<p class="news-record-match">Highest-scoring league match: <strong>${nm(highest.a)} ${highest.score[0]}–${highest.score[1]} ${nm(highest.b)}</strong>, Week ${highest.w}.</p>`:''}</section><footer class="news-footnote">All stories are based on saved season results. No unrecorded match events are assumed.</footer></div><button onclick="changeWeek(1)">Continue to Week ${s.weeks+playoffWeekCount(s)+2} — Awards ▶</button>`;
}
// v1.0.4: Top 6 semifinals reseed after both opening-round results are known. Saved results only count for their exact matchup.
function playoffRounds(s){
 if(latest(s)!==s.weeks)return [];
 const seeds=stats(s,s.weeks).map(x=>x.t),saved=Array.isArray(s.playoffs)?s.playoffs:[];
 const result=(round,index,a,b)=>{const old=saved[round]?.[index];const valid=old&&old.a===a&&old.b===b&&Array.isArray(old.score)&&old.score.length===2&&old.score.every(x=>Number.isSafeInteger(x)&&x>=0)&&old.score[0]!==old.score[1];return {a,b,score:valid?old.score:null,winner:valid?(old.score[0]>old.score[1]?a:b):null}};
 if(s.playoffCount===4){const semi=[result(0,0,seeds[0],seeds[3]),result(0,1,seeds[1],seeds[2])];return [{title:'Semifinals',matches:semi},{title:'Championship Final',matches:[result(1,0,semi[0].winner,semi[1].winner)]}];}
 const quarter=[result(0,0,seeds[2],seeds[5]),result(0,1,seeds[3],seeds[4])];
 // Fixed bracket: QF #4/#5 advances to #1; QF #3/#6 advances to #2.
 const legacyFinal=Array.isArray(saved[2])&&saved[2][0]?.score&&s.playoffBracketVersion!==211;
 const winners=quarter.map(m=>m.winner);
 const lowest=winners.every(Boolean)?winners.reduce((a,b)=>seeds.indexOf(a)>seeds.indexOf(b)?a:b):null;
 const other=lowest?winners.find(t=>t!==lowest):null;
 const semi=legacyFinal?[result(1,0,seeds[0],lowest),result(1,1,seeds[1],other)]:[result(1,0,seeds[0],quarter[1].winner),result(1,1,seeds[1],quarter[0].winner)];
 return [{title:'Quarterfinals',matches:quarter},{title:'Semifinals',matches:semi},{title:'Championship Final',matches:[result(2,0,semi[0].winner,semi[1].winner)]}];
}
function playoffChampion(s){const r=playoffRounds(s);return r.length?r[r.length-1].matches[0].winner:null}
function playoffMatchHtml(s,m,r,i,enabled,seedMap){
 const team=(t,score,side)=>`<div class="bracket-team ${m.winner===t?'bracket-winner':''} ${!t?'bracket-tbd':''}"><span class="bracket-seed">${t?'#'+(seedMap[t]||'?'):'·'}</span>${t?icon(t):'<span class="bracket-placeholder">?</span>'}<span class="bracket-name">${t?safe(name(t,s)):'Winner TBD'}</span><span class="bracket-score">${score??'–'}</span></div>`;
 return `<div class="bracket-match ${m.winner?'bracket-decided':''}" aria-label="Playoff match">${team(m.a,m.score?.[0],0)}${team(m.b,m.score?.[1],1)}${enabled?`<div class="bracket-entry"><input aria-label="First team score" id="po_${r}_${i}_a" type="number" min="0" step="1" placeholder="0" value="${m.score?.[0]??''}"><span>–</span><input aria-label="Second team score" id="po_${r}_${i}_b" type="number" min="0" step="1" placeholder="0" value="${m.score?.[1]??''}"><button onclick="savePlayoff(${r},${i})">${m.score?'Update':'Save'}</button></div>`:''}</div>`;
}
function showRecordNotice(messages){if(!messages.length)return;const el=document.createElement('div');el.className='record-toast';el.setAttribute('role','status');el.innerHTML=`<strong>New career record!</strong><p>${messages.slice(0,3).map(safe).join('<br>')}</p><button onclick="this.parentElement.remove()">Dismiss</button>`;document.body.appendChild(el);setTimeout(()=>el.remove(),14000)}
function recordMilestones(s,w){if(w!==s.weeks||latest(s)!==s.weeks)return [];const earlier=db.seasons.filter(x=>x!==s&&x.id<s.id&&latest(x)===x.weeks),prior={w:0,l:0,gf:0,ga:0};for(const x of earlier)for(const r of stats(x,x.weeks))for(const k of Object.keys(prior))prior[k]=Math.max(prior[k],r[k]);const results=[];for(const r of stats(s,s.weeks))for(const [k,label] of [['w','league wins'],['l','league losses'],['gf','league goals scored'],['ga','league goals conceded']])if(r[k]>prior[k]&&earlier.length)results.push(`${name(r.t,s)}: ${r[k]} ${label} in Season ${s.id}`);return results}
function renderPlayoffWeek(s,w){
 const r=w-s.weeks-1,rounds=playoffRounds(s),round=rounds[r],holder=$('playoffPanel');
 $('weekTitle').textContent=`Week ${w}`;$('fixtureSectionTitle').textContent='🏆 Championship Bracket';
 $('fixtures').innerHTML='<div id="mobilePlayoffBracket" aria-label="Championship bracket"></div>';
 $('saveWeek').classList.add('hidden');$('weekInfo').textContent='Enter playoff scores directly in the bracket above. Use the week arrows to move between rounds and regular-season fixtures.';
 $('playerEntry').innerHTML='';$('fixtureEditor').classList.add('hidden');
 const editButton=$('fixtureEditor').previousElementSibling;if(editButton)editButton.classList.add('hidden');
 $('standingsTitle').classList.add('hidden');$('standings').classList.add('hidden');holder.classList.add('hidden');
 renderPlayoffs(s,r);
}
function renderPlayoffs(s,onlyRound=null){
 const holder=onlyRound!==null?$('mobilePlayoffBracket'):$('playoffPanel');if(!holder||latest(s)!==s.weeks)return;
 const rounds=playoffRounds(s),seedMap=Object.fromEntries(stats(s,s.weeks).map((x,i)=>[x.t,i+1]));
 // Historical navigation must never reveal results from later playoff weeks.
 const visibleRound=onlyRound===null?rounds.length-1:onlyRound;
 // The two highest seeds have already earned their semifinal places before
 // quarterfinal week. Keep those names visible without leaking later results.
 const reveal=(m,r,i)=>{
  if(r<=visibleRound)return m;
  if(s.playoffCount===6&&r===1)return {...m,a:i===0?stats(s,s.weeks)[0].t:stats(s,s.weeks)[1].t,b:null,score:null,winner:null};
  return {...m,a:null,b:null,score:null,winner:null};
 };
 const displayRounds=rounds.map((round,r)=>({...round,matches:round.matches.map((m,i)=>reveal(m,r,i))}));
 const priorDone=r=>rounds.slice(0,r).every(round=>round.matches.every(m=>m.winner));
 const cols=displayRounds.map((round,r)=>{
  // Order the displayed quarterfinals by their ACTUAL saved semifinal feeder.
  // Seasons 1–3 may retain historical reseeded results; don't rewrite those scores.
  const qfToTop=s.playoffCount===6&&r===0&&rounds[1]?.matches?.[0]?.b===round.matches[0]?.winner&&!!round.matches[0]?.winner;
  const displayOrder=(s.playoffCount===6&&r===0)?(qfToTop?[0,1]:[1,0]):round.matches.map((_,i)=>i);
  const games=displayOrder.map(i=>{const m=round.matches[i];return playoffMatchHtml(s,m,r,i,r===onlyRound&&priorDone(r)&&!!(m.a&&m.b),seedMap)}).join('');
  return `<section class="bracket-stage ${r===onlyRound?'bracket-current':''}" aria-label="${safe(round.title)}"><h3>${safe(round.title)}</h3><div class="bracket-stage-games">${games}</div></section>`;
 }).join('<div class="bracket-connector" aria-hidden="true"><span></span></div>');
 const byes=s.playoffCount===6?`<div class="bracket-byes">${stats(s,s.weeks).slice(0,2).map((t,i)=>`<div class="bracket-bye">${icon(t.t)} #${i+1} ${safe(name(t.t,s))} · semifinal bye</div>`).join('')}</div>`:'';
 const champ=visibleRound===rounds.length-1?displayRounds.at(-1).matches[0].winner:null;
 holder.innerHTML=`<div class="bracket-heading">${onlyRound===null?'<h2>🏆 Championship Bracket</h2>':''}<p class="muted">${onlyRound===null?'Completed playoff journey':`Week ${s.weeks+onlyRound+1} · ${safe(rounds[onlyRound].title)}`} · All rounds connected</p></div>${byes}<div class="bracket-fit">${cols}</div>`+(champ?`<div class="champion-banner">🏆 CHAMPIONS · ${icon(champ)} ${safe(name(champ,s))}<p><button onclick="showPage('awards')">View season awards</button> <button onclick="startNewCareerSeason()">Set up next season</button></p></div>`:'');
}

function savePlayoff(r,i){let s=season(),rounds=playoffRounds(s),m=rounds[r]?.matches[i];if(!rounds.slice(0,r).every(x=>x.matches.every(m=>m.winner)))return;if(!m?.a||!m?.b)return;
 const rawA=$(`po_${r}_${i}_a`).value.trim(),rawB=$(`po_${r}_${i}_b`).value.trim(),a=rawA===''?'0':rawA,b=rawB===''?'0':rawB;if(!/^\d+$/.test(a)||!/^\d+$/.test(b)||Number(a)===Number(b)||!Number.isSafeInteger(Number(a))||!Number.isSafeInteger(Number(b))){alert('Enter valid non-tied whole-number scores. Blank means 0; 0–0 is not allowed.');return}
 // A correction to an earlier round invalidates all subsequent rounds.
 if(m.score&&m.score[0]===Number(a)&&m.score[1]===Number(b))return;
 if(m.score&&(!confirm('Change this playoff result? All later playoff rounds will be reset.')))return;
 s.playoffBracketVersion=211;s.playoffs ||= [];s.playoffs[r] ||= [];s.playoffs[r][i]={a:m.a,b:m.b,score:[Number(a),Number(b)]};
 if(m.score){s.playoffs=s.playoffs.slice(0,r+1)}
 const oldChamp=s.champion;s.champion=playoffChampion(s);persist();render();if(!oldChamp&&s.champion){rlWeeklyMilestonePopups(s,s.weeks+playoffWeekCount(s));const champName=name(s.champion,s),prior=db.seasons.filter(x=>x.id<s.id&&playoffChampion(x)&&playoffChampion(x)===s.champion).length,others=db.seasons.filter(x=>x.id<s.id&&playoffChampion(x)).reduce((acc,x)=>{const k=playoffChampion(x);acc[k]=(acc[k]||0)+1;return acc},{}),max=Math.max(0,...Object.values(others));if(prior+1>max&&max>0)showRecordNotice([`${champName} set a new championship record with ${prior+1} titles`])}
}
function resetPlayoffs(s){s.playoffs=[];s.champion=null}

function roster(s){return [s.humanName.trim()||'Human player',...s.botNames.slice(0,s.mode-1)]}
function renderPlayerEntry(s,w,locked){let custom=fixtures(s,w).findIndex(pair=>pair.includes('Custom'));if(custom<0){$('playerEntry').innerHTML='';return}let names=roster(s),stored=s.playerStats[w]||{};$('playerEntry').innerHTML=`<h3>Your team's match stats <span class="muted">(optional)</span></h3><div class="statgrid"><span class="muted">Player</span>${['Goals','Assists','Saves','Shots'].map(x=>`<label>${x}</label>`).join('')}</div>`+names.map((p,i)=>`<div class="statgrid"><span class="playername">${safe(p)}</span>${['goals','assists','saves','shots'].map(k=>`<input id="ps_${i}_${k}" aria-label="${safe(p)} ${k}" type="number" min="0" step="1" placeholder="—" value="${stored[i]?.[k]??''}" ${locked?'disabled':''}>`).join('')}</div>`).join('')}
function showFixtureEditor(){editing=true;let s=season(),w=selectedWeek,el=$('fixtureEditor');el.classList.remove('hidden');el.innerHTML=`<div class="notice"><strong>Edit Week ${w} fixtures</strong><p class="muted">Every team must appear exactly once. Changing a completed fixture clears its old scores and invalidates later odds.</p>${fixtures(s,w).map(([a,b],i)=>`<div class="fixtureedit"><select id="fa${i}">${teams(s).map(t=>`<option value="${safe(t)}" ${a===t?'selected':''}>${safe(name(t,s))}</option>`).join('')}</select><select id="fb${i}">${teams(s).map(t=>`<option value="${safe(t)}" ${b===t?'selected':''}>${safe(name(t,s))}</option>`).join('')}</select></div>`).join('')}<div class="row"><button onclick="saveFixtureEdit()">Save fixture changes</button><button onclick="editing=false;render()">Cancel</button></div></div>`}
function saveFixtureEdit(){let s=season(),w=selectedWeek,pairs=Array.from({length:5},(_,i)=>[$('fa'+i).value,$('fb'+i).value]);let used=pairs.flat();if(new Set(used).size!==10||teams(s).some(t=>!used.includes(t))){alert('Every team must play exactly once each week.');return}for(const pair of pairs)if(pair[1]==='Custom')pair.reverse();if(JSON.stringify(fixtures(s,w))===JSON.stringify(pairs)){editing=false;render();return}if(s.results[w]&&!confirm('This week already has results. Changing its fixtures will clear this week and all later scores and odds. Continue?'))return;if(w<=latest(s)){for(let i=w;i<=s.weeks;i++){delete s.results[i];delete s.playerStats[i];delete s.odds[i]}}else for(let i=w;i<=s.weeks;i++)delete s.odds[i];resetPlayoffs(s);s.fixtures[w]=pairs;editing=false;persist();render()}
function collectPlayerStats(s,w,score){let custom=fixtures(s,w).findIndex(pair=>pair.includes('Custom'));if(custom<0)return {};let result={},sum=0,filled=0;for(let i=0;i<s.mode;i++){let obj={},any=false;for(const k of ['goals','shots','saves','assists']){let val=$(`ps_${i}_${k}`).value.trim();if(val!==''){if(!/^\d+$/.test(val))throw Error('Player stats must be nonnegative whole numbers.');obj[k]=Number(val);any=true}}if(any){if(obj.goals!==undefined&&obj.shots!==undefined&&obj.shots<obj.goals)throw Error('A player cannot have fewer shots than goals.');result[i]=obj;filled++;sum+=obj.goals||0}}let teamGoals=fixtures(s,w)[custom][0]==='Custom'?score[custom][0]:score[custom][1];if(filled===s.mode&&Object.values(result).every(o=>o.goals!==undefined)&&sum!==teamGoals)throw Error(`Player goals add up to ${sum}, but your team scored ${teamGoals}.`);return result}
function saveResults(){if(rl211HuntGuard())return;let s=season(),w=selectedWeek;if(w>latest(s)+1||worker)return;let scores=[];for(let i=0;i<5;i++){let a=$('a'+i).value.trim(),b=$('b'+i).value.trim();a=a===''?'0':a;b=b===''?'0':b;if(!/^\d+$/.test(a)||!/^\d+$/.test(b)||!Number.isSafeInteger(Number(a))||!Number.isSafeInteger(Number(b))||Number(a)===Number(b)){alert('Enter valid non-tied scores for all five matches. Blank means 0; 0–0 is not allowed.');return}scores.push([Number(a),Number(b)])}let ps;try{ps=collectPlayerStats(s,w,scores)}catch(e){alert(e.message);return}if(w<=latest(s)&&!confirm('Correct this week? Odds for this and later weeks will be cleared, and need recalculating.'))return;if(w<=latest(s))resetPlayoffs(s);s.results[w]=scores;s.playerStats[w]=ps;const newRecordNews=recordMilestones(s,w);Object.keys(s.odds).forEach(k=>{if(Number(k)>=w)delete s.odds[k]});persist();if(latest(s)===s.weeks&&w===s.weeks)selectedWeek=s.weeks+1;render();if(newRecordNews.length)showRecordNotice(newRecordNews);rlWeeklyMilestonePopups(s,w);simulate(s,w)}
function careerEvidence(s){
 const past=db.seasons.filter(x=>x!==s&&Number(x.id)<Number(s.id));
 const evidence={};
 for(const old of past){
  const age=Math.max(0,Number(s.id)-Number(old.id)-1),recency=Math.pow(.65,age);
  const oldTeams=new Set(teams(old));
  for(const t of teams(s)){
   if(!oldTeams.has(t))continue;
   const r=stats(old,latest(old)).find(x=>x.t===t);if(!r)continue;
   const n=r.w+r.l;if(!n)continue;
   const weight=recency*Math.min(1,n/18);
   const e=evidence[t]||(evidence[t]={w:0,l:0,gf:0,ga:0,n:0});
   // Cap historical influence to prevent a long past season dominating the present.
   e.w+=weight*r.w/n*12;e.l+=weight*r.l/n*12;
   e.gf+=weight*r.gf/n*12;e.ga+=weight*r.ga/n*12;e.n+=weight*12;
  }
 }
 return evidence;
}
function simulate(s,w,onDone=null){if(worker)worker.terminate();const runs=simulationCount();let data={teams:teams(s),games:schedule(s),baseline:stats(s,w),w,runs,playoffCount:s.playoffCount,history:careerEvidence(s)};worker=new Worker('./sim-worker.js');$('simBox').classList.remove('hidden');$('simProgress').max=runs;$('simProgress').value=0;$('simStatus').textContent=`Starting ${runs.toLocaleString()} simulations…`;$('saveWeek').disabled=true;worker.onmessage=e=>{if(e.data.progress){$('simProgress').value=e.data.progress;$('simStatus').textContent=`${e.data.progress.toLocaleString()} / ${runs.toLocaleString()} simulations`}if(e.data.done){if(s.odds[w]){s.oddsArchive=s.oddsArchive||{};(s.oddsArchive[w]||(s.oddsArchive[w]=[])).push(s.odds[w]);}s.odds[w]={week:w,runs,modelVersion:e.data.modelVersion||1,rows:e.data.rows};persist();worker.terminate();worker=null;$('simBox').classList.add('hidden');render();if(onDone)onDone()}};worker.onerror=e=>{alert('Simulation failed: '+e.message);worker.terminate();worker=null;$('simBox').classList.add('hidden');render()};worker.postMessage(data)}
// v0.8.8: opt-in testing tools. Normal match entry is untouched.
let testBatchRunning=false,testBatchCancelled=false;
function testingToolsHTML(){const s=season(),left=s.weeks-latest(s);return `<h3>Testing Tools — Auto-Simulation</h3><p class="muted">For testing only. Generates match scores and estimated individual player statistics and calculates the existing Monte Carlo odds after each week. Your manual results remain untouched.</p><p class="muted">${left} regular-season weeks remaining. A full run can take time because it saves an odds snapshot for each week.</p><div class="row"><button ${testBatchRunning||!left?'disabled':''} onclick="startTestBatch(1)">Simulate next week</button><button ${testBatchRunning||!left?'disabled':''} onclick="startTestBatch(5)">Simulate 5 weeks</button><button ${testBatchRunning||!left?'disabled':''} onclick="startTestBatch(${left})">Simulate to playoffs</button><button ${testBatchRunning||!!worker||!!playoffChampion(s)?'disabled':''} onclick="simulateEntireSeason()">Simulate entire season (including playoffs)</button></div>${testBatchRunning?'<button onclick="testBatchCancelled=true">Stop after current week</button>':''}<p class="muted">Export a JSON backup before running tests. Testing scores are saved to the active career and cannot be undone automatically.</p>`}
// v0.8.9: testing-only generator shares the v4 forecast strength priors and scoring assumptions.
function testStrength(s,w){
 const rows=stats(s,w), history=careerEvidence(s), power={},attack={},defense={};
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 for(const x of rows){
  const t=x.t,h=history[t]||{w:0,l:0,gf:0,ga:0,n:0},n=x.w+x.l;
  const historical=((h.w||0)+10)/((h.w||0)+(h.l||0)+20);
  const current=(x.w+10)/(n+20);
  const blend=clamp(n/(n+18),0,.82);
  const prob=(1-blend)*historical+blend*current;
  const form=(x.form||[]).slice(-5).reduce((v,r)=>v+(r==='W'?1:-1),0)/5;
  power[t]=Math.log(prob/(1-prob))+.10*form*blend;
  const weight=Math.min(10,h.n||0);
  attack[t]=Math.log((x.gf+(h.n?h.gf/h.n*weight:0)+2.4*12)/(n+weight+12)/2.4);
  defense[t]=Math.log((x.ga+(h.n?h.ga/h.n*weight:0)+2.4*12)/(n+weight+12)/2.4);
 }
 return {power,attack,defense};
}
function testPoisson(mean){let L=Math.exp(-mean),p=1,k=0;do{k++;p*=Math.random()}while(p>L&&k<30);return k-1}
function testScore(a,b,ratings){
 const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
 const diff=ratings.power[a]-ratings.power[b];
 const ma=clamp(2.4*Math.exp(.20*diff+.17*(ratings.attack[a]-ratings.defense[b])),.65,5.4);
 const mb=clamp(2.4*Math.exp(-.20*diff+.17*(ratings.attack[b]-ratings.defense[a])),.65,5.4);
 let x=testPoisson(ma),y=testPoisson(mb);
 if(x===y){const chance=clamp(1/(1+Math.exp(-.85*diff)),.07,.93);if(Math.random()<chance)x++;else y++}
 return [x,y];
}
// v0.9.4: complete remaining regular season and every unplayed playoff matchup.
function simulateRemainingPlayoffs(s){
 if(latest(s)!==s.weeks)return;
 let count=0;
 while(!playoffChampion(s)&&count<8){
  const rounds=playoffRounds(s);let pending=null;
  for(let r=0;r<rounds.length&&!pending;r++)for(let i=0;i<rounds[r].matches.length;i++){
   const m=rounds[r].matches[i];if(m.a&&m.b&&!m.winner){pending={r,i,m};break}
  }
  if(!pending)break;
  const {r,i,m}=pending;
  const ratings=testStrength(s,s.weeks);
  const score=testScore(m.a,m.b,ratings);
  s.playoffs ||= [];s.playoffs[r] ||= [];
  s.playoffs[r][i]={a:m.a,b:m.b,score};
  rl212AssignPlayoffStats(s,s.weeks+r+1,score,m);
  count++;
 }
 const oldChamp=s.champion;s.champion=playoffChampion(s);persist();render();if(!oldChamp&&s.champion){rlWeeklyMilestonePopups(s,s.weeks+playoffWeekCount(s));const champName=name(s.champion,s),prior=db.seasons.filter(x=>x.id<s.id&&playoffChampion(x)&&playoffChampion(x)===s.champion).length,others=db.seasons.filter(x=>x.id<s.id&&playoffChampion(x)).reduce((acc,x)=>{const k=playoffChampion(x);acc[k]=(acc[k]||0)+1;return acc},{}),max=Math.max(0,...Object.values(others));if(prior+1>max&&max>0)showRecordNotice([`${champName} set a new championship record with ${prior+1} titles`])}
 if(s.champion){alert(`Season ${s.id} completed! Champion: ${name(s.champion,s)}. The playoff bracket and awards are ready.`)}
 else alert('Regular season completed, but the playoff bracket needs attention.');
}
function simulateEntireSeason(){
 const s=season();if(worker||testBatchRunning||playoffChampion(s))return;
 if(!confirm('TESTING ONLY: Simulate every remaining regular-season match AND all unplayed playoff matches, crowning a champion?\n\nThis changes your active career permanently. Export a JSON backup first. Existing completed playoff matches will be preserved.'))return;
 const remaining=s.weeks-latest(s);
 if(remaining>0){
  // Reuse the existing week-by-week simulation without a second confirmation.
  testBatchRunning=true;testBatchCancelled=false;
  let done=0;
  const next=()=>{
   if(testBatchCancelled||done>=remaining||latest(s)>=s.weeks){
    const cancelled=testBatchCancelled;testBatchRunning=false;testBatchCancelled=false;renderOther();
    if(!cancelled)simulateRemainingPlayoffs(s);return;
   }
   const w=latest(s)+1,ratings=testStrength(s,w-1);
   s.results[w]=fixtures(s,w).map(([a,b])=>testScore(a,b,ratings));
   rl212AssignPlayerStats(s,w);delete s.odds[w];persist();selectedWeek=Math.min(s.weeks,w+1);done++;render();
   simulate(s,w,()=>{if(currentPage==='settings')renderOther();next()});
  };next();
 }else simulateRemainingPlayoffs(s);
}
function startTestBatch(count,onFinished=null){const s=season(),remaining=s.weeks-latest(s);if(worker||testBatchRunning||remaining<=0)return;count=Math.min(Math.max(1,Math.floor(count)),remaining);if(!confirm(`TESTING ONLY: Generate scores for ${count} week${count===1?'':'s'} and calculate Monte Carlo odds after every week?\n\nThis changes your active career. Export a backup first if you need to preserve it.`))return;testBatchRunning=true;testBatchCancelled=false;let done=0;const next=()=>{if(testBatchCancelled||done>=count||latest(s)>=s.weeks){const cancelled=testBatchCancelled;testBatchRunning=false;testBatchCancelled=false;renderOther();if(!cancelled&&onFinished)onFinished();return}const w=latest(s)+1,ratings=testStrength(s,w-1);s.results[w]=fixtures(s,w).map(([a,b])=>testScore(a,b,ratings));rl212AssignPlayerStats(s,w);delete s.odds[w];persist();selectedWeek=Math.min(s.weeks,w+1);done++;render();simulate(s,w,()=>{if(currentPage==='settings')renderOther();next()})};next()}

// v0.9.0 calibration lab: isolated Web Worker; never writes to the career database.
let calibrationWorker=null,calibrationReport=null,calibrationProgress=0,calibrationTotal=0,calibrationStarted=0,calibrationLastRuns=100;
function calibrationHTML(){
 const s=season(),pre=s.odds?.[0]?.rows||[];
 const options=[10,25,50,100,250,500,1000].map(n=>`<option value="${n}" ${n===calibrationLastRuns?'selected':''}>${n.toLocaleString()} independent seasons</option>`).join('');
 let report='';
 if(calibrationReport){
  const r=calibrationReport,fmt=x=>Number(x).toFixed(2)+'%';
  const metrics=[['Title','title','predTitle'],['Top '+r.playoffCount,'top','predTop'],['Championship','champ','predChamp']];
  const summary=metrics.map(([label,obs,pred])=>{const valid=r.rows.filter(x=>x[pred]!=null);if(!valid.length)return `<div><strong>${label}:</strong> no Week 0 prediction available</div>`;const mae=valid.reduce((sum,x)=>sum+Math.abs(x[obs]-x[pred]),0)/valid.length;const max=Math.max(...valid.map(x=>Math.abs(x[obs]-x[pred])));const caution=max>Math.max(5,2.5*Math.sqrt(100*25/r.runs));return `<div style="margin:7px 0"><strong>${label}:</strong> mean absolute error <strong>${mae.toFixed(2)} pp</strong> · largest difference ${max.toFixed(2)} pp · <span style="color:${caution?'#f59e0b':'#4ade80'}">${caution?'Worth investigating':'No large discrepancy detected'}</span></div>`}).join('');
  report=`<div class="notice"><h4>Automatic calibration summary</h4><p class="muted">Differences are percentage points (pp). This checks agreement with the testing simulator, not real-world predictive accuracy.</p>${summary}<p class="muted">Small samples vary randomly. Repeated large differences across independent batches are more concerning than a single outlier.</p></div><h4>Calibration results — ${r.runs} independent seasons</h4><p class="muted">Each run starts from Week 0 with identical career evidence. These are independent simulated seasons, not additional career seasons. The observed rates vary randomly.</p><div style="overflow-x:auto"><table><thead><tr><th>Team</th><th>Predicted title</th><th>Observed title</th><th>Difference</th><th>Predicted Top ${r.playoffCount}</th><th>Observed Top ${r.playoffCount}</th><th>Predicted champion</th><th>Observed champion</th></tr></thead><tbody>${r.rows.map(x=>`<tr><td>${safe(name(x.t,s))}</td><td>${x.predTitle==null?'—':fmt(x.predTitle)}</td><td>${fmt(x.title)}</td><td>${x.predTitle==null?'—':((x.title-x.predTitle)>=0?'+':'')+(x.title-x.predTitle).toFixed(2)+' pp'}</td><td>${x.predTop==null?'—':fmt(x.predTop)}</td><td>${fmt(x.top)}</td><td>${x.predChamp==null?'—':fmt(x.predChamp)}</td><td>${fmt(x.champ)}</td></tr>`).join('')}</tbody></table></div><p class="muted">Prediction columns use the saved Week 0 Monte Carlo snapshot, if available. A single batch is a diagnostic, not proof of calibration.</p>`;
 }
 return `<h3>Monte Carlo Calibration Lab</h3><p class="muted">TESTING ONLY: Simulate multiple independent complete seasons from this season's Week 0 career strength. Results stay in memory and never modify your career, standings, fixtures, or saved odds.</p><label>Batch size <select id="calibrationRuns" ${calibrationWorker?'disabled':''}>${options}</select></label><div class="row"><button ${calibrationWorker?'disabled':''} onclick="startCalibration()">Run calibration</button>${calibrationWorker?'<button onclick="stopCalibration()">Cancel</button>':''}</div><p id="calibrationStatus" class="muted" aria-live="polite">${calibrationWorker?`Running: ${calibrationProgress.toLocaleString()} / ${calibrationTotal.toLocaleString()} (${Math.floor(calibrationProgress/calibrationTotal*100)}%)`:'Ready — no career changes will be made.'}</p><progress id="calibrationBar" max="${calibrationTotal||1}" value="${calibrationProgress}" style="width:100%;${calibrationWorker?'':'display:none'}"></progress><p id="calibrationTime" class="muted">${calibrationWorker?'Elapsed: 0s':''}</p>${report}`;
}
function startCalibration(){
 if(calibrationWorker||worker||testBatchRunning)return;
 const s=season(),runs=Number($('calibrationRuns')?.value)||10;
 if(![10,25,50,100,250,500,1000].includes(runs))return;
 const pre=s.odds?.[0]?.rows||[];
 if(!pre.length&&!confirm('There is no saved Week 0 forecast to compare against. Run the independent season test anyway?'))return;
 calibrationReport=null;calibrationProgress=0;calibrationTotal=runs;calibrationLastRuns=runs;calibrationStarted=Date.now();
 calibrationWorker=new Worker('./calibration-worker.js');
 const w=calibrationWorker;
 w.onmessage=e=>{
  if(e.data.progress!=null){calibrationProgress=e.data.progress;const label=$('calibrationStatus'),bar=$('calibrationBar'),time=$('calibrationTime');if(label)label.textContent=`${calibrationProgress.toLocaleString()} / ${runs.toLocaleString()} independent seasons (${Math.floor(calibrationProgress/runs*100)}%)`;if(bar)bar.value=calibrationProgress;if(time)time.textContent=`Elapsed: ${Math.round((Date.now()-calibrationStarted)/1000)}s`;}
  if(e.data.done){calibrationReport=e.data;calibrationWorker.terminate();calibrationWorker=null;renderOther();}
 };
 w.onerror=e=>{alert('Calibration failed: '+e.message);stopCalibration()};
 w.postMessage({runs,teams:teams(s),games:schedule(s),history:careerEvidence(s),baseline:stats(s,0),playoffCount:s.playoffCount,preseason:pre});
 renderOther();
}
function stopCalibration(){if(calibrationWorker){calibrationWorker.terminate();calibrationWorker=null;renderOther();const label=$('calibrationStatus');if(label)label.textContent=`Cancelled after ${calibrationProgress.toLocaleString()} of ${calibrationTotal.toLocaleString()} seasons. Career unchanged.`}}

// v0.9.3: synthetic career scenarios, separate from the saved career and Calibration Lab.
let scenarioWorker=null,scenarioReport=null,scenarioProgress=0,scenarioTotal=0,scenarioStarted=0,scenarioLastRuns=100;
function scenarioHTML(){
 const options=[30,100,250,500,1000].map(n=>`<option value="${n}" ${n===scenarioLastRuns?'selected':''}>${n.toLocaleString()} different scenarios</option>`).join('');
 let report='';
 if(scenarioReport){
  const r=scenarioReport,z=r.stats,p=x=>Number(x).toFixed(2)+'%';
  report=`<div class="notice"><h4>Career Scenario Lab — ${r.runs.toLocaleString()} different starting histories</h4><p class="muted">Each scenario generates new synthetic career histories, new team strengths, and new match outcomes. The model is tested across balanced, mixed and polarized leagues. This is a stress test of model behaviour, not validation against real Rocket League results.</p><table><tbody><tr><th>Underdog match wins</th><td>${p(z.upsetRate)}</td></tr><tr><th>Preseason bottom-${10-r.playoffCount} teams reaching Top ${r.playoffCount}</th><td>${z.bottomQualificationRate.toFixed(2)} per season</td></tr><tr><th>Playoff spots taken by preseason bottom-${10-r.playoffCount}</th><td>${p(z.qualificationSlotsTakenByBottom)}</td></tr><tr><th>Preseason bottom-${10-r.playoffCount} team wins championship</th><td>${p(z.bottomChampionRate)}</td></tr><tr><th>Preseason #1 wins regular-season title</th><td>${p(z.favoriteTitleRate)}</td></tr><tr><th>Preseason #1 wins championship</th><td>${p(z.favoriteChampionRate)}</td></tr><tr><th>Average finishing-rank movement</th><td>${z.averageRankMovement.toFixed(2)} places per team</td></tr></tbody></table><p class="muted">Underdog means the lower-ranked team according to the scenario's simulated career-history strength, not a guaranteed low probability. These results describe the model's unpredictability; they do not establish whether it is realistic.</p></div>`;
 }
 return `<h3>Career Scenario Lab</h3><p class="muted">TESTING ONLY: Unlike Calibration Lab, every run creates different synthetic career histories and team strengths. It never changes your save, fixtures, standings or odds. Scenarios use this season's schedule and playoff format.</p><label>Scenarios <select id="scenarioRuns" ${scenarioWorker?'disabled':''}>${options}</select></label><div class="row"><button ${scenarioWorker?'disabled':''} onclick="startScenarioLab()">Run scenarios</button>${scenarioWorker?'<button onclick="stopScenarioLab()">Cancel</button>':''}</div><p id="scenarioStatus" class="muted" aria-live="polite">${scenarioWorker?`Running: ${scenarioProgress} / ${scenarioTotal} (${Math.floor(100*scenarioProgress/scenarioTotal)}%)`:'Ready — your career will not change.'}</p><progress id="scenarioBar" max="${scenarioTotal||1}" value="${scenarioProgress}" style="width:100%;${scenarioWorker?'':'display:none'}"></progress><p id="scenarioTime" class="muted">${scenarioWorker?'Running…':''}</p>${report}`;
}
function startScenarioLab(){
 if(scenarioWorker||calibrationWorker||worker||testBatchRunning)return;
 const s=season(),runs=Number($('scenarioRuns')?.value)||100;
 if(![30,100,250,500,1000].includes(runs))return;
 scenarioReport=null;scenarioProgress=0;scenarioTotal=runs;scenarioLastRuns=runs;scenarioStarted=Date.now();
 scenarioWorker=new Worker('./scenario-worker.js');const w=scenarioWorker;
 w.onmessage=e=>{
  if(e.data.progress!=null){scenarioProgress=e.data.progress;const label=$('scenarioStatus'),bar=$('scenarioBar'),time=$('scenarioTime');if(label)label.textContent=`${scenarioProgress.toLocaleString()} / ${runs.toLocaleString()} different scenarios (${Math.floor(scenarioProgress/runs*100)}%)`;if(bar)bar.value=scenarioProgress;if(time)time.textContent=`Elapsed: ${Math.round((Date.now()-scenarioStarted)/1000)}s`;}
  if(e.data.done){scenarioReport=e.data;w.terminate();scenarioWorker=null;renderOther();}
 };
 w.onerror=e=>{alert('Scenario test failed: '+e.message);stopScenarioLab()};
 w.postMessage({runs,teams:teams(s),games:schedule(s),playoffCount:s.playoffCount});renderOther();
}
function stopScenarioLab(){if(scenarioWorker){scenarioWorker.terminate();scenarioWorker=null;renderOther();const el=$('scenarioStatus');if(el)el.textContent=`Cancelled after ${scenarioProgress} of ${scenarioTotal} scenarios. Career unchanged.`}}

function recalculateSelectedOdds(){const s=season();const w=selectedWeek===0?0:Math.min(selectedWeek,latest(s));if(worker)return;if(!confirm(`Recalculate Week ${w} with the v4 career-aware model using ${simulationCount().toLocaleString()} simulations? The previous snapshot will be archived in your save.`))return;simulate(s,w)}
function cancelSimulation(){if(worker){worker.terminate();worker=null;$('simBox').classList.add('hidden');render()}}
function renderOdds(s){
let modes=[['title','Title'],['top6',`Top ${s.playoffCount}`],['elim','Elimination'],['champ','Championship'],['bye','Top 2'],['history','History']];
$('oddsTabs').innerHTML=modes.map(([id,l])=>`<button class="${id===oddsMode?'active':''}" onclick="setOddsMode('${id}')">${l}</button>`).join('');
let odds=s.odds[selectedWeek],rows=odds?.rows||[];
if(selectedWeek>s.weeks&&latest(s)===s.weeks){
 const base=s.odds[s.weeks]||s.odds[Math.max(0,...Object.keys(s.odds).map(Number).filter(n=>n<=s.weeks))];
 if(base?.rows){
  const rounds=playoffRounds(s),through=Math.min(rounds.length-1,selectedWeek-s.weeks-1),eliminated=new Set(stats(s,s.weeks).slice(s.playoffCount).map(x=>x.t));
  for(let i=0;i<=through;i++)for(const m of rounds[i].matches)if(m.winner&&m.a&&m.b)eliminated.add(m.winner===m.a?m.b:m.a);
  const finalists=rounds[rounds.length-1].matches[0],champ=through===rounds.length-1?finalists.winner:null;
  const weights=base.rows.map(x=>({t:x.t,p:champ?(x.t===champ?1:0):(eliminated.has(x.t)?0:Math.max(.000001,Number(x.champ)||0))}));
  const total=weights.reduce((a,x)=>a+x.p,0);
  rows=base.rows.map(x=>({...x,champ:total?100*weights.find(v=>v.t===x.t).p/total:0}));
  odds={week:selectedWeek,runs:base.runs||0,modelVersion:base.modelVersion,rows};
 }
}
$('chart').classList.toggle('hidden',oddsMode!=='history');
if(oddsMode==='history'){renderOddsHistory(s);return}
if(!rows.length){$('oddsBody').innerHTML='<p class="notice">No saved odds for this week. Preseason odds are generated when a new season starts; historical odds are only shown if genuinely saved.</p>';$('oddsNote').textContent='';return}
let list=rows.map(x=>({...x,value:oddsMode==='elim'?100-x.top6:x[oddsMode]}));
list.sort((a,b)=>b.value-a.value);
const previous=s.odds[Number(odds.week)-1]||(selectedWeek>s.weeks?s.odds[s.weeks]:null);const comparable=previous&&previous.modelVersion===odds.modelVersion;
const oldMap=comparable?Object.fromEntries(previous.rows.map(x=>[x.t,x])):{};
const title=oddsMode==='title'?'Regular-season 1st place':oddsMode==='champ'?'Playoff championship':oddsMode==='top6'?`Finish in top ${s.playoffCount}`:oddsMode==='bye'?'Finish in top 2':'Miss the playoffs';
$('oddsBody').innerHTML=`<p class="muted odds-explain">${title} · estimated chance</p>${selectedWeek>s.weeks?'<span class="muted">Playoff championship odds adjust after each saved knockout result.</span>':`<button onclick="recalculateSelectedOdds()" ${worker?'disabled':''}>Recalculate Week ${odds.week} with latest model</button>`}<div class="odds-bars">`+list.map((x,i)=>{const old=oldMap[x.t],oldValue=old?(oddsMode==='elim'?100-old.top6:old[oddsMode]):null;const delta=oldValue==null?'':`<span class="odds-delta ${x.value>=oldValue?'odds-up':'odds-down'}">${x.value>=oldValue?'+':''}${(x.value-oldValue).toFixed(2)} pp</span>`;return `<div class="odds-entry"><div class="odds-entry-head"><span class="odds-team">${icon(x.t)} ${safe(name(x.t,s))}</span><span class="odds-number">${x.value.toFixed(2)}% ${delta}</span></div><div class="odds-track"><div class="odds-fill" style="background:${ODDS_COLORS[oddsMode]};width:${Math.max(0,Math.min(100,x.value))}%"></div></div></div>`}).join('')+'</div>';
const total=list.reduce((n,x)=>n+x.value,0),expected=oddsMode==='title'||oddsMode==='champ'?100:oddsMode==='top6'?100*s.playoffCount:oddsMode==='bye'?200:100*(10-s.playoffCount);
const check=Math.abs(total-expected)<.15?'✓':'⚠';
$('oddsNote').textContent=`${selectedWeek>s.weeks?'Conditional playoff update from saved league odds · ':''}Week ${odds.week} · ${odds.runs.toLocaleString()} simulations · ${check} Total ${total.toFixed(2)}% (expected ${expected}%)${odds.modelVersion===4?' · v4 career-aware model':odds.modelVersion===3?' · v3 model':odds.modelVersion===2?' · v2 model — recalculate for comparison':' · Legacy model — recalculate for comparison'}`;
}
function isClinched(s,t,w,st){let me=st.find(x=>x.t===t);if(!me)return false;return st.filter(x=>x.t!==t&&x.w+s.weeks-w>=me.w).length<s.playoffCount}
function historySnapshots(s){return Object.values(s.odds).filter(o=>o?.rows&&Number.isFinite(Number(o.week))&&o.week<=Math.max(selectedWeek,latest(s))).sort((a,b)=>a.week-b.week)}
function historyColor(s,t){return HISTORY_COLORS[teams(s).indexOf(t)%HISTORY_COLORS.length]}
function setHistoryWeek(w){historyWeek=Number(w);renderOddsHistory(season())}
function stepHistoryWeek(delta){const ws=historySnapshots(season()).map(o=>o.week);if(!ws.length)return;let i=ws.indexOf(historyWeek);if(i<0)i=ws.length-1;historyWeek=ws[Math.max(0,Math.min(ws.length-1,i+delta))];renderOddsHistory(season())}
function toggleHistoryScale(){historyFullScale=!historyFullScale;renderOddsHistory(season())}
function historyPointer(ev){const c=$('chart'),s=season(),snaps=historySnapshots(s);if(!snaps.length)return;const rect=c.getBoundingClientRect(),p=(ev.clientX-rect.left)/rect.width;const min=snaps[0].week,max=snaps[snaps.length-1].week;const target=min+Math.max(0,Math.min(1,(p*c.width-51)/(c.width-68)))*(max-min);historyWeek=snaps.reduce((best,o)=>Math.abs(o.week-target)<Math.abs(best-target)?o.week:best,snaps[0].week);renderOddsHistory(s)}
function renderOddsHistory(s){
 const saved=historySnapshots(s),metricNames={champ:'Championship',title:'Title',bye:'Top 2',top6:`Top ${s.playoffCount}`,elim:'Elimination'};
 const ts=teams(s);if(!historyTeams.length)historyTeams=ts.slice(0,3);
 const buttons=Object.entries(metricNames).map(([k,v])=>`<button class="${historyMetric===k?'active':''}" style="${historyMetric===k?'border-color:'+ODDS_COLORS[k]+';color:'+ODDS_COLORS[k]:''}" onclick="setHistoryMetric('${k}')">${v}</button>`).join('');
 const checks=ts.map(t=>`<button class="history-team ${historyTeams.includes(t)?'selected':''}" onclick="toggleHistoryTeam('${t}')"><span class="history-dot" style="background:${historyColor(s,t)}"></span>${historyTeams.includes(t)?'✓ ':''}${safe(name(t,s))}</button>`).join('');
 const latestSnapshot=saved[saved.length-1],prev=saved[saved.length-2];let movers='';
 if(latestSnapshot&&prev){const old=Object.fromEntries(prev.rows.map(r=>[r.t,r]));const moves=latestSnapshot.rows.filter(r=>old[r.t]).map(r=>({t:r.t,d:oddsValue(r,historyMetric)-oddsValue(old[r.t],historyMetric)})).sort((a,b)=>b.d-a.d);const entry=m=>`<span>${safe(name(m.t,s))} <strong style="color:${m.d>=0?'#7ce6ad':'#ffa3a3'}">${m.d>=0?'+':''}${m.d.toFixed(2)} pp</strong></span>`;movers=`<div class="history-movers"><div><strong>Biggest gain</strong>${moves.length?entry(moves[0]):''}</div><div><strong>Biggest drop</strong>${moves.length?entry(moves[moves.length-1]):''}</div></div>`}
 if(saved.length&&!saved.some(o=>o.week===historyWeek))historyWeek=saved[saved.length-1].week;
 const active=saved.find(o=>o.week===historyWeek),idx=saved.findIndex(o=>o.week===historyWeek);
 const values=active?historyTeams.map(t=>({t,row:active.rows.find(r=>r.t===t)})).filter(x=>x.row):[];
 const details=values.map(x=>`<div class="history-value"><span><span class="history-dot" style="background:${historyColor(s,x.t)}"></span>${safe(name(x.t,s))}</span><strong>${oddsValue(x.row,historyMetric).toFixed(2)}%</strong></div>`).join('');
 $('oddsBody').innerHTML=`<p class="muted">Saved Monte Carlo forecasts · select a category and teams to compare.</p><div class="tabs history-metrics">${buttons}</div><div class="history-teams">${checks}</div>${movers}<p class="muted">${saved.length} saved weekly snapshot${saved.length===1?'':'s'} · through Week ${saved.length?saved[saved.length-1].week:0}</p><div class="history-inspector"><div class="row between"><strong>Inspect Week ${historyWeek??'—'}</strong><button onclick="toggleHistoryScale()">${historyFullScale?'Auto scale':'0–100% scale'}</button></div><div class="row history-week-controls"><button onclick="stepHistoryWeek(-1)" ${idx<=0?'disabled':''}>◀ Previous</button><input aria-label="Inspect forecast week" type="range" min="0" max="${Math.max(0,saved.length-1)}" value="${Math.max(0,idx)}" oninput="setHistoryWeek(${JSON.stringify(saved.map(o=>o.week))}[Number(this.value)])" ${saved.length<2?'disabled':''}><button onclick="stepHistoryWeek(1)" ${idx>=saved.length-1?'disabled':''}>Next ▶</button></div><div class="history-values">${details||'<span class="muted">Select teams to see their exact percentages.</span>'}</div></div>`;
 $('oddsNote').textContent='Tap or drag on the chart to inspect a week. Points use original saved forecasts; old weeks are never recalculated.';
 drawChart(s);
}
function drawChart(s){
 const c=$('chart'),ctx=c.getContext('2d'),W=c.width,H=c.height,L=51,R=17,T=25,B=38;
 ctx.clearRect(0,0,W,H);ctx.font='13px sans-serif';ctx.textAlign='left';
 const snaps=historySnapshots(s);if(!snaps.length){ctx.fillStyle='#aabbd0';ctx.fillText('No saved forecasts yet',L+30,H/2);return}
 const visible=snaps.flatMap(o=>historyTeams.map(t=>o.rows.find(r=>r.t===t)).filter(Boolean).map(r=>oddsValue(r,historyMetric)));
 const lo=historyFullScale?0:Math.max(0,Math.floor((Math.min(...visible,0+100)-7)/10)*10),hi=historyFullScale?100:Math.min(100,Math.max(lo+10,Math.ceil((Math.max(...visible,0)+7)/10)*10));
 const minW=snaps[0].week,maxW=snaps[snaps.length-1].week;
 const x=w=>L+(maxW===minW?.5:(w-minW)/(maxW-minW))*(W-L-R),y=v=>T+(H-T-B)*(1-(v-lo)/(hi-lo));
 for(let i=0;i<=4;i++){const v=lo+(hi-lo)*i/4,yy=y(v);ctx.strokeStyle='#35475e';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(L,yy);ctx.lineTo(W-R,yy);ctx.stroke();ctx.fillStyle='#aabbd0';ctx.fillText(v.toFixed(v%1?1:0)+'%',4,yy+4)}
 const count=Math.min(6,Math.max(1,maxW-minW));for(let i=0;i<=count;i++){const w=Math.round(minW+(maxW-minW)*i/count);ctx.fillStyle='#aabbd0';ctx.fillText('W'+w,Math.max(3,Math.min(W-38,x(w)-12)),H-10)}
 historyTeams.forEach(t=>{const pts=snaps.map(o=>({w:o.week,row:o.rows.find(r=>r.t===t)})).filter(q=>q.row).map(q=>({w:q.w,v:oddsValue(q.row,historyMetric)}));if(!pts.length)return;const color=historyColor(s,t);ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();pts.forEach((q,i)=>i?ctx.lineTo(x(q.w),y(q.v)):ctx.moveTo(x(q.w),y(q.v)));ctx.stroke();pts.forEach(q=>{ctx.beginPath();ctx.arc(x(q.w),y(q.v),q.w===historyWeek?6:4,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();if(q.w===historyWeek){ctx.lineWidth=2;ctx.strokeStyle='#fff';ctx.stroke()}})});
 if(historyWeek!=null){ctx.strokeStyle='#e2e8f0';ctx.lineWidth=1;ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(x(historyWeek),T);ctx.lineTo(x(historyWeek),H-B);ctx.stroke();ctx.setLineDash([])}
}

function playerTotals(s,w){let arr=roster(s).map((n,i)=>({name:n,index:i,goals:0,shots:0,saves:0,assists:0,matches:0}));for(let k=1;k<=Math.min(w,s.weeks);k++){let p=s.playerStats[k];if(!p)continue;arr.forEach((x,i)=>{let v=p[i];if(v){x.matches++;for(let key of ['goals','shots','saves','assists'])x[key]+=Number(v[key]||0)}})}return arr.sort((a,b)=>b[sortStat]-a[sortStat]||a.index-b.index)}
function predictionReportHTML(s){if(latest(s)<s.weeks)return '<p class="muted">Prediction accuracy report unlocks when the regular season finishes.</p>';const final=stats(s,s.weeks),last=s.odds[s.weeks]?.rows,pre=s.odds[0]?.rows;const source=pre?.length?pre:last;if(!source?.length)return '<p class="muted">No saved forecasts available for an accuracy report.</p>';const actual=final[0]?.t;const fav=source.slice().sort((a,b)=>b.title-a.title)[0];const predictedRank=source.slice().sort((a,b)=>b.title-a.title).findIndex(r=>r.t===actual)+1;const champ=playoffChampion(s);const championOdds=champ?source.find(r=>r.t===champ)?.champ:null;return `<div class="notice"><h3>Prediction review · Season ${s.id}</h3><p>Forecast: ${pre?.length?'Preseason':'Last saved week'} · ${source===pre?'Week 0':'Week '+s.weeks}</p><p>Regular-season winner: <strong>${safe(name(actual,s))}</strong> · forecast rank ${predictedRank} of 10</p><p>Preseason title favourite: ${safe(name(fav.t,s))} (${Number(fav.title).toFixed(2)}%)</p>${champ?`<p>Playoff champion: <strong>${safe(name(champ,s))}</strong> · forecast Championship chance ${Number(championOdds||0).toFixed(2)}%</p>`:'<p>Playoffs not finished yet.</p>'}<p class="muted">One season cannot establish statistical calibration. Keep multiple season forecasts to assess accuracy over time.</p></div>`}
function renderOther(){let s=season(),el=$('other');if(currentPage==='milestones'){el.innerHTML=rlMilestonePage();return}if(currentPage==='archive'){el.innerHTML=rlSeasonArchivePage();return}if(currentPage==='news'){el.innerHTML=`<h2>Season ${s.id} News Archive</h2><button onclick="showPage('history')">← Season History</button>`+renderNewsPage(s);return}if(currentPage==='career'){el.innerHTML=rl212CareerPage();rlCompareRender();return}if(currentPage==='awards'){renderAwards(s);return}if(currentPage==='players'){el.innerHTML=rl212StatsPage(s);return}
else if(currentPage==='teams'){el.innerHTML=`<h2>Your custom team</h2>${s!==db.seasons.at(-1)?'<p class="muted">Viewing an archived season: changing the current team name will not rewrite this historical season name.</p>':''}<div class="stack"><label>Team name <input id="customName" value="${safe(db.customName)}"></label><label>Custom logo <input type="file" id="customFile" accept="image/*"></label><button onclick="saveCustom()">Save team</button></div><h2 style="margin-top:24px">Season ${s.id} player roster · ${s.mode}v${s.mode}</h2><label>Season mode <select id="activeMode" onchange="changeActiveMode(this.value)">${[1,2,3,4].map(n=>`<option value="${n}" ${s.mode===n?'selected':''}>${n}v${n}</option>`).join('')}</select></label><p class="muted">Change the mode before entering any results.</p><label>Your player name <input id="humanName" value="${safe(s.humanName)}" placeholder="Type your name"></label><div id="botPicker"></div><button onclick="saveRoster()">Save player roster</button><h2 style="margin-top:24px">AI team logos</h2><p class="muted">All 11 Season Mode logos are bundled locally and load automatically, even offline. You can optionally upload a replacement logo.</p><div id="teamList"></div>`;renderBotPicker();$('teamList').innerHTML=AI.map(t=>`<div class="row">${icon(t)}<strong style="flex:1">${safe(t)}</strong><input aria-label="Logo for ${safe(t)}" type="file" accept="image/*" onchange="saveLogo('${t}',this)" style="max-width:180px"></div>`).join('')}
else if(currentPage==='history'){el.innerHTML='<h2>Season History</h2><button onclick="showPage(&quot;awards&quot;)">View awards</button>'+db.seasons.map((x,i)=>`<div class="notice"><button onclick="db.active=${i};selectedWeek=0;showPage('home')">Season ${x.id}</button> <button onclick="db.active=${i};showPage('news')">News</button> · ${x.mode}v${x.mode} · ${latest(x)}/${x.weeks} weeks ${x.champion?' · Champion: '+safe(name(x.champion,x)):''} · Top ${x.playoffCount}</div>`).join('')+predictionReportHTML(s)}
else{el.innerHTML=`<h2>Backups & Season Settings</h2><p class="muted">Your phone and PC store separate saves. Export a backup before clearing app data or deploying updates.</p><div class="row"><button onclick="exportData()">Export full backup</button><label>Import <input type="file" accept=".json,application/json" onchange="importData(this)"></label></div>${careerSlotsHTML()}${testingToolsHTML()}${calibrationHTML()}${scenarioHTML()}<h3>Career Records Display</h3><label>Season number format <select onchange="saveSeasonFormat(this.value)"><option value="compact" ${seasonFormat()==='compact'?'selected':''}>Compact — S6, S9</option><option value="full" ${seasonFormat()==='full'?'selected':''}>Full — Seasons 6, 9</option></select></label><h3>Simulation settings</h3><p class="muted">Choose how many seasons to simulate when calculating odds. The default is 100,000. Lower counts are faster; higher counts reduce sampling noise. Existing odds snapshots retain their original simulation counts.</p><label>Simulations per calculation <select id="simulationCount" onchange="saveSimulationCount(this.value)">${SIM_CHOICES.map(n=>`<option value="${n}" ${simulationCount()===n?'selected':''}>${n.toLocaleString()}${n===100000?' (default)':''}</option>`).join('')}</select></label><h3>Start another season</h3><p class="muted">Choose exactly nine AI teams and a format. Your earlier seasons remain archived.</p><div class="row"><label>Mode <select id="nextMode">${[1,2,3,4].map(n=>`<option value="${n}" ${s.mode===n?'selected':''}>${n}v${n}</option>`).join('')}</select></label></div><div id="teamPicker">${AI.map(t=>`<label class="row"><input id="pick_${t}" type="checkbox" ${s.ai.includes(t)?'checked':''}>${safe(t)}</label>`).join('')}</div><button onclick="startNewCareerSeason()">Set up next season</button><h3>Restart completely</h3><p class="muted">Erase all local seasons and begin again from Season 1. Export a backup first.</p><button class="danger" onclick="restartAll()">Restart from Season 1</button><p class="muted">Simulation odds are model estimates; mathematical clinching checks are conservative, not exhaustive proofs.</p>`}}
function changeActiveMode(value){let s=season();if(Object.keys(s.results).length){alert("Season mode cannot be changed after results are entered.");renderOther();return}s.mode=Number(value);persist();renderOther()}
function isCustomMate(n){return !!n&&!BOTS.includes(n)}
function teammateOptions(current,others){return `<option value="__custom__" ${isCustomMate(current)?'selected':''}>Custom teammate</option>`+BOTS.map(bot=>`<option value="${safe(bot)}" ${current===bot?'selected':''} ${others.includes(bot)?'disabled':''}>${safe(bot)}</option>`).join('')}
function renderBotPicker(){let s=season(),el=$('botPicker');el.innerHTML=s.botNames.slice(0,s.mode-1).map((n,i)=>`<div class="teammate-picker"><label for="botSelect${i}">Teammate ${i+1}</label><select id="botSelect${i}" onchange="selectBot(${i},this.value)">${teammateOptions(n,s.botNames.slice(0,s.mode-1).filter((_,j)=>j!==i))}</select>${isCustomMate(n)?`<input aria-label="Custom teammate ${i+1} name" value="${safe(n)}" placeholder="Enter teammate name" onchange="setCustomMate(${i},this.value)">`:''}</div>`).join('')}
function setCustomMate(i,v){let s=season(),n=v.trim();if(!n||s.botNames.slice(0,s.mode-1).some((x,j)=>j!==i&&x.toLowerCase()===n.toLowerCase())||n.toLowerCase()===s.humanName.toLowerCase()){alert('Enter a unique teammate name.');renderBotPicker();return}s.botNames[i]=n;persist();renderBotPicker()}
function selectBot(i,bot){let s=season();if(bot==='__custom__'){s.botNames[i]=`Custom player ${i+1}`;persist();renderBotPicker();return}if(!BOTS.includes(bot)||s.botNames.slice(0,s.mode-1).some((x,j)=>j!==i&&x===bot)){renderBotPicker();return}s.botNames[i]=bot;persist();renderBotPicker()}
function setupTeammate(i,v){setup.bots[i]=v==='__custom__'?`Custom player ${i+1}`:v;renderWizard()}
function setupCustomMate(i,v){setup.bots[i]=v;}

function saveRoster(){let s=season(),v=$('humanName').value.trim();if(!v){alert('Enter your player name.');return}if(s.botNames.slice(0,s.mode-1).some(n=>n.toLowerCase()===v.toLowerCase())){alert('Player name cannot duplicate a teammate.');return}if(Object.keys(s.playerStats).length&&!confirm('Changing player names affects how past statistics are labelled. Continue?'))return;s.humanName=v;persist();renderOther();alert('Player roster saved.')}
function fileRead(file,cb){if(!file)return;let reader=new FileReader();reader.onload=()=>cb(reader.result);reader.readAsDataURL(file)}
function saveLogo(t,el){fileRead(el.files[0],data=>{db.logos[t]=data;persist();renderOther()})}
function saveCustom(){db.customName=$('customName').value.trim()||'My Team';if(season()===db.seasons.at(-1))season().customName=db.customName;let f=$('customFile').files[0];if(f)fileRead(f,data=>{db.customLogo=data;persist();renderOther()});else{persist();renderOther()}}
function legacyStartNextSeason(){let chosen=AI.filter(t=>$('pick_'+t)?.checked);if(chosen.length!==9){alert('Select exactly nine AI teams.');return}if(latest(season())<season().weeks){alert('Complete the regular season before starting a new one, or use Restart to start over.');return}if(!confirm('Start a new season and preserve the current season in history?'))return;db.seasons.push(makeSeason(chosen,Number($('nextMode').value)));db.active=db.seasons.length-1;selectedWeek=0;persist();showPage('home')}
function restartAll(){if(rl211HuntGuard())return;if(!confirm('Delete ALL local seasons, results, statistics and odds? This cannot be undone without a backup.'))return;let word=prompt('Type RESTART to confirm permanent deletion:');if(word!=='RESTART')return;cancelSimulation();rl211PrepareReplacement();db.seasons=[];db.active=0;persist();openMenu()}
function exportData(){let blob=new Blob([JSON.stringify(db)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='rocket-league-tracker-v2.0.12-career-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000)}
function importData(el){if(rl211HuntGuard())return;let f=el.files[0];if(!f)return;f.text().then(t=>{let v=JSON.parse(t);if(!Array.isArray(v.seasons)||!v.seasons.length||!Array.isArray(v.seasons[0]?.ai))throw Error('Invalid backup');if(confirm('Replace all local data with this backup?')){rl211PrepareReplacement();db=v;db.logos ||= {};db.seasons.forEach(initSeason);rlRecalculateHistoricalMatches();
selectedWeek=Math.max(0,Math.min(db.seasons[db.active]?.weeks||36,latest(db.seasons[db.active]||db.seasons[0])+1));db.active=Math.max(0,Math.min(db.active||0,db.seasons.length-1));persist();closeWizard();showPage('home')}}).catch(e=>alert('Import failed: '+e.message))}

function showWizard(){ $('wizard').classList.remove('hidden');$('mainApp').classList.add('hidden') }
function closeWizard(){ $('wizard').classList.add('hidden');$('mainApp').classList.remove('hidden') }
function openMenu(){setup=null;setupStep=0;showWizard();$('wizard').innerHTML=`<div class="panel intro"><h1>🏆 ROCKET LEAGUE<br>SEASON TRACKER</h1><p class="muted">v2.1.4 · Career Record Book & Streak Badges</p><button onclick="beginSetup()">＋ New Save</button>${db.seasons.length?'<button onclick="closeWizard();showPage(\'home\')">Load Existing Career</button>':''}<button onclick="$('loadFile').click()">Import Save File</button><input id="loadFile" class="hidden" type="file" accept=".json" onchange="importData(this)"></div>`}
function beginSetup(next=false){if(rl211HuntGuard())return;if(!next&&db.seasons.length&&!confirm('Creating a new save replaces this local career. Export a backup first. Continue?'))return;if(next&&!playoffChampion(season())){alert('Finish the playoffs and crown a champion before starting another season.');return}setup={next,name:next?season().customName:'',human:next?season().humanName:'',mode:next?season().mode:3,bots:next?[...season().botNames]:BOTS.slice(0,3),badge:next?season().badge:'./badges/badge-01.png',ai:next?[...season().ai]:AI.slice(0,9),weeks:next?season().weeks:36,playoffCount:next?season().playoffCount:6,fixtures:{}};setupStep=1;renderWizard()}
function startNewCareerSeason(){beginSetup(true)}
function pickOptions(values,selected){return values.map(v=>`<option value="${safe(v)}" ${String(v)===String(selected)?'selected':''}>${safe(v)}</option>`).join('')}
function renderWizard(){showWizard();const el=$('wizard');let body='';if(setupStep===1){body=`<h2>1 · Create your team</h2><label>Team name<input id="newTeamName" value="${safe(setup.name)}" placeholder="Enter team name" oninput="setup.name=this.value"></label><label>Your player name<input id="newHuman" value="${safe(setup.human)}" placeholder="Enter player name" oninput="setup.human=this.value"></label><label>Game mode<select onchange="setup.mode=Number(this.value);renderWizard()">${pickOptions([1,2,3,4],setup.mode)}</select></label><h3>Teammates</h3>${Array.from({length:setup.mode-1},(_,i)=>`<label>Teammate ${i+1}<select onchange="setupTeammate(${i},this.value)">${teammateOptions(setup.bots[i],setup.bots.slice(0,setup.mode-1).filter((_,j)=>j!==i))}</select></label>${isCustomMate(setup.bots[i])?`<input placeholder="Custom teammate name" value="${safe(setup.bots[i])}" oninput="setupCustomMate(${i},this.value)">`:''}`).join('')}<h3>Choose your badge</h3><div class="badge-gallery">${Array.from({length:21},(_,i)=>{const url=`./badges/badge-${String(i+1).padStart(2,'0')}.png`;return `<button class="badge-choice ${setup.badge===url?'chosen':''}" onclick="setup.badge='${url}';renderWizard()"><img src="${url}" alt="Badge ${i+1}"><small>${i+1}</small></button>`}).join('')}</div><label>Or upload a logo<input type="file" accept="image/*" onchange="fileRead(this.files[0],v=>{setup.badge=v;renderWizard()})"></label>`}
else if(setupStep===2){body=`<h2>2 · Choose league teams</h2><p>Select exactly 9 opponents. Your custom team is the tenth.</p><p id="teamCount">${setup.ai.length}/9 selected</p><div class="league-gallery">${AI.map(t=>`<label class="league-option"><input type="checkbox" ${setup.ai.includes(t)?'checked':''} onchange="toggleLeague('${t}',this.checked)"><img src="${officialLogo(t)}" alt=""><span>${t}</span></label>`).join('')}</div>`}
else if(setupStep===3){body=`<h2>3 · Season settings</h2><label>Regular-season length<select onchange="setup.weeks=Number(this.value);setup.fixtures={}">${[9,18,27,36].map(v=>`<option value="${v}" ${setup.weeks===v?'selected':''}>${v} weeks · ${v*5} matches</option>`).join('')}</select></label><label>Playoff teams<select onchange="setup.playoffCount=Number(this.value)">${[4,6].map(v=>`<option value="${v}" ${setup.playoffCount===v?'selected':''}>Top ${v}</option>`).join('')}</select></label><p class="notice">${setup.playoffCount===4?'Top four: semifinals and final.':'Top six: seeds 1–2 receive byes.'}</p>`}
else if(setupStep===4){if(!Object.keys(setup.fixtures).length)generateSetupFixtures();body=`<h2>4 · Set up fixtures</h2><p>${setup.weeks} weeks · ${setup.weeks*5} games</p><div class="row"><button onclick="generateSetupFixtures();renderWizard()">Regenerate schedule</button><label>Week <select id="setupWeek" onchange="renderSetupMatches(Number(this.value))">${Array.from({length:9},(_,i)=>`<option value="${i+1}">Week ${i+1}</option>`).join('')}</select></label></div><div id="setupMatches"></div><p class="muted">Edit Weeks 1–9 only. The remaining weeks repeat automatically: AI fixtures reverse home/away every nine weeks, while your custom team always stays home. Every team must play once per week.</p>`}
else{body=`<h2>5 · Season preview</h2><p><strong>${safe(setup.name)}</strong> · ${setup.mode}v${setup.mode} · ${setup.weeks} weeks · Top ${setup.playoffCount}</p><p>${safe(setup.human)}${setup.bots.slice(0,setup.mode-1).map(x=>' · '+safe(x)).join('')}</p><p>${setup.ai.map(safe).join(', ')}</p><p class="notice">Confirm to create Season ${setup.next?db.seasons.length+1:1}. Your results begin empty.</p>`}
el.innerHTML=`<div class="panel wizard-card"><div class="muted">${setup.next?'New season':'New save'} · Step ${setupStep}/5</div>${body}<div class="row wizard-actions"><button onclick="setupStep===1?openMenu():(setupStep--,renderWizard())">Back</button><button onclick="nextSetup()">${setupStep===5?'Confirm & Start Season':'Continue →'}</button></div></div>`;if(setupStep===4)renderSetupMatches(1)}
function toggleLeague(t,on){if(on){if(setup.ai.length>=9){renderWizard();return}setup.ai.push(t)}else setup.ai=setup.ai.filter(x=>x!==t);$('teamCount').textContent=`${setup.ai.length}/9 selected`}
function expandSetupFixtures(){
 const base=Array.from({length:9},(_,i)=>setup.fixtures[i+1]);
 if(base.some(matches=>!Array.isArray(matches)||matches.length!==5))return;
 for(let w=10;w<=setup.weeks;w++){
  const reverse=Math.floor((w-1)/9)%2===1;
  setup.fixtures[w]=base[(w-1)%9].map(([a,b])=>{
   const pair=reverse?[b,a]:[a,b];
   return pair[1]==='Custom'?[pair[1],pair[0]]:pair;
  });
 }
 for(const key of Object.keys(setup.fixtures))if(Number(key)>setup.weeks)delete setup.fixtures[key];
}
function generateSetupFixtures(){let a=['Custom',...setup.ai],rounds=[];for(let r=0;r<9;r++){rounds.push(Array.from({length:5},(_,i)=>[a[i],a[9-i]]));a=[a[0],a[9],...a.slice(1,9)]}setup.fixtures={};for(let w=1;w<=9;w++)setup.fixtures[w]=rounds[w-1].map(([x,y])=>y==='Custom'?[y,x]:[x,y]);expandSetupFixtures()}
function updateSetupFixture(w,i,side,value){setup.fixtures[w][i][side]=value;expandSetupFixtures();validateSetupWeek(w)}
function renderSetupMatches(w){
 const holder=$('setupMatches');if(!holder)return;
 const teamNames=['Custom',...setup.ai];
 const options=(value)=>teamNames.map(t=>`<option value="${safe(t)}" ${value===t?'selected':''}>${safe(t==='Custom'?setup.name:t)}</option>`).join('');
 holder.innerHTML=setup.fixtures[w].map(([a,b],i)=>`<div class="setup-fixture-card"><div class="setup-fixture-label">MATCH ${i+1}</div><div class="setup-fixture-teams"><select aria-label="Match ${i+1} first team" onchange="updateSetupFixture(${w},${i},0,this.value)">${options(a)}</select><span class="setup-vs">VS</span><select aria-label="Match ${i+1} second team" onchange="updateSetupFixture(${w},${i},1,this.value)">${options(b)}</select></div></div>`).join('')+'<p id="setupValidity" role="status"></p>';
 validateSetupWeek(w);
}
function validateSetupWeek(w){let a=setup.fixtures[w].flat(),valid=a.length===10&&new Set(a).size===10;$('setupValidity').textContent=valid?'✓ Every team plays once':'⚠ Duplicate or missing teams';return valid}
function nextSetup(){if(setupStep===1){if(!setup.name.trim()||!setup.human.trim()){alert('Enter a team name and player name.');return}if(setup.bots.slice(0,setup.mode-1).some(n=>!n.trim())||new Set(setup.bots.slice(0,setup.mode-1).map(n=>n.trim().toLowerCase())).size!==setup.mode-1||setup.bots.slice(0,setup.mode-1).some(n=>n.trim().toLowerCase()===setup.human.trim().toLowerCase())){alert('Choose unique teammate names.');return}}if(setupStep===2&&setup.ai.length!==9){alert('Select exactly 9 teams.');return}if(setupStep===4){expandSetupFixtures();if(Object.values(setup.fixtures).some(m=>new Set(m.flat()).size!==10)){alert('Fix duplicate teams in your fixtures before continuing.');return}}if(setupStep===4){for(let w=1;w<=9;w++)for(const pair of setup.fixtures[w])if(pair[1]==='Custom')pair.reverse();expandSetupFixtures();}if(setupStep<5){setupStep++;renderWizard();return}const s=makeSeason(setup.ai,setup.mode);s.id=db.seasons.length+1;s.customName=setup.name.trim();s.humanName=setup.human.trim();s.botNames=setup.bots.slice();s.badge=setup.badge;s.weeks=setup.weeks;s.playoffCount=setup.playoffCount;s.fixtures=JSON.parse(JSON.stringify(setup.fixtures));if(!setup.next){rl211PrepareReplacement();db.seasons=[];s.id=1}db.customName=s.customName;db.seasons.push(s);db.active=db.seasons.length-1;selectedWeek=0;persist();closeWizard();showPage('home');simulate(s,0)}


// v0.7.1: automatic, fullscreen ceremony. Timers are presentation-only; saves stay unchanged.
let ceremonyState={season:null,index:0,phase:0};
let ceremonyTimer=null;
function ceremonyCancel(){if(ceremonyTimer!==null){clearTimeout(ceremonyTimer);ceremonyTimer=null}}
function comebackEvidence(s,t){
 const start=Math.max(1,Math.ceil(s.weeks*.25)),finish=stats(s,s.weeks).findIndex(r=>r.t===t)+1;
 let best=null;
 for(let w=start;w<=s.weeks-2;w++){
  const pos=stats(s,w).findIndex(r=>r.t===t)+1;
  const recent=Array.from({length:Math.min(5,w)},(_,i)=>{const week=w-i,j=fixtures(s,week).findIndex(pair=>pair.includes(t)),pair=fixtures(s,week)[j],score=s.results[week]?.[j];return score?(pair[0]===t?score[0]>score[1]:score[1]>score[0]):false});
  const poorWins=recent.filter(Boolean).length;
  const sustained=Array.from({length:Math.min(3,w-start+1)},(_,i)=>stats(s,w-i).findIndex(r=>r.t===t)+1).filter(p=>p>=s.playoffCount+1).length;
  const rise=pos-finish;
  if(rise<=0||!(poorWins<=2||sustained>=2))continue;
  const score=rise*15+(sustained>=2?12:0)+(2-poorWins)*3+Math.min(10,s.weeks-w)/2;
  if(!best||score>best.score)best={t,score,worst:pos,week:w,finish,poorWins,sustained,rise};
 }
 return best;
}
function calculateCeremonyAwards(s){
 const table=stats(s,s.weeks), out=[], games=[];
 for(let w=1;w<=s.weeks;w++)fixtures(s,w).forEach(([a,b],i)=>{const score=s.results[w]?.[i];if(score)games.push({a,b,score,w,margin:Math.abs(score[0]-score[1]),total:score[0]+score[1]})});
 const add=(title,desc,rank,detail,one=false)=>{if(!rank.length)return;const top=rank[0].score;out.push({title,desc,teams:one?[rank[0].t]:rank.filter(x=>x.score===top).map(x=>x.t),detail:detail(rank[0]),nominees:rank.slice(0,4).map(x=>({t:x.t,label:x.label||name(x.t,s)}))})};
 add('BEST ATTACKING TEAM','The highest-scoring team',[...table].map(x=>({t:x.t,score:x.gf})).sort((a,b)=>b.score-a.score),x=>`${x.score} regular-season goals`);
 add('BEST DEFENSIVE TEAM','Fewest goals conceded',[...table].map(x=>({t:x.t,score:-x.ga})).sort((a,b)=>b.score-a.score),x=>`${-x.score} regular-season goals conceded`);
 const victories=games.map(g=>({t:g.score[0]>g.score[1]?g.a:g.b,score:g.margin,label:`${name(g.a,s)} ${g.score[0]}–${g.score[1]} ${name(g.b,s)} · Week ${g.w}`})).sort((a,b)=>b.score-a.score);
 add('BIGGEST VICTORY','The greatest winning margin',victories,x=>`${x.score}-goal winning margin`);
 const prev=db.seasons.filter(x=>x.id<s.id&&latest(x)===x.weeks).sort((a,b)=>b.id-a.id)[0];
 if(prev){const old=stats(prev,prev.weeks),r=table.map((x,i)=>{const j=old.findIndex(y=>y.t===x.t);if(j<0)return null;const oldRow=old[j];const improvement=prev.weeks===s.weeks?(x.w-oldRow.w)*100+(j-i)*10+((x.gf-x.ga)-(oldRow.gf-oldRow.ga)):
   ((x.w/s.weeks-oldRow.w/prev.weeks)*s.weeks*100)+(j-i)*10+(((x.gf-x.ga)/s.weeks-(oldRow.gf-oldRow.ga)/prev.weeks)*s.weeks);return {t:x.t,score:improvement,label:prev.weeks===s.weeks?`${name(x.t,s)} · ${oldRow.w} to ${x.w} wins`:`${name(x.t,s)} · ${oldRow.w}/${prev.weeks} to ${x.w}/${s.weeks} wins`}}).filter(Boolean).sort((a,b)=>b.score-a.score||name(a.t,s).localeCompare(name(b.t,s)));add('MOST IMPROVED TEAM','Progress compared with last season',r,x=>x.label,true)}
 const pre=s.odds?.[0]?.rows||[];
 const spread=pre.length===10?Math.max(...pre.map(x=>Number(x.title)||0))-Math.min(...pre.map(x=>Number(x.title)||0)):0;
 const meaningful=s.id>1&&spread>=2;
 const ranked=meaningful?[...pre].sort((a,b)=>b.title-a.title):[];
 const candidates=table.map((x,i)=>{const finish=i+1,rank=ranked.findIndex(z=>z.t===x.t)+1,gd=x.gf-x.ga,comeback=comebackEvidence(s,x.t),isChamp=playoffChampion(s)===x.t;
  const knockoutWins=playoffRounds(s).flatMap(r=>r.matches).filter(m=>m.score&&(m.score[0]>m.score[1]?m.a:m.b)===x.t).length;
  const surprise=meaningful?(rank-finish)*16+Math.max(0,x.w-s.weeks/2)*2+knockoutWins*9:(comeback?Math.min(32,comeback.rise*5):0)+knockoutWins*13+(isChamp?25:0)+(finish<=s.playoffCount?7:0)+Math.max(0,gd)/15;
  // Preseason is primary; historical context contributes at most a small bonus.
  // A debut club has no previous league appearances; a returning club does.
  const prior=db.seasons.filter(z=>z.id<s.id&&latest(z)===z.weeks).sort((a,b)=>b.id-a.id).slice(0,3);
  const appearances=prior.map((z,age)=>({z,age,row:stats(z,z.weeks).find(r=>r.t===x.t)})).filter(z=>z.row);
  const debut=!db.seasons.some(z=>z.id<s.id&&teams(z).some(t=>t===x.t));
  const historical=appearances.length?appearances.reduce((sum,z)=>{const pos=stats(z.z,z.z.weeks).findIndex(r=>r.t===z.row.t)+1;return sum+(11-pos)/10*[.55,.30,.15][z.age]},0):0;
  const baseDisappointment=meaningful?(finish-rank)*16+Math.max(0,s.weeks/2-x.w)*2:(finish>s.playoffCount?20:0)+Math.max(0,s.weeks/2-x.w)*3+Math.max(0,-gd)/8+(finish>=9?12:0);
  const disappointment=(baseDisappointment>0&&debut?baseDisappointment*.92:baseDisappointment)+Math.min(7,historical*7);
  return {t:x.t,finish,rank,score:surprise,disappointment,label:`${name(x.t,s)} · finished ${finish}`};});
 add('SURPRISE OF THE SEASON','The ultimate underdog story — the team that defied expectations',[...candidates].sort((a,b)=>b.score-a.score||a.finish-b.finish),x=>`Finished ${x.finish}${ordinalSuffix(x.finish)}`,true);
 add('BIGGEST DISAPPOINTMENT','The season that fell furthest short',candidates.map(x=>({...x,score:x.disappointment})).sort((a,b)=>b.score-a.score||b.finish-a.finish),x=>`Finished ${x.finish}${ordinalSuffix(x.finish)}`,true);
 const comebacks=table.map(x=>comebackEvidence(s,x.t)).filter(Boolean).map(x=>({...x,label:`${name(x.t,s)} · ${x.worst}${ordinalSuffix(x.worst)} after Week ${x.week} → ${x.finish}${ordinalSuffix(x.finish)}`})).sort((a,b)=>b.score-a.score||name(a.t,s).localeCompare(name(b.t,s)));if(comebacks.length)add('COMEBACK OF THE SEASON','A sustained recovery after a genuine difficult spell',comebacks,x=>x.label);

 const rounds=playoffRounds(s);rounds.forEach((round,i)=>round.matches.forEach(m=>{if(m.score)games.push({a:m.a,b:m.b,score:m.score,w:s.weeks+i+1,margin:Math.abs(m.score[0]-m.score[1]),total:m.score[0]+m.score[1],playoff:i+1})}));
 const matchRank=games.map(g=>{
  const winner=g.score[0]>g.score[1]?g.a:g.b,loser=winner===g.a?g.b:g.a;
  const high=Math.max(...g.score),low=Math.min(...g.score);
  const before=stats(s,Math.min(s.weeks,Math.max(0,g.w-1)));
  const wr=before.findIndex(z=>z.t===winner),lr=before.findIndex(z=>z.t===loser);
  // Scoreline is the main factor. Close thrillers and exceptional shutouts both qualify.
  const thriller=(g.margin===1?25:g.margin===2?11:0)+Math.min(22,Math.max(0,g.total-3)*3);
  const dominance=Math.max(0,g.margin-2)*5+(low===0?Math.max(0,high-2)*3:0);
  const stakes=g.playoff?(g.playoff===rounds.length?11:g.playoff===rounds.length-1?8:5):0;
  const upset=g.w>=10&&wr>=0&&lr>=0&&wr>lr?Math.min(2,(wr-lr)*.25):0;
  const score=thriller+dominance+stakes+upset;
  return {t:g.a,score,label:`${name(g.a,s)} ${g.score[0]}–${g.score[1]} ${name(g.b,s)} · Week ${g.w}`};
 }).sort((a,b)=>b.score-a.score||a.label.localeCompare(b.label));
 if(matchRank.length){add('MATCH OF THE SEASON','The most memorable result, from any stage of the season',matchRank,x=>x.label,true);const award=out[out.length-1],chosen=games.find(g=>`${name(g.a,s)} ${g.score[0]}–${g.score[1]} ${name(g.b,s)} · Week ${g.w}`===matchRank[0].label);if(chosen)award.teams=[chosen.a,chosen.b]}
 const league=table[0];out.push({title:'LEAGUE TITLE',desc:'Regular-season champions',teams:[league.t],detail:`${league.w} wins · ${league.l} losses · GD ${league.gf-league.ga}`,nominees:[],trophy:true});out.push({title:'CHAMPIONSHIP',desc:'Playoff champions',teams:[playoffChampion(s)],detail:`Season ${s.id} Championship winners`,nominees:[],trophy:true,final:true});return out;
}
// v2.0: preserve a completed season's awards, nominees and their presentation order.
// Older saves are upgraded lazily without rewriting match results or odds snapshots.
function rlRecalculateHistoricalMatches(){
 let count=0;
 for(const x of db.seasons){
  if(!playoffChampion(x))continue;
  const existing=Array.isArray(x.ceremonyArchiveV2)?x.ceremonyArchiveV2:null;
  if(!existing?.length)continue;
  if(x.matchAwardAlgorithmVersion===211)continue;
  const updates=calculateCeremonyAwards(x);
  let changed=false;
  for(const title of ['MATCH OF THE SEASON','MOST IMPROVED TEAM']){
   const replacement=updates.find(a=>a.title===title),idx=existing.findIndex(a=>a.title===title);
   if(replacement&&idx>=0){existing[idx]=replacement;changed=true}
  }
  if(changed){x.matchAwardAlgorithmVersion=211;count++}

 }
 return count;
}
function ceremonyAwards(s){
 if(!playoffChampion(s))return calculateCeremonyAwards(s);
 if(Array.isArray(s.ceremonyArchiveV2)&&s.ceremonyArchiveV2.length){if(s.matchAwardAlgorithmVersion!==211){rlRecalculateHistoricalMatches();persist()}return s.ceremonyArchiveV2;}
 const awards=calculateCeremonyAwards(s);
 const existing=s.awardsNomineeOrders||{};
 for(const award of awards){
  if(!award.nominees?.length)continue;
  const signature=award.nominees.map(n=>`${n.t}:${n.label}`).sort().join('|');
  const saved=existing[award.title];
  if(saved?.signature===signature&&Array.isArray(saved.labels)){
   const pending=[...award.nominees];
   const ordered=saved.labels.map(label=>{const i=pending.findIndex(n=>n.label===label);return i<0?null:pending.splice(i,1)[0]}).filter(Boolean);
   award.nominees=[...ordered,...pending];
  }else{
   for(let i=award.nominees.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[award.nominees[i],award.nominees[j]]=[award.nominees[j],award.nominees[i]];}
  }
 }
 s.ceremonyArchiveV2=awards;s.matchAwardAlgorithmVersion=211;
 persist();
 return awards;
}
function ordinalSuffix(n){return n%100>=11&&n%100<=13?'th':({1:'st',2:'nd',3:'rd'}[n%10]||'th')}
function ceremonyNomineeReason(item,x,s){
 const title=item.title,table=stats(s,s.weeks),row=table.find(r=>r.t===x.t),finish=table.findIndex(r=>r.t===x.t)+1;
 const place=n=>`${n}${ordinalSuffix(n)}`;
 if(title==='MATCH OF THE SEASON'){
  const m=String(x.label||'').match(/^(.*?) (\d+)–(\d+) (.*?) · Week (\d+)$/);
  if(!m)return 'Selected from the recorded season results.';
  const a=m[1],b=m[4],as=+m[2],bs=+m[3],w=+m[5],win=as>bs?a:b,lose=as>bs?b:a,total=as+bs;
  const rounds=playoffRounds(s),idx=w-s.weeks,playoff=idx>0&&idx<=rounds.length;
  const details=[];
  if(playoff){
   if(idx===rounds.length)details.push(`${win} defeated ${lose} ${Math.max(as,bs)}–${Math.min(as,bs)} to win the Championship.`);
   else if(idx===rounds.length-1)details.push(`${win} knocked out ${lose} to reach the Championship Final.`);
   else details.push(`${win} eliminated ${lose} in the opening playoff round.`);
   const table=stats(s,s.weeks),winnerSeed=table.findIndex(r=>name(r.t,s)===win)+1,loserSeed=table.findIndex(r=>name(r.t,s)===lose)+1;
   if(winnerSeed>loserSeed)details.push(`The ${winnerSeed}${ordinalSuffix(winnerSeed)} seed overcame the ${loserSeed}${ordinalSuffix(loserSeed)} seed.`);
  }else{
   details.push(`${win} beat ${lose} ${Math.max(as,bs)}–${Math.min(as,bs)} in Week ${w}.`);
   const before=stats(s,w-1),after=stats(s,w),key=teams(s).find(t=>name(t,s)===win),loserKey=teams(s).find(t=>name(t,s)===lose);
   if(key){const prev=before.findIndex(r=>r.t===key)+1,next=after.findIndex(r=>r.t===key)+1;if(prev>next)details.push(`The victory lifted ${win} from ${place(prev)} to ${place(next)}.`);}
   if(loserKey){const prev=before.findIndex(r=>r.t===loserKey)+1,next=after.findIndex(r=>r.t===loserKey)+1;if(next>prev&&w>=s.weeks*.7)details.push(`${lose} slipped from ${place(prev)} to ${place(next)} during the run-in.`);}
   const winPos=before.findIndex(r=>r.t===key),losePos=before.findIndex(r=>r.t===loserKey);
   if(winPos>losePos+1)details.push(`The result came against a higher-ranked opponent.`);
  }
  if(Math.abs(as-bs)===1)details.push(`Only one goal separated the sides${total>=8?` in a ${total}-goal contest`:''}.`);
  else if(total>=8)details.push(`${total} goals made it a high-scoring encounter.`);
  return details.join(' ');
 }
 if(!row)return '';
 const pre=s.odds?.[0]?.rows||[];
 if(title==='SURPRISE OF THE SEASON'||title==='BIGGEST DISAPPOINTMENT'){
  const spread=pre.length===10?Math.max(...pre.map(z=>Number(z.title)||0))-Math.min(...pre.map(z=>Number(z.title)||0)):0;
  const meaningful=s.id>1&&spread>=2,gd=row.gf-row.ga,qualified=finish<=s.playoffCount;
  if(!meaningful){
   if(title==='SURPRISE OF THE SEASON'){
    const champ=playoffChampion(s)===x.t,comeback=comebackEvidence(s,x.t),wins=playoffRounds(s).flatMap(r=>r.matches).filter(m=>m.score&&(m.score[0]>m.score[1]?m.a:m.b)===x.t).length;
    if(champ)return `${name(x.t,s)} turned a ${place(finish)} league finish into the Championship trophy, winning ${wins} knockout matches. Their playoff breakthrough is the season's clearest underdog achievement.`;
    if(comeback&&comeback.rise>=3)return `From ${place(comeback.worst)} after Week ${comeback.week}, ${name(x.t,s)} recovered ${comeback.rise} places to finish ${place(finish)}. That sustained rise, rather than opening odds, makes their case.`;
    if(wins){const eliminated=playoffRounds(s).flatMap(r=>r.matches).filter(m=>m.score&&(m.score[0]>m.score[1]?m.a:m.b)===x.t).map(m=>name(m.a===x.t?m.b:m.a,s));return `${name(x.t,s)} qualified in ${place(finish)} and eliminated ${eliminated.join(' and ')} before their playoff run ended. That knockout result made their campaign stand out.`;}
    return `Finished ${place(finish)} with ${row.w} wins and a goal difference of ${gd>=0?'+':''}${gd}, earning recognition for the campaign they put together.`;
   }
   const halfway=stats(s,Math.max(1,Math.floor(s.weeks/2))),mid=halfway.findIndex(r=>r.t===x.t)+1;
   if(mid<=s.playoffCount&&finish>s.playoffCount)return `${name(x.t,s)} occupied ${place(mid)} at halfway but fell to ${place(finish)}, losing ${finish-mid} league places and missing the Championship playoffs. The slide from a qualifying position defines their disappointment.`;
   if(mid>=s.playoffCount+2&&finish===s.playoffCount+1)return `After standing ${place(mid)} at halfway, ${name(x.t,s)} recovered to ${place(finish)} but still missed the playoffs by one position. Their late push was not quite enough.`;
   if(finish===10)return `A last-place finish with ${row.w} wins and ${row.ga} goals conceded left ${name(x.t,s)} facing a difficult end to the season.`;
   if(finish===s.playoffCount+1)return `Finished one place short of the playoffs, despite ${row.w} wins. Missing qualification made their season particularly frustrating.`;
   if(gd<=-15)return `Conceded ${row.ga} goals and ended with a ${gd} goal difference, missing the playoffs in ${place(finish)}.`;
   return `A ${place(finish)} finish and ${row.w} wins were not enough to reach the playoffs. Their ${gd>=0?'+':''}${gd} goal difference underlined a challenging campaign.`;
  }
  const rank=[...pre].sort((a,b)=>b.title-a.title).findIndex(z=>z.t===x.t)+1;
  if(title==='SURPRISE OF THE SEASON')return `${name(x.t,s)} defied their ${place(rank)} preseason billing to finish ${place(finish)}. Their ${row.w} victories and ${gd>=0?'+':''}${gd} goal difference tell the story of a campaign that exceeded predictions by ${Math.max(0,rank-finish)} places.`;
  return `${name(x.t,s)} were tipped for ${place(rank)} before the season, yet ended in ${place(finish)} with a ${row.w}–${row.l} record. That gap between expectation and outcome put them in contention for this award.`;
 }
 if(title==='MOST IMPROVED TEAM'){
  const prev=db.seasons.filter(z=>z.id<s.id&&latest(z)===z.weeks).sort((a,b)=>b.id-a.id)[0];if(!prev)return '';
  const old=stats(prev,prev.weeks),oldRank=old.findIndex(z=>z.t===x.t),before=old[oldRank];if(!before)return '';
  const wins=row.w-before.w,rank=oldRank+1-finish,gd=(row.gf-row.ga)-(before.gf-before.ga);
  if(prev.weeks!==s.weeks)return `Win rate ${(100*before.w/prev.weeks).toFixed(1)}% over ${prev.weeks} weeks → ${(100*row.w/s.weeks).toFixed(1)}% over ${s.weeks} weeks; position ${place(oldRank+1)} → ${place(finish)}.`;
  return `Wins ${before.w} → ${row.w} (${wins>=0?'+':''}${wins}); position ${place(oldRank+1)} → ${place(finish)} (${rank>=0?'+':''}${rank} places); goal difference ${gd>=0?'+':''}${gd} compared with last season.`;
 }
 if(title==='COMEBACK OF THE SEASON'){
  const evidence=comebackEvidence(s,x.t);if(!evidence)return 'No qualifying sustained recovery was recorded.';
  const lastFive=row.form.slice(-5).filter(z=>z==='W').length;
  const half=stats(s,Math.floor(s.weeks/2)).findIndex(r=>r.t===x.t)+1;
  const comebackIntro=evidence.poorWins===0?`A winless five-match spell left ${name(x.t,s)} in ${place(evidence.worst)} after Week ${evidence.week}.`:`After a difficult run with only ${evidence.poorWins} wins in their previous five matches, ${name(x.t,s)} stood ${place(evidence.worst)} in Week ${evidence.week}.`;
  const outcome=finish<=2?`They fought all the way back to ${place(finish)}, gaining ${evidence.rise} places and entering the title conversation.`:finish<=s.playoffCount?`A rise of ${evidence.rise} places secured ${place(finish)} and a playoff berth.`:`They recovered ${evidence.rise} places to ${place(finish)}, although a playoff place remained out of reach.`;
  return `${comebackIntro} ${outcome} ${lastFive>=4?`Four or more wins in their final five confirmed a strong finish.`:half>finish?`They also improved on their halfway standing of ${place(half)}.`:`Their final five matches produced ${lastFive} wins.`}`;
 }

 return '';
}
function ceremonyDisplayNominees(s,item){
 // The archived order is fixed on first ceremony generation, including on replay.
 return item.nominees||[];
}
function ceremonyNomineeCard(item,x,s,i){
 const reason=ceremonyNomineeReason(item,x,s);
 const match=item.title==='MATCH OF THE SEASON';
 const matchText=match?String(x.label||'').match(/^(.*?) (\d+)–(\d+) (.*?) · Week (\d+)$/):null;
 const content=matchText?`<div class="nominee-match"><span>${safe(matchText[1])}</span><strong>${matchText[2]}–${matchText[3]}</strong><span>${safe(matchText[4])}</span></div><span class="nominee-week">WEEK ${matchText[5]}</span>`:`${icon(x.t)}<strong>${safe(x.label||name(x.t,s))}</strong>`;
 return `<article class="ceremony-nominee-card"><span class="nominee-number">NOMINEE ${i+1}</span>${content}${reason?`<p class="nominee-reason">${safe(reason)}</p>`:''}</article>`;
}
function ceremonySchedule(){ceremonyCancel();if(currentPage!=='awards'||ceremonyState.phase===5)return;const phase=ceremonyState.phase;const delay=[2500,4700,1750,1750,1750][phase]||1600;ceremonyTimer=setTimeout(()=>{ceremonyTimer=null;if(currentPage!=='awards')return;ceremonyState.phase=Math.min(5,phase+1);renderAwards(season())},window.matchMedia('(prefers-reduced-motion: reduce)').matches?80:delay)}
function ceremonyAdvance(){ceremonyCancel();const awards=ceremonyAwards(season());if(ceremonyState.index<awards.length-1){ceremonyState.index++;ceremonyState.phase=0}else{ceremonyState.phase=6;season().awardsCompleted=true;persist()}renderAwards(season())}
function ceremonyBack(){ceremonyCancel();if(ceremonyState.index>0){ceremonyState.index--;ceremonyState.phase=5;renderAwards(season())}}
function ceremonySkip(){ceremonyCancel();ceremonyState.phase=5;renderAwards(season())}
function ceremonyBeginReveal(){ceremonyCancel();ceremonyState.phase=2;renderAwards(season())}
function ceremonyClose(){ceremonyCancel();showPage('home')}
function renderAwards(s){
 const el=$('other');if(!playoffChampion(s)){ceremonyCancel();el.innerHTML='<h2>Season Awards</h2><p>Complete the playoffs to unlock the ceremony.</p><button onclick="showPage(\'home\')">Return to playoffs</button>';return}
 if(ceremonyState.season!==s.id){ceremonyCancel();ceremonyState={season:s.id,index:0,phase:0}}
 const awards=ceremonyAwards(s),item=awards[ceremonyState.index],phase=ceremonyState.phase;if(phase===6&&rlMythicReveal(s))return;if(phase===6||phase===7){el.innerHTML=`<div class="ceremony-stage"><div class="ceremony-center"><div class="ceremony-big">SEASON ${s.id} COMPLETE!</div><p>All awards have been presented.</p><button onclick="startNewCareerSeason()">Continue to Season ${s.id+1} ▶</button><button onclick="rl216ReplayWholeCeremony()">Replay ceremony</button><button onclick="ceremonyClose()">Exit</button></div></div>`;return}
 const logos=item.teams.map(t=>`<div class="ceremony-team">${icon(t)}<strong>${safe(name(t,s))}</strong></div>`).join('');
 // Nominees are specific to each award; the actual winner stays hidden until reveal.
 const standings=stats(s,s.weeks);
 const title=item.title;
 let candidates=[];
 if(title==='BEST ATTACK')candidates=[...standings].sort((a,b)=>b.gf-a.gf);
 else if(title==='BEST DEFENCE')candidates=[...standings].sort((a,b)=>a.ga-b.ga);
 else if(title==='MOST GOALS CONCEDED')candidates=[...standings].sort((a,b)=>b.ga-a.ga);
 else if(title==='FEWEST GOALS SCORED')candidates=[...standings].sort((a,b)=>a.gf-b.gf);
 else if(title==='BIGGEST OVERACHIEVER'||title==='BIGGEST UNDERACHIEVER'){
   const pre=s.odds[0]?.rows||[];const ranked=[...pre].sort((a,b)=>(b.title||0)-(a.title||0));
   candidates=standings.map((x,i)=>({...x,delta:ranked.findIndex(p=>p.t===x.t)+1-(i+1)})).filter(x=>ranked.some(p=>p.t===x.t)).sort((a,b)=>title==='BIGGEST OVERACHIEVER'?b.delta-a.delta:a.delta-b.delta);
 } else if(title==='HIGHEST-SCORING MATCH'){
   let matches=[];for(let w=1;w<=s.weeks;w++)fixtures(s,w).forEach(([a,b],i)=>{const score=s.results[w]?.[i];if(score)matches.push({a,b,total:score[0]+score[1]})});
   matches.sort((a,b)=>b.total-a.total);const ordered=[];for(const m of matches){for(const t of [m.a,m.b])if(!ordered.includes(t))ordered.push(t)}
   candidates=ordered.map(t=>({t}));
 } else if(item.final){
   // Champion nominees are the actual final's two teams, plus the highest seed outside the final.
   const rounds=s.playoffs||[];const last=rounds[rounds.length-1];const finalTeams=Array.isArray(last)?last.flatMap(m=>[m.a,m.b]):[];
   const ordered=[...finalTeams.filter(t=>t!=null),...standings.map(x=>x.t)];candidates=[...new Set(ordered)].map(t=>({t}));
 }
 const finalists=[...new Set((item.nominees||[]).map(x=>x.t))];
 const finalistLogos=finalists.map(t=>`<div class="ceremony-finalist">${icon(t)}<span>${safe(name(t,s))}</span></div>`).join('');
 let inside='';
 if(phase===0)inside=ceremonyState.index===0?`<div class="ceremony-kicker">TONIGHT'S AWARDS</div><div class="ceremony-big">SEASON ${s.id} AWARDS NIGHT</div>${awards.map((a,i)=>`<p>${i+1}. ${safe(a.title)}</p>`).join('')}`:`<div class="ceremony-kicker">${ceremonyState.index===awards.length-1?'THE FINAL AWARD IS...':`AWARD ${ceremonyState.index+1} IS...`}</div><div class="ceremony-big">${safe(item.title)}</div>`;
 else if(phase===1)inside=`<div class="ceremony-kicker">ROCKET LEAGUE SEASON ${s.id}</div><div class="ceremony-big">${safe(item.title)}</div><p>${safe(item.desc)}</p>${item.trophy?'':`<div class="ceremony-finalists">${ceremonyDisplayNominees(s,item).map((x,i)=>ceremonyNomineeCard(item,x,s,i)).join('')}</div><div class="ceremony-note">FOUR NOMINEES · BASED ON SAVED RESULTS</div>`}`;
 else if(phase<=4)inside=`<div class="ceremony-big">${safe(item.title)}</div><div class="ceremony-suspense">AND THE WINNER IS...</div><div class="ceremony-number">${5-phase}</div>`;
 else inside=`<div class="ceremony-spark">${item.final?'🏆':'✦'}</div><div class="ceremony-award">${safe(item.title)}</div><div class="ceremony-winners">${logos}</div><p class="ceremony-detail">${safe(item.detail)}</p>${!item.trophy&&item.teams.length===1?`<p class="ceremony-winner-citation">${safe(ceremonyWinnerSpeech(item,s))}</p>`:''}<div class="ceremony-confetti" aria-hidden="true">${Array.from({length:item.final?110:65},(_,i)=>`<i style="--x:${(i*67+13)%100}%;--delay:${((i*37)%140)/100}s;--duration:${2.7+((i*19)%160)/100}s;--drift:${((i*47)%180)-90}px;--hue:${(i*83)%360}deg;--turn:${(i%2?1:-1)*540}deg"></i>`).join('')}</div>`;
 const controls=phase===5?`<button onclick="ceremonyBack()" ${ceremonyState.index===0?'disabled':''}>Previous Award</button><button class="ceremony-primary" onclick="ceremonyAdvance()">${ceremonyState.index===awards.length-1?'Ceremony Complete':'Continue to Next Award'} ▶</button>`:`<button onclick="ceremonySkip()">Skip Animation</button>${phase===1?'<button class="ceremony-primary" onclick="ceremonyBeginReveal()">Begin Winner Reveal ▶</button>':''}`;
 el.innerHTML=`<div class="ceremony-stage ceremony-phase-${phase} ${phase===5?'ceremony-revealed':''} ${item.final?'ceremony-final':''}" role="dialog" aria-modal="true" aria-label="Season awards ceremony"><div class="ceremony-spotlight one"></div><div class="ceremony-spotlight two"></div><div class="ceremony-top"><span>ROCKET LEAGUE · SEASON ${s.id} AWARDS NIGHT</span><span>${ceremonyState.index+1} / ${awards.length}</span></div><div class="ceremony-center" aria-live="polite">${inside}</div><div class="ceremony-actions">${controls}<button onclick="ceremonyClose()">Exit Ceremony</button></div></div>`;
 if(phase<5&&phase!==1)ceremonySchedule();
}


// v0.8: read-only analytics; no modifications to saved season results or odds.
let analyticsWeek=null,headA='Custom',headB=null;
function analyticsGames(s,w){const out=[];for(let k=1;k<=Math.min(w,s.weeks);k++){if(!complete(s,k))continue;fixtures(s,k).forEach(([a,b],i)=>{const v=s.results[k][i];if(v&&v.length===2)out.push({w:k,a,b,x:Number(v[0]),y:Number(v[1])})})}return out}
function raceStatus(s,t,w,st){
 const me=st.find(x=>x.t===t),others=st.filter(x=>x.t!==t),left=s.weeks-w,slots=s.playoffCount;
 if(w===s.weeks)return st.findIndex(x=>x.t===t)<slots?'QUALIFIED':'ELIMINATED';
 // Strict wins comparisons avoid falsely claiming a tie-breaker is settled.
 if(others.filter(x=>x.w+left>=me.w).length<slots)return 'CLINCHED';
 if(others.filter(x=>x.w>me.w+left).length>=slots)return 'ELIMINATED';
 return 'IN THE RACE';
}
function streak(form){if(!form.length)return '—';const v=form[form.length-1];let n=0;for(let i=form.length-1;i>=0&&form[i]===v;i--)n++;return v+n}
function renderAnalytics(s){
 const el=$('other'),max=latest(s),w=Math.min(analyticsWeek===null?max:analyticsWeek,max),st=stats(s,w),left=s.weeks-w;
 const saved=s.odds[w]?.rows||[],byOdds=Object.fromEntries(saved.map(r=>[r.t,r]));
 const options=teams(s).map(t=>`<option value="${safe(t)}" ${t===headA?'selected':''}>${safe(name(t,s))}</option>`).join('');
 if(!teams(s).includes(headA))headA='Custom';if(!teams(s).includes(headB)||headB===headA)headB=teams(s).find(t=>t!==headA);
 const optsB=teams(s).filter(t=>t!==headA).map(t=>`<option value="${safe(t)}" ${t===headB?'selected':''}>${safe(name(t,s))}</option>`).join('');
 const race=st.map((x,i)=>{const state=raceStatus(s,x.t,w,st),o=byOdds[x.t],p=o&&Number.isFinite(o.top6)?o.top6.toFixed(1)+'%':'—';return `<tr><td>${i+1}</td><td>${icon(x.t)} ${safe(name(x.t,s))}</td><td>${x.w}–${x.l}</td><td>${state}</td><td>${p}</td></tr>`}).join('');
 const form=st.map(x=>`<tr><td>${icon(x.t)} ${safe(name(x.t,s))}</td><td>${x.form.slice(-5).map(v=>`<span class="form-pill ${v==='W'?'form-win':'form-loss'}">${v}</span>`).join('')||'—'}</td><td>${streak(x.form)}</td><td>${x.gf-x.ga>0?'+':''}${x.gf-x.ga}</td></tr>`).join('');
 const games=analyticsGames(s,w).filter(g=>(g.a===headA&&g.b===headB)||(g.a===headB&&g.b===headA));
 const winsA=games.filter(g=>g.a===headA?g.x>g.y:g.y>g.x).length,winsB=games.length-winsA;
 const gfA=games.reduce((n,g)=>n+(g.a===headA?g.x:g.y),0),gfB=games.reduce((n,g)=>n+(g.a===headB?g.x:g.y),0);
 const h2h=games.map(g=>`<div class="analytics-game"><span>Week ${g.w}</span><span>${safe(name(g.a,s))} <strong>${g.x}–${g.y}</strong> ${safe(name(g.b,s))}</span></div>`).join('')||'<p class="muted">No completed meetings yet.</p>';
 const pre=s.odds[0]?.rows||[],ranks=pre.slice().sort((a,b)=>b.title-a.title),expect=st.map((x,i)=>({t:x.t,actual:i+1,pre:ranks.findIndex(r=>r.t===x.t)+1})).filter(x=>x.pre>0);
 const prediction=expect.map(x=>`<tr><td>${icon(x.t)} ${safe(name(x.t,s))}</td><td>${x.pre}</td><td>${x.actual}</td><td>${x.pre-x.actual>0?'+':''}${x.pre-x.actual}</td></tr>`).join('');
 el.innerHTML=`<div class="row between"><h2>Advanced Analytics · Season ${s.id}</h2><label>Through week <select onchange="analyticsWeek=Number(this.value);renderOther()">${Array.from({length:max+1},(_,i)=>`<option value="${i}" ${i===w?'selected':''}>${i===0?'Preseason':'Week '+i}</option>`).join('')}</select></label></div>
 <p class="muted">${left} regular-season weeks remaining. All statistics below use completed games only.</p>
 <h3>Playoff Race · Top ${s.playoffCount}</h3><div class="analytics-scroll"><table><tr><th>#</th><th>Team</th><th>W–L</th><th>Status</th><th>Playoff odds</th></tr>${race}</table></div>
 <p class="muted">CLINCHED and ELIMINATED use conservative mathematical wins bounds. IN THE RACE includes teams not yet proven either way. Odds are saved simulation estimates, not mathematical guarantees.</p>
 <h3>Recent Form & Momentum</h3><div class="analytics-scroll"><table><tr><th>Team</th><th>Last 5</th><th>Streak</th><th>GD</th></tr>${form}</table></div>
 <h3>⚔️ Head-to-Head</h3><div class="analytics-selects"><label>Team A <select onchange="headA=this.value;renderOther()">${options}</select></label><label>Team B <select onchange="headB=this.value;renderOther()">${optsB}</select></label></div>
 <div class="analytics-h2h"><strong>${safe(name(headA,s))}: ${winsA} wins</strong><span>${games.length} meetings · Goals ${gfA}–${gfB}</span><strong>${safe(name(headB,s))}: ${winsB} wins</strong></div>${h2h}
 <h3>Preseason Expectations vs Current Standings</h3>${expect.length?`<div class="analytics-scroll"><table><tr><th>Team</th><th>Preseason rank</th><th>Current</th><th>Change</th></tr>${prediction}</table></div><p class="muted">Preseason ranking is based on saved league-title odds, not projected wins. Positive change means a higher current position.</p>`:'<p class="muted">No saved preseason simulation available for this season.</p>'}
 <p class="muted">Analytics are calculated locally from your saved results; nothing is uploaded.</p>`;
}


// v0.9.5: Local, deterministic editorial summaries from real entered scores.
// No remote service, fake results, or extra save format required.
// Conservative mathematical league-title clinch detection. A leader is confirmed
// only when no rival can even tie its current wins with all remaining games.
// This deliberately avoids claiming a title while a tiebreak could still change.
function rlLeagueTitleClinch(s,through=latest(s)){
 const limit=Math.min(through,latest(s));
 for(let w=1;w<=limit;w++){
  const table=stats(s,w),leader=table[0];if(!leader)continue;
  if(w===s.weeks)return {week:w,team:leader.t,table};
  const remaining=Object.fromEntries(teams(s).map(t=>[t,0]));
  for(let next=w+1;next<=s.weeks;next++)for(const [a,b] of fixtures(s,next)){remaining[a]++;remaining[b]++}
  if(table.slice(1).every(r=>leader.w>r.w+(remaining[r.t]||0)))return {week:w,team:leader.t,table};
 }
 return null;
}
function rlNewsItems(s,through=latest(s)){
 const items=[],last=Math.min(through,latest(s));if(!last)return [{week:0,title:'A new season begins',body:'All ten teams begin level. Enter the first results to follow the title race, form and playoff battle.'}];
 const current=stats(s,last),prev=stats(s,last-1),leader=current[0],previous=prev[0],rank=Object.fromEntries(current.map((r,i)=>[r.t,i+1]));
 const preRank=Object.fromEntries(prev.map((r,i)=>[r.t,i+1]));
 const describe=t=>{const r=current.find(x=>x.t===t);return `${name(t,s)} are ${rank[t]}${rank[t]===1?'st':rank[t]===2?'nd':rank[t]===3?'rd':'th'} with ${r.w} wins, ${r.l} losses and a goal difference of ${r.gf-r.ga>=0?'+':''}${r.gf-r.ga}`};
 if(last>1&&leader.t!==previous.t)items.push({week:last,title:`${name(leader.t,s)} take the league lead`,body:`The lead changed hands after Week ${last}. ${describe(leader.t)}. ${name(previous.t,s)} have slipped to ${rank[previous.t]}${rank[previous.t]===2?'nd':'th'} place. With ${s.weeks-last} regular-season weeks left, the race is still developing.`});
 if(last>1){const mover=current.map(r=>({t:r.t,move:preRank[r.t]-rank[r.t]})).sort((a,b)=>b.move-a.move)[0];if(mover?.move>=2)items.push({week:last,title:`${name(mover.t,s)} surge ${mover.move} places`,body:`A significant standings change sees ${name(mover.t,s)} climb from ${preRank[mover.t]} to ${rank[mover.t]}. ${describe(mover.t)}. Their position in the ${s.playoffCount}-team playoff race has improved, but the remaining fixtures will decide whether they can hold it.`})}
 const matches=fixtures(s,last).map(([a,b],i)=>({a,b,score:s.results[last]?.[i]})).filter(m=>m.score);
 const closest=matches.filter(m=>Math.abs(m.score[0]-m.score[1])===1)[0];if(closest){const m=closest,winner=m.score[0]>m.score[1]?m.a:m.b;items.push({week:last,title:`${name(winner,s)} edge a one-goal contest`,body:`${name(m.a,s)} ${m.score[0]}–${m.score[1]} ${name(m.b,s)}. ${name(winner,s)} came out on top in a match separated by a single goal. ${describe(winner)}. The result also leaves ${name(winner===m.a?m.b:m.a,s)} in ${rank[winner===m.a?m.b:m.a]} place.`})}
 const biggest=matches.slice().sort((a,b)=>Math.abs(b.score[0]-b.score[1])-Math.abs(a.score[0]-a.score[1]))[0];if(biggest&&Math.abs(biggest.score[0]-biggest.score[1])>=3){const m=biggest,winner=m.score[0]>m.score[1]?m.a:m.b,loser=winner===m.a?m.b:m.a;items.push({week:last,title:`Statement victory for ${name(winner,s)}`,body:`${name(m.a,s)} ${m.score[0]}–${m.score[1]} ${name(m.b,s)} was the largest winning margin of Week ${last}. The ${Math.abs(m.score[0]-m.score[1])}-goal victory boosts ${name(winner,s)}'s goal difference; ${describe(winner)}. ${name(loser,s)} must regroup after the defeat.`})}
 const streaks=current.map(r=>({t:r.t,run:(r.form.join('').match(/W+$/)||[''])[0].length})).filter(r=>r.run>=4).sort((a,b)=>b.run-a.run);if(streaks.length)items.push({week:last,title:`${name(streaks[0].t,s)} extend winning streak to ${streaks[0].run}`,body:`${name(streaks[0].t,s)} have won their last ${streaks[0].run} league matches. ${describe(streaks[0].t)}. Consistency is proving important as the regular season moves towards the final standings.`});
 if(last>=Math.floor(s.weeks*.75)&&last<s.weeks){const cutoff=current[s.playoffCount-1],outside=current[s.playoffCount];items.push({week:last,title:`Playoff cutoff tightens with ${s.weeks-last} weeks remaining`,body:`${name(cutoff.t,s)} occupy the final qualifying position with ${cutoff.w} wins. ${name(outside.t,s)} are immediately outside the top ${s.playoffCount} on ${outside.w} wins. Goal difference and remaining fixtures could still affect the final order.`})}
 // Publish a team's first mathematically confirmed playoff status in the week it changes.
 // Use the same conservative status calculation as the coloured league standings.
 if(last>0){
  const before=leagueRowStatuses(s,last-1),after=leagueRowStatuses(s,last);
  const weekMatches=fixtures(s,last).map(([a,b],i)=>({a,b,score:s.results[last]?.[i]})).filter(m=>Array.isArray(m.score));
  for(const t of teams(s)){
   const status=after[t];
   if(!['qualified','eliminated'].includes(status)||before[t]===status)continue;
   // The gold league champion also qualifies; the title announcement covers that event.
   const own=weekMatches.find(m=>m.a===t||m.b===t);
   const ownText=own?`${name(own.a,s)} ${own.score[0]}–${own.score[1]} ${name(own.b,s)}`:'';
   const other=weekMatches.filter(m=>m!==own);
   const resultsContext=other.length?` Other Week ${last} results also affected the qualification race.`:'';
   if(status==='qualified'){
    items.push({week:last,kind:'playoff-qualified',title:`${name(t,s)} mathematically secure a playoff place!`,body:`${ownText?`Following their ${ownText} match, `:`Following Week ${last}, `}${name(t,s)} are guaranteed a place in the top ${s.playoffCount}. Even with the remaining fixtures, they cannot fall outside the qualifying positions.${resultsContext}`});
   }else{
    items.push({week:last,kind:'playoff-eliminated',title:`${name(t,s)} mathematically eliminated from playoff contention`,body:`${ownText?`Following ${ownText}, `:`Following the Week ${last} results, `}${name(t,s)} can no longer finish in the top ${s.playoffCount}, even if they win every remaining league match.${resultsContext}`});
   }
  }
 }
 const clinch=rlLeagueTitleClinch(s,last);
 if(clinch&&clinch.week===last&&last<s.weeks){
  const runner=clinch.table[1],remaining=s.weeks-last;
  items.unshift({week:last,kind:'league-clinch',title:`🏆 ${name(clinch.team,s)} clinch the league title in Week ${last}!`,body:`${name(clinch.team,s)} have mathematically secured first place with ${remaining} league week${remaining===1?'':'s'} remaining. They have ${clinch.table[0].w} wins; even if ${name(runner.t,s)} win every remaining match, they cannot draw level on wins. A full season review will follow after Week ${s.weeks}.`});
 }
 if(last===s.weeks)items.unshift({week:last,kind:'league-review',title:`🏆 ${name(leader.t,s)} — League Champions: full season review`,body:`The regular season is complete. ${describe(leader.t)}. The top ${s.playoffCount} now progress to the knockout stage, where league position determines the seeds${s.playoffCount===6?' and the top two receive semifinal byes':''}.`});
 if(!items.length)items.push({week:last,title:`Week ${last} complete: ${name(leader.t,s)} remain on top`,body:`${describe(leader.t)}. ${name(current[1].t,s)} sit second on ${current[1].w} wins, while ${name(current[s.playoffCount].t,s)} are first outside the playoff places. ${s.weeks-last} league weeks remain.`});
 return items;
}

function rlFeatured(s,w){
 const played=latest(s),target=Math.min(s.weeks,Math.max(1,w));
 if(target<Math.max(3,Math.ceil(s.weeks*0.14)))return null;
 if(target<=played){const matches=fixtures(s,target),scores=s.results[target]||[];const rank=Object.fromEntries(stats(s,Math.max(0,target-1)).map((r,i)=>[r.t,i+1]));const idx=matches.map(([a,b],i)=>({i,score:scores[i],quality:Math.abs((rank[a]||5)-(rank[b]||5))})).filter(x=>x.score).sort((a,b)=>a.quality-b.quality)[0]?.i??0;const [a,b]=matches[idx],score=scores[idx];return {title:`Week ${target} · Featured Result`,body:`${name(a,s)} ${score[0]}–${score[1]} ${name(b,s)}. ${name(score[0]>score[1]?a:b,s)} take the win.`,a,b};}
 if(played===s.weeks)return null;
 const rank=Object.fromEntries(stats(s,played).map((r,i)=>[r.t,i+1]));const matches=fixtures(s,target);const sorted=matches.map(([a,b],i)=>({a,b,i,score:(rank[a]||5)+(rank[b]||5),gap:Math.abs((rank[a]||5)-(rank[b]||5))})).sort((x,y)=>x.score-y.score||x.gap-y.gap);const m=sorted[0];return {title:`Week ${target} · Featured Match`,body:`#${rank[m.a]} ${name(m.a,s)} vs #${rank[m.b]} ${name(m.b,s)}. Both teams enter this fixture near the top of the table. A win could affect the title race, seeding and the chase for a playoff place.`,a:m.a,b:m.b};
}
function playoffNews(s){const rounds=playoffRounds(s),out=[];rounds.forEach((round,i)=>round.matches.forEach(m=>{if(!m.winner||!m.score)return;const loser=m.winner===m.a?m.b:m.a,roundWeek=s.weeks+i+1;out.push({week:roundWeek,title:i===rounds.length-1?`🏆 ${name(m.winner,s)} win the championship`:`${name(m.winner,s)} advance from ${round.title}`,body:`${name(m.a,s)} ${m.score[0]}–${m.score[1]} ${name(m.b,s)}. ${name(m.winner,s)} defeat ${name(loser,s)} in ${round.title.toLowerCase()}. ${i===rounds.length-1?`The victory crowns ${name(m.winner,s)} Season ${s.id} playoff champions after ${rounds.length} knockout rounds.`:`Their season continues into the next playoff round, while ${name(loser,s)} are eliminated from championship contention.`}`})}));const next=rounds.findIndex(round=>round.matches.some(m=>m.a&&m.b&&!m.winner));if(next>=0){const round=rounds[next],m=round.matches.find(x=>x.a&&x.b&&!x.winner);if(m){const a=stats(s,s.weeks).find(x=>x.t===m.a),b=stats(s,s.weeks).find(x=>x.t===m.b);out.unshift({week:s.weeks+next+1,title:`Playoff preview: ${name(m.a,s)} vs ${name(m.b,s)}`,body:`${round.title} brings together ${name(m.a,s)} (${a.w}–${a.l} in the league) and ${name(m.b,s)} (${b.w}–${b.l}). ${name(m.a,s)} scored ${a.gf} league goals and conceded ${a.ga}; ${name(m.b,s)} scored ${b.gf} and conceded ${b.ga}. The winner advances${next===rounds.length-1?' to claim the championship':' to the next round'}, and the loser is eliminated.`})}}return out.reverse()}
function rlNewsFeed(s){let out=playoffNews(s);for(let w=latest(s);w>=1;w--)out.push(...rlNewsItems(s,w).filter(n=>n.week===w));return out.length?out:rlNewsItems(s,0)}
function rlArticleParagraphs(s,n){
 const paragraphs=[n.body],w=n.week,st=stats(s,Math.min(w,s.weeks));
 if(n.kind==='playoff-qualified'||n.kind==='playoff-eliminated'){
  const table=stats(s,Math.min(w,s.weeks)),cutoff=table[s.playoffCount-1],firstOut=table[s.playoffCount];
  const remaining=Math.max(0,s.weeks-w);
  paragraphs.push(`After Week ${w}, the playoff cutoff stands at ${name(cutoff.t,s)} in ${s.playoffCount}${ordinalSuffix(s.playoffCount)} place with ${cutoff.w} wins. ${name(firstOut.t,s)} are immediately outside with ${firstOut.w} wins. There are ${remaining} league matches left for each team.`);
  paragraphs.push(`Qualification and elimination are determined by the mathematical standings, not simply by a team's position today. Other teams' results can settle a place even when the team itself wins, so the full week's scores must be considered.`);
 }
 if(w===s.weeks&&latest(s)===s.weeks&&(n.kind==='league-review'||n.title.includes('league title'))){
  const leader=st[0],runner=st[1],form=leader.form||[];
  let best=0,run=0,worst=0,loss=0;for(const f of form){run=f==='W'?run+1:0;loss=f==='L'?loss+1:0;best=Math.max(best,run);worst=Math.max(worst,loss)}
  const games=[];for(let week=1;week<=s.weeks;week++)fixtures(s,week).forEach(([a,b],i)=>{if(a!==leader.t&&b!==leader.t)return;const score=s.results[week]?.[i];if(!score)return;const gf=a===leader.t?score[0]:score[1],ga=a===leader.t?score[1]:score[0];games.push({week,gf,ga,opponent:a===leader.t?b:a})});
  const peak=games.slice().sort((a,b)=>(b.gf-b.ga)-(a.gf-a.ga))[0],struggle=games.filter(x=>x.gf<x.ga).sort((a,b)=>(a.gf-a.ga)-(b.gf-b.ga))[0];
  paragraphs.push(`${name(leader.t,s)} finish the ${s.weeks}-week league campaign with ${leader.w} wins and ${leader.l} losses, scoring ${leader.gf} goals and conceding ${leader.ga}. Their goal difference stands at ${leader.gf-leader.ga>=0?'+':''}${leader.gf-leader.ga}, with ${name(runner.t,s)} finishing second on ${runner.w} wins. The final table, rather than a prediction, confirms the title.`);
  paragraphs.push(`Their strongest spell included ${best} consecutive league victories. ${peak?`A standout result came in Week ${peak.week}, when they beat ${name(peak.opponent,s)} ${peak.gf}–${peak.ga}.`:''} Their scoring and defensive totals reveal how they built the campaign over the full schedule.`);
  paragraphs.push(struggle?`There were difficult moments too. In Week ${struggle.week}, ${name(struggle.opponent,s)} beat them ${struggle.ga}–${struggle.gf}, one of the setbacks they had to overcome. Their longest losing run was ${worst} match${worst===1?'':'es'}.`:`They avoided defeat throughout the league schedule. Their longest losing run was zero, leaving opponents without a league victory against them.`);
  const past=db.seasons.filter(x=>x.id<=s.id&&latest(x)===x.weeks&&name(stats(x,x.weeks)[0].t,x)===name(leader.t,s)).map(x=>x.id).sort((a,b)=>a-b);
  paragraphs.push(`This is ${name(leader.t,s)}'s ${ordinal(past.length)} League Title.${past.length>1?` Their previous league wins came in ${seasonList(past.slice(0,-1))}.`:''} The playoffs now offer a separate opportunity to claim the championship.`);
 }else if(n.kind==='league-clinch'){
  const c=rlLeagueTitleClinch(s,w),leader=c?.table[0],runner=c?.table[1];
  if(c&&leader&&runner){
   const gap=leader.w-runner.w,possible=runner.w+(s.weeks-w);
   paragraphs.push(`With ${s.weeks-w} rounds still to play, ${name(leader.t,s)} have ${leader.w} wins and ${runner.w} for ${name(runner.t,s)}. The closest challenger can reach at most ${possible} wins, which is fewer than the leaders already have. The league title is therefore mathematically beyond reach.`);
   paragraphs.push(`The title winners have scored ${leader.gf} goals and conceded ${leader.ga} through Week ${w}, with a goal difference of ${leader.gf-leader.ga>=0?'+':''}${leader.gf-leader.ga}. Their current lead over second place is ${gap} wins.`);
   const form=leader.form||[],best=form.reduce((a,x)=>{a.run=x==='W'?a.run+1:0;a.max=Math.max(a.max,a.run);return a},{run:0,max:0}).max;
   paragraphs.push(`A longest winning streak of ${best} matches has helped put ${name(leader.t,s)} out of reach. The remaining fixtures still matter for the final record and playoff seeding, but not for the identity of the league champions.`);
   const previous=db.seasons.filter(x=>x.id<s.id&&latest(x)===x.weeks&&name(stats(x,x.weeks)[0].t,x)===name(leader.t,s)).map(x=>x.id).sort((a,b)=>a-b);
   paragraphs.push(`This is ${name(leader.t,s)}'s ${ordinal(previous.length+1)} League Title.${previous.length?` Their previous league wins came in ${seasonList(previous)}.`:''} A detailed review of their complete campaign will be published after Week ${s.weeks}.`);
  }
 }else if(w>s.weeks){
  const r=w-s.weeks-1,round=playoffRounds(s)[r],match=round?.matches.find(m=>m.score&&n.title.includes(name(m.winner,s)));
  if(match){const win=match.winner,lose=win===match.a?match.b:match.a,ws=match.score[win===match.a?0:1],ls=match.score[win===match.a?1:0],rank=stats(s,s.weeks),wr=rank.find(x=>x.t===win),lr=rank.find(x=>x.t===lose);
   paragraphs.push(`${name(win,s)} came into the knockout stage after finishing ${rank.indexOf(wr)+1}${ordinalSuffix(rank.indexOf(wr)+1)} in the league with a ${wr.w}–${wr.l} record. ${name(lose,s)} had finished ${rank.indexOf(lr)+1}${ordinalSuffix(rank.indexOf(lr)+1)}, recording ${lr.w} wins across the regular season.`);
   paragraphs.push(`The final score was ${ws}–${ls} in favour of ${name(win,s)}, a margin of ${ws-ls} goal${ws-ls===1?'':'s'}. With knockout elimination at stake, the result ends ${name(lose,s)}'s championship challenge and keeps ${name(win,s)} in contention.`);
   if(r===playoffRounds(s).length-1){const path=playoffRounds(s).slice(0,-1).flatMap(round=>round.matches.filter(m=>m.winner===win&&m.score).map(m=>`${round.title}: ${name(win,s)} beat ${name(m.a===win?m.b:m.a,s)} ${m.score[m.a===win?0:1]}–${m.score[m.a===win?1:0]}`));
    paragraphs.push(`${name(win,s)}'s journey to the final followed a league campaign of ${wr.w} wins, ${wr.l} defeats, ${wr.gf} goals scored and ${wr.ga} conceded. ${path.length?`Their earlier playoff victories were ${path.join('; ')}.`:'They reached the final after their earlier knockout fixtures and any earned bye.'}`);
    const previous=db.seasons.filter(x=>x.id<s.id&&playoffChampion(x)&&name(playoffChampion(x),x)===name(win,s)).map(x=>x.id).sort((a,b)=>a-b);
    paragraphs.push(`The final completes a knockout campaign in which every recorded playoff victory mattered. ${name(win,s)} have emerged as the last team standing from the ${s.playoffCount} qualifiers, converting their regular-season position into the championship trophy.`);
    paragraphs.push(`Their regular-season goal difference was ${wr.gf-wr.ga>=0?'+':''}${wr.gf-wr.ga}. Across ${s.weeks} league weeks they finished ${rank.indexOf(wr)+1}${ordinalSuffix(rank.indexOf(wr)+1)}, showing how the league title and playoff championship reward different achievements.`);
    paragraphs.push(`This is ${name(win,s)}'s ${ordinal(previous.length+1)} Championship Title.${previous.length?` Their previous ${previous.length===1?'win came':'wins came'} in ${seasonList(previous)}.`:''}`);
   }else paragraphs.push(`The next stage will test whether ${name(win,s)} can turn this result into a championship run. ${name(lose,s)} must wait until another season for their next opportunity.`);
  }else{paragraphs.push(`This ${round?.title||'playoff'} contest will determine which team progresses. The final league standings and any saved earlier knockout results provide the context for the matchup.`)}
 }else if(w>0){const previous=stats(s,Math.max(0,w-1)),current=stats(s,Math.min(w,s.weeks));const lead=current[0],second=current[1];
  paragraphs.push(`After Week ${w}, ${name(lead.t,s)} lead the table with ${lead.w} wins, followed by ${name(second.t,s)} with ${second.w}. The race for the top ${s.playoffCount} remains shaped by each team's actual results and goal difference.`);
  if(w>=Math.ceil(s.weeks*.65)){const edge=current[s.playoffCount-1],next=current[s.playoffCount];paragraphs.push(`${name(edge.t,s)} currently hold the final playoff position on ${edge.w} wins, while ${name(next.t,s)} are immediately outside on ${next.w}. With ${s.weeks-w} regular-season weeks remaining, every result carries added importance.`)}
  else paragraphs.push(`There are ${s.weeks-w} league weeks left. The standings can still shift as teams build form, face direct rivals and try to protect their positions.`);
 }
 return paragraphs;
}
function ordinalSuffix(n){return n%100>=11&&n%100<=13?'th':n%10===1?'st':n%10===2?'nd':n%10===3?'rd':'th'}
function ordinal(n){return `${n}${ordinalSuffix(n)}`}
function rlNewsCard(s,n){const paragraphs=rlArticleParagraphs(s,n);return `<details class="story-card news-article"><summary><div class="story-meta">Season ${s.id} · Week ${n.week}</div><div class="news-headline"><strong>${safe(n.title)}</strong></div><div class="news-preview">${safe(n.body)}</div><div class="news-read">Read full article ▾</div></summary><div class="news-full">${paragraphs.map(p=>`<p>${safe(p)}</p>`).join('')}</div></details>`}
function rlFeaturedCard(s,w){const f=rlFeatured(s,w);return f?rlNewsCard(s,{...f,week:w}):''}
function renderHomeNews(s,w){const el=$('homeNews');if(!el)return;const expanded=el.querySelector('details.news-archive')?.open||false,feed=rlNewsFeed(s);el.innerHTML=rlFeaturedCard(s,Math.min(latest(s)+1,s.weeks))+rlOpeningDay(s,w)+rlWeekHistory(s,w)+rlRevengePreview(s,w)+rlMilestones(s,w)+feed.slice(0,3).map(n=>rlNewsCard(s,n)).join('')+`<details class="news-archive" ${expanded?'open':''}><summary>View all news (${feed.length} stories)</summary><div class="news-feed">${feed.slice(3).map(n=>rlNewsCard(s,n)).join('')||'<p class="muted">No older stories yet.</p>'}</div></details>`}
function renderNewsPage(s){return rlNewsFeed(s).map(n=>rlNewsCard(s,n)).join('')}
let careerSort='wins';function setCareerSort(k){careerSort=k;renderOther()}
function renderCareerRecords(){
 const completed=db.seasons.filter(s=>latest(s)===s.weeks).sort((a,b)=>a.id-b.id),history={},league={},play={},titles={},champs={},runnerUps={},qual={},winnerRows=[];
 const get=(o,k)=>o[k]||(o[k]={w:0,l:0,gf:0,ga:0,played:0});
 const add=(o,k,gf,ga)=>{const r=get(o,k);r.w+=gf>ga?1:0;r.l+=gf<ga?1:0;r.gf+=gf;r.ga+=ga;r.played++};
 const addSeason=(o,k,id)=>{(o[k]||(o[k]=[])).push(id)};
 const seasonLeague=[],seasonPlay=[];
 for(const s of completed){const table=stats(s,s.weeks),first=table[0]?.t,champ=playoffChampion(s);winnerRows.push({s,first,champ});if(first)addSeason(titles,first,s.id);if(champ)addSeason(champs,champ,s.id);if(champ){const final=playoffRounds(s).at(-1)?.matches?.[0];if(final?.winner&&final.a&&final.b){const losing=final.winner===final.a?final.b:final.a;addSeason(runnerUps,losing,s.id)}}
  for(const [i,r] of table.entries()){const k=r.t;get(league,k);get(play,k);if(i<s.playoffCount)addSeason(qual,k,s.id);(history[k]||(history[k]=[])).push({id:s.id,qualified:i<s.playoffCount,league:r.t===first,champ:r.t===champ});seasonLeague.push({team:k,id:s.id,...r})}
  for(let w=1;w<=s.weeks;w++)fixtures(s,w).forEach(([a,b],i)=>{const score=s.results[w]?.[i];if(score){add(league,a,score[0],score[1]);add(league,b,score[1],score[0])}});
  const rounds=playoffRounds(s),run={};for(const round of rounds)for(const m of round.matches){if(!m.score||!m.a||!m.b)continue;const a=m.a,b=m.b;add(play,a,m.score[0],m.score[1]);add(play,b,m.score[1],m.score[0]);for(const [k,gf,ga] of [[a,m.score[0],m.score[1]],[b,m.score[1],m.score[0]]]){const v=run[k]||(run[k]={gf:0,ga:0,w:0,l:0});v.gf+=gf;v.ga+=ga;v.w+=gf>ga?1:0;v.l+=gf<ga?1:0}}
  for(const [k,r] of Object.entries(run))seasonPlay.push({team:k,id:s.id,...r});
 }
 const allNames=[...new Set([...Object.keys(league),...Object.keys(play)])].sort();
 const fmtNames=(names)=>names.length?names.map(x=>safe(x==='Custom'?db.customName:x)).join('<br>'):'—';
 const maxList=(o)=>{const max=Math.max(0,...Object.values(o).map(v=>v.length));return {max,entries:Object.entries(o).filter(([k,v])=>v.length===max)}};
 const streak=(field,current=false)=>{
  const entries=[];
  for(const [k,rows] of Object.entries(history)){
   let run=0,start=null,end=null,best=0,bestStart=null,bestEnd=null,lastSeason=null;
   for(const r of rows){
    if(lastSeason!==null&&r.id!==lastSeason+1){run=0;start=null;}
    lastSeason=r.id;
    if(r[field]){
     if(!run)start=r.id;
     run++;end=r.id;
     if(run>best){best=run;bestStart=start;bestEnd=end}
    }else{run=0;start=null}
   }
   // An absent season cannot preserve a current title/qualification streak.
   if(current&&lastSeason!==completed.at(-1)?.id){run=0;start=null;end=null}
   entries.push({team:k,value:current?run:best,start:current?start:bestStart,end:current?end:bestEnd});
  }
  const max=Math.max(0,...entries.map(e=>e.value));
  return {max,entries:entries.filter(e=>e.value===max&&max>0)};
 };
 const seasonRange=(a,b)=>a===b?seasonLabel(a):`${seasonLabel(a)} – ${seasonLabel(b)}`;
 const major=(title,r,unit)=>`<div class="record-tile"><span>${safe(title)}</span><strong class="record-count">${r.max} ${safe(unit)}</strong>${r.entries.map(e=>`<div class="record-holder"><b>${safe(e.team==='Custom'?db.customName:e.team)}</b><span>${safe(e.seasons?seasonList(e.seasons):seasonRange(e.start,e.end))}</span></div>`).join('')||'—'}</div>`;
 const titleMax=maxList(titles),champMax=maxList(champs),runnerMax=maxList(runnerUps);
 const big=[major('Most league titles',{max:titleMax.max,entries:titleMax.entries.map(([team,seasons])=>({team,seasons}))},'titles'),major('🏆 Most championships',{max:champMax.max,entries:champMax.entries.map(([team,seasons])=>({team,seasons}))},'championships'),major('🥈 Most Championship Runner-Ups',{max:runnerMax.max,entries:runnerMax.entries.map(([team,seasons])=>({team,seasons}))},'runner-up finishes'),major('Longest championship streak',streak('champ'),'consecutive titles'),major('Longest playoff qualification streak',streak('qualified'),'consecutive qualifications')];
 const board=(heading,obj)=>`<h3>${heading}</h3><div class="career-table-wrap career-leaderboard"><table><tr><th>Team</th><th>W</th><th>L</th><th>GF</th><th>GA</th><th>GD</th><th>Win %</th></tr>${allNames.map(team=>({team,...get(obj,team)})).sort((a,b)=>b.w-a.w||a.team.localeCompare(b.team)).map(r=>`<tr><td>${safe(r.team==='Custom'?db.customName:r.team)}</td><td>${r.w}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gf-r.ga}</td><td>${r.played?(100*r.w/r.played).toFixed(1)+'%':'—'}</td></tr>`).join('')}</table></div>`;
 const recordRows=(arr,fields,period)=>fields.map(([field,label])=>{const max=Math.max(0,...arr.map(r=>r[field]||0)),hits=arr.filter(r=>(r[field]||0)===max&&max>0);return `<tr><td>${safe(label)}</td><td>${max}</td><td>${hits.length?(hits.length>5?`<details><summary>${hits.length} tied records — show all</summary>${hits.map(r=>`${safe(r.team==='Custom'?db.customName:r.team)} (${safe(seasonLabel(r.id))})`).join('<br>')}</details>`:hits.map(r=>`${safe(r.team==='Custom'?db.customName:r.team)} <span class="muted">(${safe(seasonLabel(r.id))})</span>`).join('<br>')):'—'}</td></tr>`}).join('');
 const allTimeRows=(obj,fields)=>fields.map(([field,label])=>{const max=Math.max(0,...Object.values(obj).map(r=>r[field]||0));return `<tr><td>${safe(label)}</td><td>${max}</td><td>${Object.entries(obj).filter(([k,r])=>r[field]===max&&max>0).map(([k])=>safe(k==='Custom'?db.customName:k)).join('<br>')||'—'}</td></tr>`}).join('');
 const goalFields=[['gf','Most goals scored'],['ga','Most goals conceded']];
 const table=(title,rows)=>`<h3>${title}</h3><div class="career-table-wrap career-record-list"><table><tr><th>Record</th><th>Value</th><th>Holder · Season</th></tr>${rows}</table></div>`;
 const records=(label,obj,arr,isPlayoff=false)=>table(label,allTimeRows(obj,[['gf','Most goals scored (all-time)'],['ga','Most goals conceded (all-time)'],['w','Most wins (all-time)'],['l','Most losses (all-time)']])+recordRows(arr,isPlayoff?[['gf','Most goals scored (playoff run)'],['ga','Most goals conceded (playoff run)']]:[['gf','Most goals scored (season)'],['ga','Most goals conceded (season)'],['w','Most wins (season)'],['l','Most losses (season)']]));
 const streakRows=[['Longest playoff qualification streak',streak('qualified')],['Current playoff qualification streak',streak('qualified',true)],['Consecutive league titles',streak('league')],['Consecutive championships',streak('champ')]].map(([label,r])=>`<tr><td>${safe(label)}</td><td>${r.max}</td><td>${r.entries.map(e=>`${safe(e.team==='Custom'?db.customName:e.team)} (${safe(seasonRange(e.start,e.end))})`).join('<br>')||'—'}</td></tr>`).join('');
 const appearances=Object.fromEntries(Object.entries(qual).map(([k,v])=>[k,{count:v.length}]));const maxApps=Math.max(0,...Object.values(appearances).map(v=>v.count));
 return `<h2>Career Records</h2><p class="muted">${completed.length} completed seasons · All joint holders included. Teams keep records when they rotate out.</p><div class="record-grid major-records">${big.join('')}</div>${board('All-Time League Leaderboard',league)}${board('All-Time Playoff Leaderboard',play)}${records('Regular Season Goalscoring & Match Records',league,seasonLeague)}${records('Playoff Goalscoring & Match Records',play,seasonPlay,true)}${table('Other Career Records',`<tr><td>Most playoff appearances</td><td>${maxApps}</td><td>${Object.entries(appearances).filter(([k,v])=>v.count===maxApps).map(([k])=>safe(k==='Custom'?db.customName:k)).join('<br>')||'—'}</td></tr>`+streakRows)}<h3>Championship History</h3><div class="career-history-wrap"><table class="career-history-table"><tr><th>Season</th><th>League winner</th><th>Playoff champion</th></tr>${winnerRows.map(x=>`<tr><td>${safe(seasonLabel(x.s.id))}</td><td>${safe(name(x.first,x.s))}</td><td>${x.champ?safe(name(x.champ,x.s)):'Not completed'}</td></tr>`).join('')}</table></div>`;
}


// v1.0.6 career-history expansion — read-only views over existing saved results.
function rlFinishedSeasons(){return db.seasons.filter(x=>latest(x)===x.weeks&&!!playoffChampion(x))}
function rlSeasonSummary(s){const r=stats(s,s.weeks),champ=playoffChampion(s);return {s,r,champ,league:r[0],games:analyticsGames(s,s.weeks),spread:r[0].w-r[r.length-1].w,topGap:r[0].w-r[1].w,playoffGap:r[s.playoffCount-1].w-r[s.playoffCount].w}}
function rlAllGames(){return db.seasons.flatMap(s=>analyticsGames(s,latest(s)).map(g=>({...g,s,an:name(g.a,s),bn:name(g.b,s)})))}
function rlCareerExpansion(){const finished=rlFinishedSeasons(),summary=finished.map(rlSeasonSummary);const cards=summary.map(x=>`<div class="notice"><strong>Season ${x.s.id}</strong><p>League Title: ${safe(name(x.league.t,x.s))} (${x.league.w}–${x.league.l}) · Championship: ${safe(name(x.champ,x.s))}</p><p>Top-two win gap: ${x.topGap} · First-to-last win gap: ${x.spread} · Playoff cutoff gap: ${x.playoffGap}</p></div>`).join('');const trophies={};for(const x of summary){for(const [t,kind] of [[x.league.t,'League Title'],[x.champ,'Championship']]){const z=trophies[t]||(trophies[t]={league:0,champ:0,seasons:[]});z[kind==='League Title'?'league':'champ']++;z.seasons.push(`S${x.s.id} ${kind}`)}}const legacy=Object.entries(trophies).sort((a,b)=>(b[1].league+b[1].champ)-(a[1].league+a[1].champ)||a[0].localeCompare(b[0])).map(([t,v])=>`<tr><td>${safe(t==='Custom'?db.customName:t)}</td><td>${v.league}</td><td>${v.champ}</td><td>${safe(v.seasons.join(', '))}</td></tr>`).join('');const moments=summary.flatMap(x=>{const r=x.r,events=[{s:x.s.id,w:x.s.weeks,title:`${name(x.league.t,x.s)} win the League Title with ${x.league.w} wins and a ${x.league.gf-x.league.ga>=0?"+":""}${x.league.gf-x.league.ga} goal difference`},{s:x.s.id,w:x.s.weeks+playoffWeekCount(x.s),title:`${name(x.champ,x.s)} win the Championship`}];const prev=db.seasons.find(z=>z.id===x.s.id-1);if(prev){const newcomers=teams(x.s).filter(t=>!teams(prev).includes(t)).map(t=>name(t,x.s));if(newcomers.length)events.unshift({s:x.s.id,w:1,title:`${newcomers.join(", ")} ${newcomers.length===1?"join":"join"} the league`})}return events}).sort((a,b)=>a.s-b.s||a.w-b.w);return `<h2>League Hall of Fame & Championship Legacy</h2><p class="muted">Verified trophy achievements from completed seasons; formal legendary-team inductions are not assigned automatically.</p><div class="career-table-wrap"><table><tr><th>Team</th><th>League Titles</th><th>Championships</th><th>Trophy history</th></tr>${legacy||'<tr><td colspan="4">Complete a season to populate the gallery.</td></tr>'}</table></div><h2>League Strength Across Seasons</h2><p class="muted">Smaller gaps indicate a closer league by wins; these measures do not claim a season was objectively stronger.</p>${cards||'<p>No completed seasons yet.</p>'}<h2>Season Comparison</h2><div class="row"><label>First season <select id="rlCompareA" onchange="rlCompareRender()">${summary.map(x=>`<option value="${x.s.id}">Season ${x.s.id}</option>`).join('')}</select></label><label>Second season <select id="rlCompareB" onchange="rlCompareRender()">${summary.map(x=>`<option value="${x.s.id}" ${x.s.id===summary.at(-1)?.s.id?'selected':''}>Season ${x.s.id}</option>`).join('')}</select></label></div><div id="rlCompareResult"></div><h2>Career Timeline</h2>${moments.map(m=>`<div class="notice"><strong>Season ${m.s} · Week ${m.w}</strong><p>${safe(m.title)}</p><button onclick="rlGoToMoment(${m.s},${m.w})">View season</button></div>`).join('')||'<p>Historic moments appear after completed seasons.</p>'}`}
function rlCompareRender(){const a=Number(document.getElementById('rlCompareA')?.value),b=Number(document.getElementById('rlCompareB')?.value),el=document.getElementById('rlCompareResult');if(!el)return;const x=db.seasons.find(s=>s.id===a),y=db.seasons.find(s=>s.id===b);if(!x||!y)return;if(a===b){el.innerHTML='<div class="notice">Choose two different completed seasons to compare. Season comparisons become meaningful once a second season is complete.</div>';return;}const r=[rlSeasonSummary(x),rlSeasonSummary(y)];el.innerHTML='<div class="career-table-wrap"><table><tr><th>Measure</th>'+r.map(z=>`<th>Season ${z.s.id}</th>`).join('')+'</tr>'+[['League Champion',z=>name(z.league.t,z.s)],['Championship Winner',z=>name(z.champ,z.s)],['Champion Wins',z=>z.league.w],['Champion Goal Difference',z=>z.league.gf-z.league.ga],['Total Regular-Season Goals',z=>z.r.reduce((a,b)=>a+b.gf,0)],['First–Second Wins Gap',z=>z.topGap],['First–Last Wins Gap',z=>z.spread]].map(([k,fn])=>`<tr><td>${k}</td>${r.map(z=>`<td>${safe(String(fn(z)))}</td>`).join('')}</tr>`).join('')+'</table></div>'}
function rlGoToMoment(id,w){const i=db.seasons.findIndex(s=>s.id===id);if(i<0)return;db.active=i;selectedWeek=Math.min(w,maxViewWeek(season()));persist();showPage('home')}
function rlOpeningDay(s,w){if(w!==1)return '';const prev=db.seasons.filter(x=>x.id<s.id&&latest(x)===x.weeks&&!!playoffChampion(x)).at(-1);const fixturesText=fixtures(s,1).map(([a,b])=>safe(name(a,s))+' vs '+safe(name(b,s))).join(' · ');const returning=prev?teams(s).filter(t=>teams(prev).includes(t)).map(t=>name(t,s)):[];const intro=prev?`Defending League Champions: ${safe(name(stats(prev,prev.weeks)[0].t,prev))}. Defending Championship Winners: ${safe(name(playoffChampion(prev),prev))}. ${returning.length} of this season's teams also competed last season.`:'The first season begins with ten teams and a fresh title race.';return `<details class="notice" open><summary><strong>Opening Day Special · Season ${s.id}</strong></summary><p>${intro}</p><p><strong>Week 1 fixtures:</strong> ${fixturesText}</p><p>All teams begin with a clean slate. No future results are included in this preview.</p></details>`} 
function rlWeekHistory(s,w){if(w<1)return '';const old=db.seasons.filter(x=>x.id<s.id&&latest(x)>=w);const matches=old.flatMap(x=>fixtures(x,w).map(([a,b],i)=>({x,a,b,score:x.results[w]?.[i]})).filter(z=>Array.isArray(z.score))).sort((a,b)=>(b.score[0]+b.score[1])-(a.score[0]+a.score[1]));if(!matches.length)return '';return `<details class="notice"><summary><strong>This Week in League History · Week ${w}</strong></summary>${matches.slice(0,3).map(m=>`<p>Season ${m.x.id}: ${safe(name(m.a,m.x))} ${m.score[0]}–${m.score[1]} ${safe(name(m.b,m.x))}</p>`).join('')}</details>`}
function rlRevengePreview(s,w){if(w<1||w>s.weeks)return '';const prev=db.seasons.filter(x=>x.id<s.id),notes=[];for(const [a,b] of fixtures(s,w)){const na=name(a,s),nb=name(b,s);for(const old of [...prev].reverse()){const matches=analyticsGames(old,latest(old)).filter(g=>[g.a,g.b].sort().join('|')===[a,b].sort().join('|'));if(matches.length){const g=matches.at(-1),winner=g.x>g.y?name(g.a,old):name(g.b,old),loser=g.x>g.y?name(g.b,old):name(g.a,old);notes.push(`${na} vs ${nb}: last regular-season meeting was won by ${winner} against ${loser} (Season ${old.id}, Week ${g.w}).`);break}}}return notes.length?`<details class="notice"><summary><strong>Previous Meetings & Potential Revenge Matches</strong></summary>${notes.slice(0,5).map(n=>`<p>${safe(n)}</p>`).join('')}</details>`:''}
function rlMilestones(s,w){if(w<1||!complete(s,w))return '';const before={},after={};for(const old of db.seasons){if(old.id>s.id)continue;for(const g of analyticsGames(old,old.id===s.id?w:latest(old))){for(const [t,goals,win] of [[g.a,g.x,g.x>g.y],[g.b,g.y,g.y>g.x]]){const o=after[t]||(after[t]={goals:0,wins:0});o.goals+=goals;o.wins+=Number(win)}}}for(const old of db.seasons){if(old.id>s.id)continue;for(const g of analyticsGames(old,old.id===s.id?w-1:latest(old))){for(const [t,goals,win] of [[g.a,g.x,g.x>g.y],[g.b,g.y,g.y>g.x]]){const o=before[t]||(before[t]={goals:0,wins:0});o.goals+=goals;o.wins+=Number(win)}}}const out=[];for(const [t,a] of Object.entries(after)){const b=before[t]||{goals:0,wins:0};for(const [key,unit,step] of [['wins','career wins',50],['goals','career goals',100]]){const n=Math.floor(a[key]/step)*step;if(n>=step&&b[key]<n)out.push(`${t==='Custom'?db.customName:t} reached ${n} ${unit}.`)}}return out.length?`<div class="notice"><strong>Career Milestones</strong>${out.map(x=>`<p>${safe(x)}</p>`).join('')}</div>`:''}
