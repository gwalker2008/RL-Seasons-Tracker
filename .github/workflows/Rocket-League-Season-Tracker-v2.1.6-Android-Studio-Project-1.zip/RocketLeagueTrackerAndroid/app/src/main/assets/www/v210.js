'use strict';
/* Rocket League Season Tracker v2.1.0 — major milestone & prestige upgrade.
   Additive views: pre-existing match results, career IDs, honours and JSON format remain intact. */

// Simulation-only seasons may have ten AI teams and no human entrant.
// Manual seasons retain exactly nine AI entrants and the Custom team.
validCareer = function(v){
 return !!v && Array.isArray(v.seasons) && v.seasons.length>0 && v.seasons.every(s=>
  s && Array.isArray(s.ai) && (s.customAbsent===true ? s.ai.length===10 && !s.ai.includes('Custom') : s.ai.length===9));
};
teams = function(s){return s.customAbsent===true ? [...s.ai] : ['Custom',...s.ai]};
standardFixtures = function(s,w){
 let a=teams(s), rounds=[];
 if(a.length!==10) return [];
 for(let r=0;r<9;r++){
  rounds.push(Array.from({length:5},(_,i)=>[a[i],a[9-i]]));
  a=[a[0],a[9],...a.slice(1,9)];
 }
 return rounds[(w-1)%9].map(p=>{
  const q=Math.floor((w-1)/9)%2?[p[1],p[0]]:[...p];
  return q[1]==='Custom'?[q[1],q[0]]:q;
 });
};

let rl210DataCache=null,rl210SunCounter=0,rl210SecretState=null;
function rl210Data(){
 if(!rl210DataCache)rl210DataCache=rlMilestoneData();
 return rl210DataCache;
}
function rl210Invalidate(){rl210DataCache=null}
const rl210OriginalRender=render;
render=function(){return rl210OriginalRender()};
const rl210OriginalRenderOther=renderOther;
renderOther=function(){return rl210OriginalRenderOther()};

function rl210Prestige(t,seasonId=Infinity,week=Infinity){
 const revealed=db.mythicRevealed||{};
 if(!Object.values(revealed).some(Boolean))return null;
 const events=rl210Data().team[t]?.events||[];
 let level=null;
 for(const e of events){
  if(!['Mythic','Godly'].includes(e.tier)||!revealed[e.season])continue;
  if(e.season>seasonId||e.season===seasonId&&e.week>week)continue;
  if(e.tier==='Godly')return 'godly';
  level='mythic';
 }
 return level;
}
function rl210Sun(){
 const id='rl210sun'+(++rl210SunCounter);
 return `<svg class="rl210-rainbow-sun" viewBox="0 0 24 24" role="img" aria-label="Godly prestige"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff626c"/><stop offset=".18" stop-color="#ffc34b"/><stop offset=".35" stop-color="#f5ed68"/><stop offset=".5" stop-color="#5eec94"/><stop offset=".67" stop-color="#57d9ff"/><stop offset=".84" stop-color="#8694ff"/><stop offset="1" stop-color="#f17fdd"/></linearGradient></defs><g fill="none" stroke="url(#${id})" stroke-linecap="round" stroke-width="1.9"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></g></svg>`;
}
function rl210PrestigeMark(t,seasonId=Infinity,week=Infinity){
 const level=rl210Prestige(t,seasonId,week);
 return level==='godly'?`<span class="rl210-name-prestige" title="Godly prestige">${rl210Sun()}</span>`:
  level==='mythic'?'<span class="rl210-name-prestige rl210-mythic-gem" title="Mythic prestige"><svg viewBox="0 0 24 24" aria-label="Mythic prestige" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 3h12l5 6-11 12L1 9Z M1 9h22M6 3l6 18L18 3"/></svg></span>':'';
}
function rl210LogoWrap(html,level){
 if(!level)return html;
 return `<span class="rl210-prestige-logo rl210-${level}" title="${level==='godly'?'Godly':'Mythic'} prestige">${html}</span>`;
}
const rl210PlainIcon=icon;
icon=function(t,contextSeason=null,contextWeek=null){
 const s=contextSeason||season(),id=s?.id??Infinity;
 const week=contextWeek===null?selectedWeek:contextWeek;
 return rl210LogoWrap(rl210PlainIcon(t),rl210Prestige(t,id,week));
};
rlLegacyIcon=function(t){return rl210LogoWrap(rl210PlainIcon(t),rl210Prestige(t))};

function rl210HistoricalLogo(t,seasonId,week){
 const old=db.seasons.find(s=>s.id===seasonId);
 const src=t==='Custom'?(old?.badge||db.customLogo):null;
 const base=src?`<span class="logo-slot logo-custom"><img class="logo" src="${safe(src)}" alt="" loading="lazy" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span class="logo-fallback" hidden>${safe((old?.customName||db.customName||'?')[0])}</span></span>`:rl210PlainIcon(t);
 return rl210LogoWrap(base,rl210Prestige(t,seasonId,week));
}
function rl210FirstBadge(){return '<span class="rl210-first" title="First team in league history to earn this milestone">No1</span>'}
function rl210TierSymbol(tier){
 const paths={
  Mythic:'<path d="M6 3h12l5 6-11 12L1 9Z M1 9h22M6 3l6 18L18 3"/>',
  Legendary:'<path d="m2 7 5 4 5-7 5 7 5-4-2 13H4L2 7Z M4 20h16"/>',
  Major:'<circle cx="12" cy="16" r="5"/><path d="m7 3 3 8m7-8-3 8M7 3h10"/>',
  Standard:'<circle cx="12" cy="10" r="6"/><path d="m8 15-2 7 6-3 6 3-2-7"/>'
 };
 return tier==='Godly'?rl210Sun():paths[tier]?`<svg class="rl210-tier-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" aria-hidden="true">${paths[tier]}</svg>`:'';
}
rlTierBadge=function(tier){
 return `<span class="rl-tier rl-tier-${safe(tier)}"><span class="rl210-tier-symbol">${rl210TierSymbol(tier)}</span>${tier==='Godly'?'<span class="rl211-rainbow-word">Godly</span>':safe(tier)}</span>`;
};
rlMilestoneCard=function(e){
 return `<article class="rl-milestone-card" data-milestone-tier="${safe(e.tier)}" data-milestone-team="${safe(e.t)}" data-career-first="${e.first?'yes':'no'}"><div class="rl-award-names">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong>${e.first?rl210FirstBadge(e.tier):''}</div><div class="rl210-card-team">${rl210HistoricalLogo(e.t,e.season,e.week-1)}<span>${safe(name(e.t,db.seasons.find(s=>s.id===e.season)||season()))} · Season ${e.season} · Week ${e.week}</span>${rl210PrestigeMark(e.t,e.season,e.week-1)}</div></article>`;
};

// A personal collection is distinct from the league-wide, pageable Hall of Fame.
let rl210HallTier='All',rl210HallTeam='All',rl210HallPage=0,rl210HallOpen=false;
function rl210ChooseTeam(id){window.rlSelectedLegacy=id;rl210HallPage=0;renderOther()}
function rl210ChangeHallFilter(type,value){
 if(type==='tier')rl210HallTier=value;
 else rl210HallTeam=value;
 rl210HallPage=0;renderOther();
}
function rl210HallPageMove(delta){rl210HallPage=Math.max(0,rl210HallPage+delta);rl210HallOpen=true;renderOther()}
function rl210Collection(data,teamId){
 const earned=data.team[teamId].events.filter(rlMilestoneVisible);
 const groups=RL_TIERS.map(tier=>{
  const tierEvents=earned.filter(e=>e.tier===tier);
  const distinct=new Set(tierEvents.map(e=>e.title)).size,id=tier.toLowerCase();
  return `<details class="rl210-rarity rl210-rarity-${id}" data-tier="${id}" data-team="${safe(teamId)}" ontoggle="rl211LoadRarity(this)"><summary>${rlTierBadge(tier)}<span>${distinct} achievements · ${tierEvents.length} occurrences</span><span class="rl210-chevron">⌄</span></summary><div class="rl210-rarity-content"></div></details>`;
 }).join('');
 return `<section class="rl210-collection"><h3>✨ ${rlTitle(teamId)}'s Milestone Collection</h3><p class="muted">Only this team's revealed achievements. Rarities stay highest first; within each rarity, the most recently earned milestone is first. Expand an achievement to see every earning season.</p>${groups}</section>`;
}

function rl210Trophies(r){
 const doubles=r.league.filter(id=>r.champ.includes(id));
 const groups=[{label:'League Titles',hint:'Regular-season winners',icon:'🥇',ids:r.league,cls:'league'},
 {label:'Championships',hint:'Playoff winners',icon:'🏆',ids:r.champ,cls:'champ'},
 {label:'Doubles',hint:'Both titles in the same season',icon:'💎',ids:doubles,cls:'double'}];
 const shelves=`<div class="rl210-cabinet-shelf">${groups.map(g=>`<div class="rl210-shelf-piece"><div class="rl210-shelf-icon">${g.icon}</div><b>${g.ids.length}</b><small>${g.label}</small></div>`).join('')}<div class="rl210-wood-shelf"></div></div>`;
 const cards=`<div class="rl210-trophy-cards">${groups.map(g=>`<details class="rl210-trophy-card rl210-trophy-${g.cls}"><summary><span class="rl210-trophy-symbol">${g.icon}</span><span><strong>${g.ids.length}</strong><small>${g.label}</small></span><span class="rl210-chevron">⌄</span></summary><p class="muted">${g.hint}</p><div class="rl210-trophy-history">${g.ids.length?rl211TrophyYears(g.ids):'None earned yet'}</div></details>`).join('')}</div>`;
 return `<section class="rl210-cabinet">${shelves}${cards}<div class="rl210-total"><span>Total major trophies</span><b>${r.champ.length+r.league.length}</b></div><p class="muted">Doubles are special combined honours, not additional trophies.</p></section>`;
}
rlMilestonePage=function(){
 const data=rl210Data(),profiles=Object.values(data.team);
 const selected=window.rlSelectedLegacy||'Custom',r=data.team[selected]||profiles[0];
 const firsts=r.firsts.filter(rlMilestoneVisible).slice().sort((a,b)=>a.season-b.season||a.week-b.week);
 const all=data.events.filter(rlMilestoneVisible).slice().sort((a,b)=>b.season-a.season||b.week-a.week);
 const filtered=all.filter(e=>(rl210HallTier==='All'||e.tier===rl210HallTier)&&(rl210HallTeam==='All'||e.t===rl210HallTeam));
 const perPage=80,pages=Math.max(1,Math.ceil(filtered.length/perPage));rl210HallPage=Math.min(rl210HallPage,pages-1);
 const page=filtered.slice(rl210HallPage*perPage,(rl210HallPage+1)*perPage);
 const nameOptions=profiles.map(x=>`<option value="${safe(x.id)}" ${x.id===r.id?'selected':''}>${rlTitle(x.id)}</option>`).join('');
 const teamOptions=profiles.map(x=>`<option value="${safe(x.id)}" ${rl210HallTeam===x.id?'selected':''}>${rlTitle(x.id)}</option>`).join('');
 return `<h2>🏅 Milestone Centre</h2><p class="muted">Godly → Mythic → Legendary → Major → Standard. Hidden achievements appear only after the Awards Ceremony.</p>
 ${rl212Watch(data)}
 <h3>Team Legacy Profiles</h3><label>Choose team<select onchange="rl210ChooseTeam(this.value)">${nameOptions}</select></label>
 <div class="rl-legacy-header">${rlLegacyIcon(r.id)}<div><h3>${rlTitle(r.id)} ${rl210PrestigeMark(r.id)}</h3><p>${r.seasons.length} seasons participated</p>${r.names.length>1?`<p class="muted">Historical names: ${safe(r.names.join(' → '))}</p>`:''}</div></div>
 <div class="rl-legacy-numbers">${[[r.wins,'Wins'],[r.losses,'Losses'],[r.gf,'Goals scored'],[r.ga,'Goals conceded'],[r.clean,'Clean sheets'],[r.playoffs.length,'Playoff qualifications'],[r.finals.length,'Finals reached'],[r.best,'Longest win streak']].map(x=>rlLegacyNumber(...x)).join('')}</div>
 <h3>🏆 Trophy Cabinet</h3>${rl210Trophies(r)}
 <details class="rl212-panel"><summary>Career Firsts (${firsts.length})</summary>${firsts.length?firsts.map(e=>`<div class="rl210-first-line">${rl210FirstBadge(e.tier)}<span>${safe(e.title)} <small>· Season ${e.season}, Week ${e.week}</small></span></div>`).join(''):'<p>No historical firsts recorded for this team.</p>'}</details>
 ${rl210Collection(data,r.id)}
 <details class="rl212-panel rl210-hall" ${rl210HallOpen?'open':''} ontoggle="rl210HallOpen=this.open"><summary>Milestone Hall of Fame — All teams (${all.length.toLocaleString()})</summary>
 <p class="muted">League-wide revealed history. Filters apply to ALL records before pagination, not just the current page.</p>
 <div class="rl-filterline"><label>Rarity<select onchange="rl210ChangeHallFilter('tier',this.value)"><option ${rl210HallTier==='All'?'selected':''}>All</option>${RL_TIERS.map(x=>`<option ${rl210HallTier===x?'selected':''}>${x}</option>`).join('')}</select></label><label>Team<select onchange="rl210ChangeHallFilter('team',this.value)"><option ${rl210HallTeam==='All'?'selected':''}>All</option>${teamOptions}</select></label></div>
 <div class="row"><button onclick="rl210HallPageMove(-1)" ${rl210HallPage===0?'disabled':''}>← Newer</button><span>${filtered.length.toLocaleString()} matches · Page ${rl210HallPage+1} of ${pages}</span><button onclick="rl210HallPageMove(1)" ${rl210HallPage>=pages-1?'disabled':''}>Older →</button></div>
 <div id="rlMilestoneHall">${page.map(rlMilestoneCard).join('')||'<p>No matching milestones.</p>'}</div></details>`;
};

// Secret awards: reveal each team's Mythics together, fewest first; higher
// league finisher reveals later when Mythic counts tie. Godly is always last.
function rl210RevealSequence(s){
 const all=rl210Data().events.filter(e=>e.season===s.id&&['Mythic','Godly'].includes(e.tier));
 const group=(tier)=>{
  const teamsMap=new Map();for(const e of all.filter(x=>x.tier===tier)){
   if(!teamsMap.has(e.t))teamsMap.set(e.t,[]);teamsMap.get(e.t).push(e);
  }
  const ranks=stats(s,s.weeks).map(x=>x.t);
  return [...teamsMap].map(([t,events])=>({tier,t,events})).sort((a,b)=>
   (tier==='Mythic'?a.events.length-b.events.length:0)||
   ranks.indexOf(b.t)-ranks.indexOf(a.t)||a.t.localeCompare(b.t));
 };
 return [...group('Mythic'),...group('Godly')];
}
function rl210RenderSecret(){
 const st=rl210SecretState,s=season(),step=st?.groups[st.index];if(!step)return false;
 const godly=step.tier==='Godly';
 const displayLogo=rl210LogoWrap(rl210PlainIcon(step.t),godly?'godly':'mythic');
 $('other').innerHTML=`<div class="ceremony-stage ceremony-final rl210-secret ${godly?'rl210-secret-godly':'rl210-secret-mythic'}" role="dialog" aria-modal="true" aria-label="Secret ${step.tier} milestone reveal"><div class="ceremony-spotlight one"></div><div class="ceremony-spotlight two"></div><div class="ceremony-top"><span>SEASON ${s.id} · SECRET HONOURS</span><span>REVEAL ${st.index+1} / ${st.groups.length}</span></div><div class="ceremony-center"><div class="rl210-reveal-label">${godly?rl210Sun():'◆'} ${step.tier.toUpperCase()} REVEAL</div><div class="rl210-reveal-logo">${displayLogo}</div><div class="ceremony-big">${rlTitle(step.t)}</div><div class="rl210-reveal-achievements">${step.events.map(e=>`<div class="rl210-reveal-award">${rlTierBadge(e.tier)}<strong>${safe(e.title)}</strong>${e.first?rl210FirstBadge(e.tier):''}</div>`).join('')}</div><p class="muted">${step.events.length} ${step.tier} achievement${step.events.length===1?'':'s'} earned this season · Permanent prestige unlocked after the ceremony</p></div><div class="ceremony-actions"><button class="ceremony-primary" onclick="rlFinishMythicReveal()">${st.index===st.groups.length-1?'Complete Secret Reveals':'Continue to Next Reveal'} ▶</button></div></div>`;
 return true;
}
rlMythicReveal=function(s){
 if(db.mythicRevealed?.[s.id])return false;
 if(!rl210SecretState||rl210SecretState.season!==s.id){
  const groups=rl210RevealSequence(s);
  if(!groups.length)return false;
  rl210SecretState={season:s.id,index:0,groups};
 }
 return rl210RenderSecret();
};
rlFinishMythicReveal=function(){
 if(!rl210SecretState)return;
 rl210SecretState.index++;
 if(rl210SecretState.index<rl210SecretState.groups.length){rl210RenderSecret();return}
 db.mythicRevealed ||= {};
 db.mythicRevealed[rl210SecretState.season]=true;
 for(const run of db.huntHistory||[])if(run.sealed&&run.seasonId===rl210SecretState.season)run.sealed=false;
 rl210SecretState=null;rl210Invalidate();persist();
 ceremonyState.phase=7;renderAwards(season());
};
const rl210OriginalOpenCeremony=rlOpenCeremony;
rlOpenCeremony=function(){rl210SecretState=null;return rl210OriginalOpenCeremony()};

// Hunt promotion/relegation: two bottom clubs swap with the two currently
// inactive teams, from the full 12-club pool (11 AI plus Custom).
rl212HuntNewSeason=function(prev){
 const participants=teams(prev),ranked=stats(prev,prev.weeks).map(x=>x.t);
 const relegated=ranked.slice(-2);
 const waiting=['Custom',...AI].filter(t=>!participants.includes(t));
 if(participants.length!==10||waiting.length!==2)throw Error('Hunt promotion/relegation requires exactly 10 active and 2 inactive teams');
 const incoming=[...waiting]; // deterministic order, eligible absent teams only
 const nextTeams=[...participants.filter(t=>!relegated.includes(t)),...incoming];
 const ai=nextTeams.filter(t=>t!=='Custom');
 const s=makeSeason(ai.slice(0,9),prev.mode);
 s.customAbsent=!nextTeams.includes('Custom');s.ai=ai;
 // makeSeason initially built a fixture normalization for Custom + nine AI.
 // Discard it whenever the roster has changed, especially Custom-absent years.
 s.fixtures={};s.customAlwaysHomeV1=true;
 s.weeks=prev.weeks;s.playoffCount=prev.playoffCount;s.humanName=prev.humanName;
 s.botNames=[...prev.botNames];s.badge=prev.badge;s.customName=db.customName;
 s.id=db.seasons.at(-1).id+1;
 s.huntRotation={relegated:[...relegated],promoted:[...incoming]};
 db.seasons.push(s);db.active=db.seasons.length-1;
 return s;
};
function rl210PrepareAfterStop(){
 const prev=season();if(!prev||!playoffChampion(prev))return;
 let ai;
 if(prev.customAbsent){
  const standings=stats(prev,prev.weeks).map(x=>x.t);
  ai=standings.slice(0,9); // replaces the last-ranked AI with Custom
 }else ai=prev.ai.slice(0,9);
 const next=makeSeason(ai,prev.mode);next.weeks=prev.weeks;
 next.playoffCount=prev.playoffCount;next.humanName=prev.humanName;
 next.botNames=[...prev.botNames];next.badge=prev.badge;
 next.id=prev.id+1;next.customName=db.customName;
 db.seasons.push(next);db.active=db.seasons.length-1;selectedWeek=0;
}
const rl210OriginalHuntFinish=rl212HuntFinish;
rl212HuntFinish=function(success,rarity,reason){
 const h=rl212Hunt;
 if(!success&&h?.stopped&&playoffChampion(season()))rl210PrepareAfterStop();
 return rl210OriginalHuntFinish(success,rarity,reason);
};

// Preserve manual next-season setup when the simulated last season had no Custom.
const rl210OriginalBeginSetup=beginSetup;
beginSetup=function(next=false){
 const result=rl210OriginalBeginSetup(next);
 if(next&&setup&&season().customAbsent){
  setup.ai=stats(season(),season().weeks).slice(0,9).map(r=>r.t);
  if(setupStep>=2)renderWizard();
 }
 return result;
};
