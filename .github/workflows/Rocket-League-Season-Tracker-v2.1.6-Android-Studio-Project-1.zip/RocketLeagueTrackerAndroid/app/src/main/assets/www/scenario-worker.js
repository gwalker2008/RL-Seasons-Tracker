// v0.9.3 Career Scenario Lab: synthetic, independently randomized career histories.
// All data stays inside this worker. No career or storage writes.
self.onmessage=e=>{
 const {runs,teams,games,playoffCount=6}=e.data;
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const sigmoid=x=>1/(1+Math.exp(-x));
 const count={upsets:0,decided:0,bottomQualified:0,bottomSlots:0,bottomChamp:0,favoriteTitle:0,favoriteChamp:0,topSixFavorites:0,rankMoves:0,scenarios:0};
 const styles={balanced:0,mixed:0,polarized:0};
 const samples=[];
 function poisson(mean){const L=Math.exp(-mean);let p=1,k=0;do{k++;p*=Math.random()}while(p>L&&k<30);return k-1}
 const winner=(a,b,power,latent)=>Math.random()<clamp(sigmoid((power[a]-power[b])*.85+latent[a]-latent[b]),.07,.93)?a:b;
 let i=0;
 function batch(){
  const end=Math.min(runs,i+10);
  for(;i<end;i++){
   // Each scenario has a different career-history shape and randomized history for every team.
   const style=i%3===0?'balanced':i%3===1?'mixed':'polarized';styles[style]++;
   const spread=style==='balanced'?.12:style==='mixed'?.5:1.0;
   const history={},power={},attack={},defense={};
   for(const t of teams){
    const ability=(Math.random()+Math.random()+Math.random()+Math.random()-2)*spread;
    const n=12+Math.floor(Math.random()*37);let wins=0,gf=0,ga=0;
    const p=clamp(sigmoid(ability),.08,.92);
    for(let j=0;j<n;j++){if(Math.random()<p)wins++;gf+=poisson(2.4*Math.exp(.20*ability));ga+=poisson(2.4*Math.exp(-.20*ability))}
    history[t]={w:wins,l:n-wins,gf,ga,n};
    const h=history[t],historical=(h.w+10)/(h.w+h.l+20);
    power[t]=Math.log(historical/(1-historical));
    const weight=Math.min(10,h.n);
    attack[t]=Math.log(((h.gf/h.n)*weight+2.4*12)/(weight+12)/2.4);
    defense[t]=Math.log(((h.ga/h.n)*weight+2.4*12)/(weight+12)/2.4);
   }
   const seeded=teams.slice().sort((a,b)=>power[b]-power[a]);
   const rank=Object.fromEntries(seeded.map((t,j)=>[t,j]));
   const st=Object.fromEntries(teams.map(t=>[t,{t,w:0,gf:0,ga:0}]));
   const latent=Object.fromEntries(teams.map(t=>[t,(Math.random()+Math.random()+Math.random()-1.5)*.12]));
   let lastWeek=0;
   for(const g of games){
    if(g.w!==lastWeek){for(const t of teams)latent[t]=clamp(.94*latent[t]+(Math.random()+Math.random()+Math.random()-1.5)*.06,-.45,.45);lastWeek=g.w}
    const a=g.a,b=g.b;
    const diff=power[a]-power[b]+latent[a]-latent[b];
    const ma=clamp(2.4*Math.exp(.20*diff+.17*(attack[a]-defense[b])),.65,5.4);
    const mb=clamp(2.4*Math.exp(-.20*diff+.17*(attack[b]-defense[a])),.65,5.4);
    let ga=poisson(ma),gb=poisson(mb);
    if(ga===gb){if(winner(a,b,power,latent)===a)ga++;else gb++}
    st[a].gf+=ga;st[a].ga+=gb;st[b].gf+=gb;st[b].ga+=ga;
    const won=ga>gb?a:b;st[won].w++;
    if(rank[a]!==rank[b]){count.decided++;if(rank[won]>rank[won===a?b:a])count.upsets++}
   }
   const sorted=Object.values(st).sort((a,b)=>b.w-a.w||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||a.t.localeCompare(b.t));
   const bottom=seeded.slice(playoffCount),bottomSet=new Set(bottom);
   const qualified=sorted.slice(0,playoffCount).filter(x=>bottomSet.has(x.t)).length;
   count.bottomQualified+=qualified;count.bottomSlots+=playoffCount;
   count.rankMoves+=sorted.reduce((sum,x,j)=>sum+Math.abs(rank[x.t]-j),0)/teams.length;
   if(sorted[0].t===seeded[0])count.favoriteTitle++;
   count.topSixFavorites+=sorted.slice(0,playoffCount).filter(x=>rank[x.t]<playoffCount).length;
   let s1,s2;
   if(playoffCount===4){s1=winner(sorted[0].t,sorted[3].t,power,latent);s2=winner(sorted[1].t,sorted[2].t,power,latent)}
   else{const q1=winner(sorted[2].t,sorted[5].t,power,latent),q2=winner(sorted[3].t,sorted[4].t,power,latent);s1=winner(sorted[0].t,q2,power,latent);s2=winner(sorted[1].t,q1,power,latent)}
   const champ=winner(s1,s2,power,latent);
   if(champ===seeded[0])count.favoriteChamp++;
   if(bottomSet.has(champ))count.bottomChamp++;
   if(samples.length<5)samples.push({style,topSeed:seeded[0],title:sorted[0].t,champ,bottomQualified:qualified});
   count.scenarios++;
  }
  postMessage({progress:i});
  if(i<runs){setTimeout(batch,0);return}
  postMessage({done:true,runs,playoffCount,stats:{upsetRate:100*count.upsets/Math.max(1,count.decided),bottomQualificationRate:100*count.bottomQualified/runs,qualificationSlotsTakenByBottom:100*count.bottomQualified/(runs*playoffCount),bottomChampionRate:100*count.bottomChamp/runs,favoriteTitleRate:100*count.favoriteTitle/runs,favoriteChampionRate:100*count.favoriteChamp/runs,averageRankMovement:count.rankMoves/runs},styles,samples});
 }
 batch();
};
