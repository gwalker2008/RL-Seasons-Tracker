'use strict';
/* v2.1.2 Turbo Hunt. Runs the ORIGINAL match scoring, season transition,
   stats and milestone implementations inside a dedicated browser Web Worker.
   Completed seasons are returned to the UI in order; UI ACKs ONLY after IDB commit. */
self.window=self;
self.document={getElementById:()=>null,querySelector:()=>null,addEventListener:()=>{},body:{classList:{toggle(){}}}};
self.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};
self.alert=()=>{};self.confirm=()=>true;
self.matchMedia=()=>({matches:true});
importScripts('./app.js','./milestones.js','./v212.js','./v210.js','./storage212.js','./v211.js');
let lastSentIndex=-1,completedTotal=0,jobActive=false,outcome=null;
// Saving happens on the owner thread. The worker never writes and never tells
// the owner it is safe to discard data before an explicit durable acknowledgement.
rl211JournalSeason=function(){return true};
rl212QueueWrite=function(){};
persist=function(){return true};
rl212HuntFinish=function(success,rarity,reason){
 const h=rl212Hunt;if(!h)return;
 if(!success&&h.stopped&&playoffChampion(season()))rl210PrepareAfterStop();
 outcome={success,rarity,reason:reason||null,seasons:h.seasons,seasonId:season()?.id||null,target:h.target,stopped:!!h.stopped};
 completedTotal=h.seasons;rl212Hunt=null;
};
function flushBatch(workerComputeMs=0){
 const s=season(),last=db.seasons.length-1;
 const lastCompleted=playoffChampion(s)?last:last-1;
 const completed=lastCompleted>lastSentIndex?db.seasons.slice(lastSentIndex+1,lastCompleted+1):[];
 lastSentIndex=lastCompleted;
 const extra=outcome?.stopped && last>lastCompleted ? db.seasons[last]:null;
 postMessage({type:'batch',completed,extra,outcome,completedTotal:rl212Hunt?.seasons??completedTotal,
  lastSeasonId:lastCompleted>=0?db.seasons[lastCompleted].id:0,workerTime:performance.now(),workerComputeMs});
}
function runBatch(budgetMs=48){
 if(!jobActive)return;
 try{
  const begin=performance.now();let iterations=0;
  // Time is a cooperative yield budget, NOT a throughput/season cap.
  // Simulate as many real weeks/seasons as this CPU can finish in the budget.
  while(rl212Hunt&&performance.now()-begin<Math.max(16,Math.min(320,budgetMs))){
   if(!rl211HuntStep())break;
   iterations++;
  }
  completedTotal=rl212Hunt?.seasons??completedTotal;
  const computeMs=performance.now()-begin;
  flushBatch(computeMs);
 }catch(e){
  console.error('Turbo Hunt worker failure',e);
  const h=rl212Hunt;
  outcome={success:false,rarity:null,reason:'Simulation error: '+String(e.message||e),seasons:h?.seasons||completedTotal,
   seasonId:season()?.id,target:h?.target||'either',stopped:false};
  rl212Hunt=null;
  flushBatch();
 }
}
self.onmessage=e=>{
 const m=e.data||{};
 if(m.type==='start'){
  try{
   db=m.career;db.seasons.forEach(s=>{s.playerStats ||= {};s.playoffPlayerStats ||= {};});
   db.active=db.seasons.length-1;
   const s=season();lastSentIndex=playoffChampion(s)?db.seasons.length-1:db.seasons.length-2;
   completedTotal=0;outcome=null;jobActive=true;
   rl211HuntEvidence=null;rl211JournalFailed=false;
   rl212Hunt={target:m.target,cap:m.cap,streaks:m.streaks||rl212HuntInitStreaks(),runs:m.seedRuns||null,seasons:0,mythicThisSeason:!!m.currentHundred,stopped:false,history:null};
   postMessage({type:'ready'});
  }catch(error){postMessage({type:'fatal',message:String(error.message||error)})}
 }else if(m.type==='next'){
  if(jobActive&&rl212Hunt)runBatch(m.budgetMs);
 }else if(m.type==='stop'){
  if(rl212Hunt)rl212Hunt.stopped=true;
 }else if(m.type==='terminate'){
  jobActive=false;close();
 }
};
