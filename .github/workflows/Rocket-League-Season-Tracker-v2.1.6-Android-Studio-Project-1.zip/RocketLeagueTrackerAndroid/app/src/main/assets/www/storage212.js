'use strict';
/* v2.1.1 — compatible IndexedDB snapshot + per-season crash-safe Hunt journal.
   The original complete JSON remains the canonical export format. */
let rl212DbHandle=null,rl212StorageOpening=null,rl212WriteTimer=null,rl212PendingSnapshot=null;
let rl212WriteInProgress=false,rl211JournalFailed=false,rl211RecoveredSeasons=0,rl211JournalPending=0;
let rl211ForceJournalReset=false,rl212LastSnapshotFailure=null;
function rl211PrepareReplacement(){rl211ForceJournalReset=true}
const RL212_IDB_NAME='rocket-league-tracker-career-v212';
const RL212_IDB_STORE='career';
const RL211_JOURNAL_STORE='huntSeasons';
function rl212OpenStorage(){
 if(rl212StorageOpening)return rl212StorageOpening;
 rl212StorageOpening=new Promise(resolve=>{
  if(typeof indexedDB==='undefined'){resolve(null);return}
  try{
   const req=indexedDB.open(RL212_IDB_NAME,2);
   req.onupgradeneeded=()=>{
    if(!req.result.objectStoreNames.contains(RL212_IDB_STORE))req.result.createObjectStore(RL212_IDB_STORE);
    if(!req.result.objectStoreNames.contains(RL211_JOURNAL_STORE))req.result.createObjectStore(RL211_JOURNAL_STORE);
   };
   req.onsuccess=()=>{rl212DbHandle=req.result;resolve(rl212DbHandle)};
   req.onerror=()=>{console.warn('IndexedDB unavailable; legacy save retained');resolve(null)};
   req.onblocked=()=>{console.warn('IndexedDB upgrade blocked by another tab');resolve(null)};
  }catch(e){resolve(null)}
 });
 return rl212StorageOpening;
}
async function rl212LoadDatabase(){
 const idb=await rl212OpenStorage();if(!idb)return null;
 return new Promise(resolve=>{
  try{
   const tx=idb.transaction([RL212_IDB_STORE,RL211_JOURNAL_STORE],'readonly');
   const baseReq=tx.objectStore(RL212_IDB_STORE).get('latest');
   const journalReq=tx.objectStore(RL211_JOURNAL_STORE).getAll();
   const metaReq=tx.objectStore(RL211_JOURNAL_STORE).get('__hunt_meta_v212');
   tx.oncomplete=()=>{
    try{
     if(!baseReq.result){resolve(null);return}
     const parsed=JSON.parse(baseReq.result);
     if(!validCareer(parsed)){resolve(null);return}
     const entries=(journalReq.result||[]).filter(x=>x&&x.id&&Array.isArray(x.ai)).sort((a,b)=>a.id-b.id);
     if(entries.length){
      const positions=new Map(parsed.seasons.map((s,i)=>[s.id,i]));
      for(const s of entries){
       if(positions.has(s.id)){parsed.seasons[positions.get(s.id)]=s}
       else{positions.set(s.id,parsed.seasons.length);parsed.seasons.push(s)}
      }
      parsed.active=positions.get(entries.at(-1).id);
      rl211RecoveredSeasons=entries.length;
     }
     const meta=metaReq.result;
     if(meta&&Number.isFinite(meta.lastCommittedId)&&entries.some(x=>x.id===meta.lastCommittedId)){
      parsed.huntHistory=Array.isArray(meta.huntHistory)?meta.huntHistory:parsed.huntHistory;
      if(Number.isFinite(meta.activeId)){const idx=parsed.seasons.findIndex(s=>s.id===meta.activeId);if(idx>=0)parsed.active=idx}
     }
     resolve(parsed);
    }catch(e){console.error('Could not read career snapshot/journal',e);resolve(null)}
   };
   tx.onerror=()=>resolve(null);
   tx.onabort=()=>resolve(null);
  }catch(e){resolve(null)}
 });
}
// Each completed Hunt season is saved by itself, not as a re-serialised 14MB career.
// A journal transaction is atomic; after interruption the last completed season can
// be replayed onto the last full snapshot at next startup.
function rl211JournalSeason(s){
 if(!rl212DbHandle||rl211JournalFailed)return false;
 try{
  const tx=rl212DbHandle.transaction(RL211_JOURNAL_STORE,'readwrite');
  tx.objectStore(RL211_JOURNAL_STORE).put(s,s.id);
  rl211JournalPending++;
  tx.oncomplete=()=>{rl211JournalPending=Math.max(0,rl211JournalPending-1)};
  tx.onerror=()=>{rl211JournalPending=Math.max(0,rl211JournalPending-1);rl211JournalFailed=true;console.error('Hunt season could not be saved; stop and export a backup')};
  tx.onabort=()=>{rl211JournalPending=Math.max(0,rl211JournalPending-1);rl211JournalFailed=true;console.error('Hunt season transaction aborted')};
  return true;
 }catch(e){rl211JournalFailed=true;console.error('Hunt journal failure',e);return false}
}
function rl212QueueWrite(snapshot,checkpointId,forceClear=false){
 if(!rl212DbHandle)return;
 rl212PendingSnapshot={raw:snapshot,checkpointId,forceClear:forceClear||!!rl212PendingSnapshot?.forceClear};
 if(rl212WriteTimer!==null)return;
 rl212WriteTimer=setTimeout(rl212FlushWrite,80);
}
function rl212FlushWrite(){
 rl212WriteTimer=null;
 if(rl212WriteInProgress||!rl212DbHandle||rl212PendingSnapshot===null)return;
 rl212WriteInProgress=true;
 const {raw,checkpointId,forceClear}=rl212PendingSnapshot;rl212PendingSnapshot=null;
 try{
  // The journal is cleared in the SAME transaction as committing a complete snapshot.
  const tx=rl212DbHandle.transaction([RL212_IDB_STORE,RL211_JOURNAL_STORE],'readwrite');
  tx.objectStore(RL212_IDB_STORE).put(raw,'latest');
  // Only erase journal seasons already covered by this particular snapshot.
  // An older pending snapshot must never erase newly completed Hunt seasons.
  const journal=tx.objectStore(RL211_JOURNAL_STORE);
  if(forceClear)journal.clear();
  else{
   const cursorReq=journal.openCursor();
   cursorReq.onsuccess=()=>{const cursor=cursorReq.result;if(cursor){if(cursor.key==='__hunt_meta_v212'){const meta=cursor.value;if(Math.max(Number(meta?.lastCommittedId)||0,Number(meta?.activeId)||0)<=checkpointId)cursor.delete()}else if(Number(cursor.key)<=checkpointId)cursor.delete();cursor.continue()}};
  }
  tx.oncomplete=()=>{rl212LastSnapshotFailure=null;rl212WriteInProgress=false;if(rl212PendingSnapshot!==null)rl212FlushWrite()};
  tx.onerror=()=>{rl212LastSnapshotFailure=tx.error||Error('IndexedDB snapshot failed');rl212WriteInProgress=false;console.error('Full career IndexedDB save failed. Export a backup.');if(rl212PendingSnapshot!==null)rl212FlushWrite()};
  tx.onabort=()=>{rl212LastSnapshotFailure=tx.error||Error('IndexedDB snapshot aborted');rl212WriteInProgress=false;console.error('Full career transaction aborted. Export a backup.')};
 }catch(e){rl212LastSnapshotFailure=e;rl212WriteInProgress=false;console.error('Full career save failed',e)}
}
const rl212OriginalPersist=persist;
persist=function(){
 let raw;
 try{raw=JSON.stringify(db)}catch(e){console.error('Career serialization failed',e);return false}
 let localOkay=false;
 // Large JSON files exceed common localStorage quotas. Do not repeatedly attempt
 // two impossible writes; IndexedDB holds the full career and journal.
 if(raw.length<3_500_000){
  try{
   localStorage.setItem(KEY,raw);localOkay=true;
   try{localStorage.setItem(RECOVERY_KEY,raw)}catch(e){}
  }catch(e){if(!rl212DbHandle){console.error('Browser storage is full',e);return rl212OriginalPersist()}}
 }
 if(rl212DbHandle){const lastCompleted=[...db.seasons].reverse().find(s=>s.champion&&s.results?.[s.weeks]?.length===5);rl212QueueWrite(raw,lastCompleted?.id||0,rl211ForceJournalReset);rl211ForceJournalReset=false}
 saveLoadError=false;
 if(typeof rl210Invalidate==='function')rl210Invalidate();
 if(typeof rl211Invalidate==='function')rl211Invalidate();
 try{localStorage.removeItem('rl211_cursor_v1')}catch(e){}
 return localOkay||!!rl212DbHandle;
};
