'use strict';
// v2.0.11 – one stable, deterministic career-achievement engine, rebuilt from the
// actual saved games. Team keys never depend on display names.
const RL_TIERS = ['Godly', 'Mythic', 'Legendary', 'Major', 'Standard'];
const RL_GODLY='The Absolute Perfection';
const RL_MYTHICS = Object.freeze({
 impenetrable: 'The Impenetrable',
 eternal: 'The Eternal Champions',
 kings: 'Kings of the League',
 dynasty: 'The Ultimate Dynasty',
 hundred: 'The Unstoppable Hundred'
});
const RL_TEAM_IDS = ['Custom', ...AI];
const rlLabel = t => t === 'Custom' ? db.customName : t;
const rlTitle = t => safe(rlLabel(t));
let rlTierBadge = tier => `<span class="rl-tier rl-tier-${safe(tier)}">${safe(tier)}</span>`;
function rlLegacyIcon(t) {
 if(t!=='Custom') return icon(t);
 const img=db.customLogo || db.seasons.at(-1)?.badge || '';
 if(!img) return `<span class="logo-fallback">${safe((db.customName||'?')[0])}</span>`;
 return `<span class="logo-slot logo-custom"><img class="logo" src="${safe(img)}" alt="" loading="lazy" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span class="logo-fallback" hidden>${safe((db.customName||'?')[0])}</span></span>`;
}


function rlTimelineForSeason(s) {
 const out = [];
 // The only valid regular-season history is the contiguous completed weeks.
 for (let w = 1; w <= Math.min(latest(s), s.weeks); w++) {
  fixtures(s, w).forEach(([a, b], i) => {
   const score = s.results[w]?.[i];
   if (Array.isArray(score) && score.length === 2 && score[0] !== score[1])
    out.push({s, w, a, b, x:score[0], y:score[1], playoff:false});
  });
 }
 if (latest(s) === s.weeks) {
  playoffRounds(s).forEach((round, i) => round.matches.forEach(m => {
   if (m.a && m.b && m.score)
    out.push({s, w:s.weeks+i+1, a:m.a, b:m.b, x:m.score[0], y:m.score[1], playoff:true});
  }));
 }
 return out;
}
function rlTimeline() {
 return [...db.seasons].sort((a,b)=>a.id-b.id).flatMap(rlTimelineForSeason);
}
function rlResultFrom(g, t) {
 return g.a === t ? [g.x, g.y] : [g.y, g.x];
}
function rlMilestoneData() {
 const ids = [...new Set([...RL_TEAM_IDS,...db.seasons.flatMap(s => s.ai || [])])];
 const team = Object.fromEntries(ids.map(id => [id, {
  id, wins:0, losses:0, gf:0, ga:0, played:0, clean:0, streak:0, best:0,
  league:[], champ:[], finals:[], playoffs:[], seasons:[], names:[],
  firsts:[], events:[], seasonStats:[]
 }]));
 const events = [];
 const uniqueEvents = new Set();
 const oneTimeAwards = new Set();
 // Career counters / first-ever accomplishments are one-time per team. Seasonal
 // honours, independent streaks, and legitimately recurring rarities may repeat.
 const repeatable = title => title==='League Title' || title==='Championship Title' ||
   title==='League and Championship Double' || title==='League Title Drought Ended' ||
   title==='Championship Title Drought Ended' || title==='Back-to-Back League Titles' ||
   title==='Back-to-Back Championships' || title==='Back-to-Back Doubles' ||
   title==='Three Consecutive League Titles' || title==='Three Consecutive Championships' ||
   title==='Three Consecutive Doubles' || title.endsWith('-Match Winning Streak') ||
   Object.values(RL_MYTHICS).includes(title) || title===RL_GODLY;
 function award(t, s, week, title, tier='Standard', detail='') {
  if (!team[t]) return;
  const id = `${t}:${s.id}:${week}:${title}`;
  if (uniqueEvents.has(id)) return;
  const identity=`${t}:${title}`;
  if(!repeatable(title)&&oneTimeAwards.has(identity))return;
  uniqueEvents.add(id);
  if(!repeatable(title))oneTimeAwards.add(identity);
  const e = {id,t,season:s.id,week,title,tier,detail,first:false};
  events.push(e);
  team[t].events.push(e);
 }
 const ordered = [...db.seasons].sort((a,b)=>a.id-b.id);
 const allFinishedParticipation = {};
 const titleHistory = {league:{}, champ:{}};
 const doubleHistory = {};
 const titleRuns={league:{},champ:{},doubles:{},perfect:{}};
 // The exact consecutive length is maintained in O(1); don't rescan a
 // thousands-of-seasons run on every new title.
 const nextRun=(kind,t,id)=>{
  const prev=titleRuns[kind][t];
  return (titleRuns[kind][t]={id,len:prev&&prev.id===id-1?prev.len+1:1}).len;
 };
 for (const s of ordered) {
  const members = teams(s);
  const seasonTally = Object.fromEntries(members.map(t=>[t,{wins:0,losses:0,gf:0,ga:0,clean:0}]));
  for (const t of members) {
   const r = team[t];
   if (!r) continue;
   r.seasons.push(s.id);
   const n = name(t,s);
   if (!r.names.includes(n)) r.names.push(n);
  }
  const finishedRegular = latest(s) === s.weeks;
  if (finishedRegular) {
   const regular = stats(s,s.weeks);
   for (const x of regular.slice(0,s.playoffCount)) {
    team[x.t]?.playoffs.push(s.id);
    if (team[x.t]?.playoffs.length === 1)
     award(x.t,s,s.weeks,'First Playoff Qualification','Standard');
    for (const n of [5,10,20]) if (team[x.t]?.playoffs.length === n)
     award(x.t,s,s.weeks,`${n} Playoff Qualifications`,n>=10?'Legendary':'Major');
   }
  }
  const seasonGames = rlTimelineForSeason(s);
  for (const g of seasonGames) {
   for (const t of [g.a,g.b]) {
    const r = team[t], z = seasonTally[t];
    if (!r || !z) continue;
    const [gf,ga] = rlResultFrom(g,t);
    r.played++;r.gf+=gf;r.ga+=ga;
    z.gf+=gf;z.ga+=ga;
    if (gf>ga) {r.wins++;r.streak++;z.wins++}
    else {r.losses++;r.streak=0;z.losses++}
    r.best = Math.max(r.best,r.streak);
    if (ga === 0) {
     r.clean++;z.clean++;
     for (const n of [10,25,50,100,250]) if (r.clean===n)
      award(t,s,g.w,`${n} Career Clean Sheets`,n>=100?'Legendary':n>=25?'Major':'Standard');
    }
    if (r.wins === 1) award(t,s,g.w,'First Career Win');
    for (const n of [10,25,50,100,250,500,1000]) if (r.wins===n)
     award(t,s,g.w,`${n} Career Wins`,n>=100?'Legendary':n>=50?'Major':'Standard');
    for (const n of [5,10,25,50,100]) if (r.streak===n)
     award(t,s,g.w,n===100?RL_MYTHICS.hundred:`${n}-Match Winning Streak`,
      n===100?'Mythic':n>=25?'Legendary':n>=10?'Major':'Standard');
    for (const n of [100,250,500,1000,2500]) if (r.gf>=n && r.gf-gf<n)
     award(t,s,g.w,`${n} Career Goals`,n>=1000?'Legendary':n>=500?'Major':'Standard');
   }
  }
  for (const t of members) if (team[t]) team[t].seasonStats.push({id:s.id,...seasonTally[t]});
  if (!finishedRegular) continue;
  const league = stats(s,s.weeks)[0]?.t;
  const champ = playoffChampion(s);
  // An absent season breaks a title streak. Consecutive IDs, not just consecutive appearances.
  const consecutive = (years,n) => years.length>=n &&
   Array.from({length:n},(_,i)=>s.id-i).every(id=>years.includes(id));
  if (league) {
   const r=team[league];
   const earlier = r.league.length;
   r.league.push(s.id);
   const leagueRun=nextRun('league',league,s.id);
   award(league,s,s.weeks,'League Title',earlier?'Legendary':'Major');
   if (earlier===0) award(league,s,s.weeks,'First League Title','Major');
   for (const n of [2,3]) if (leagueRun===n)
    award(league,s,s.weeks,n===2?'Back-to-Back League Titles':'Three Consecutive League Titles','Legendary');
   for (const n of [5,10]) if (r.league.length===n)
    award(league,s,s.weeks,`${n} Total League Titles`,'Legendary');
   if (leagueRun>=10&&leagueRun%10===0) award(league,s,s.weeks,RL_MYTHICS.kings,'Mythic');
   const last=titleHistory.league[league];
   if (last!==undefined && allFinishedParticipation[league]?.filter(x=>x>last&&x<s.id).length>=5)
    award(league,s,s.weeks,'League Title Drought Ended','Major');
   titleHistory.league[league]=s.id;
  }
  const rounds=playoffRounds(s),final=rounds.at(-1)?.matches?.[0];
  // Recognition for reaching the final occurs after the semifinals, not only after the final.
  if (final?.a && final?.b) {
   const arrivalWeek = s.weeks + rounds.length-1;
   for (const t of [final.a,final.b]) if (team[t] && !team[t].finals.includes(s.id)) {
    team[t].finals.push(s.id);
    if (team[t].finals.length===1) award(t,s,arrivalWeek,'First Championship Final','Major');
    for (const n of [5,10,20]) if (team[t].finals.length===n)
     award(t,s,arrivalWeek,`${n} Championship Final Appearances`,n>=10?'Legendary':'Major');
   }
  }
  if (champ) {
   const r=team[champ],end=s.weeks+rounds.length;
   const earlier=r.champ.length;
   r.champ.push(s.id);
   const champRun=nextRun('champ',champ,s.id);
   award(champ,s,end,'Championship Title',earlier?'Legendary':'Major');
   if (!earlier) award(champ,s,end,'First Championship Title','Major');
   for (const n of [2,3]) if (champRun===n)
    award(champ,s,end,n===2?'Back-to-Back Championships':'Three Consecutive Championships','Legendary');
   for (const n of [5,10]) if (r.champ.length===n)
    award(champ,s,end,`${n} Total Championships`,'Legendary');
   if (champRun>=10&&champRun%10===0) award(champ,s,end,RL_MYTHICS.eternal,'Mythic');
   const last=titleHistory.champ[champ];
   if (last!==undefined && allFinishedParticipation[champ]?.filter(x=>x>last&&x<s.id).length>=5)
    award(champ,s,end,'Championship Title Drought Ended','Major');
   titleHistory.champ[champ]=s.id;
   if (league===champ) {
    award(champ,s,end,'League and Championship Double','Legendary');
    // Incremental history avoids repeatedly rescanning thousands of past seasons.
    const doubles=(doubleHistory[champ] ||= []);
    doubles.push(s.id);
    const doubleRun=nextRun('doubles',champ,s.id);
    for (const n of [2,3]) if (doubleRun===n)
     award(champ,s,end,n===2?'Back-to-Back Doubles':'Three Consecutive Doubles','Legendary');
    if (doubleRun>=10&&doubleRun%10===0) award(champ,s,end,RL_MYTHICS.dynasty,'Mythic');
    const tally=seasonTally[champ];
    // A league winner in the six-team playoffs receives a semi-final bye:
    // two knockout wins, one game per completed regular-season week.
    const flawless=!!tally && tally.ga===0 && tally.losses===0 &&
     tally.wins===s.weeks+2 && rlTimelineForSeason(s).filter(g=>g.a===champ||g.b===champ).length===s.weeks+2;
    if (flawless){
     award(champ,s,end,RL_MYTHICS.impenetrable,'Mythic');
     const perfectRun=nextRun('perfect',champ,s.id);
     if(perfectRun>=10&&perfectRun%10===0)award(champ,s,end,RL_GODLY,'Godly');
    }
   }
  }
  for (const t of members) (allFinishedParticipation[t] ||= []).push(s.id);
 }
 // Career Firsts are determined by the earliest season+week of each particular achievement.
 // Multiple teams doing it in the same week share the №1 distinction.
 const earliest=new Map();
 for(const e of events) {
  const prior=earliest.get(e.title);
  if (!prior || e.season<prior.season || (e.season===prior.season && e.week<prior.week))
   earliest.set(e.title,{season:e.season,week:e.week});
 }
 for(const e of events) {
  const x=earliest.get(e.title);
  if (x?.season===e.season && x.week===e.week) {e.first=true;team[e.t]?.firsts.push(e)}
 }
 return {team,events};
}
let rl213StreakMemo=null;
function rlStreakBefore(s,w){
 const key=`${s?.id}:${w}`;
 if(rl213StreakMemo?.db===db&&rl213StreakMemo.key===key&&rl213StreakMemo.count===db.seasons.length&&rl213StreakMemo.last===db.seasons.at(-1))
  return rl213StreakMemo.streaks;
 const streaks=Object.fromEntries(RL_TEAM_IDS.map(t=>[t,0]));
 const stopped=new Set();
 // Search backwards for each team's latest loss; this remains fast after
 // 18,000+ seasons and keeps streaks across seasons where a team was absent.
 for(let i=db.seasons.length-1;i>=0&&stopped.size<RL_TEAM_IDS.length;i--){
  const previous=db.seasons[i];if(previous.id>s.id)continue;
  const games=rlTimelineForSeason(previous);
  for(let k=games.length-1;k>=0;k--){
   const g=games[k];if(g.s.id===s.id&&g.w>=w)continue;
   for(const t of [g.a,g.b]){
    if(stopped.has(t))continue;
    const [gf,ga]=rlResultFrom(g,t);
    if(gf>ga)streaks[t]=(streaks[t]||0)+1;else stopped.add(t);
   }
  }
 }
 rl213StreakMemo={db,key,count:db.seasons.length,last:db.seasons.at(-1),streaks};
 return streaks;
}
const RL_STREAK_TIERS=[
 {min:2000,name:'Obsidian Electric White',color:'#F5F7FF',filter:'grayscale(1) brightness(1.75) contrast(3)'},
 {min:1000,name:'Emerald',color:'#19C878',filter:'grayscale(1) sepia(1) saturate(6) hue-rotate(110deg) brightness(1.1)'},
 {min:500,name:'Rose Gold',color:'#E6A0A1',filter:'grayscale(1) sepia(1) saturate(1.5) hue-rotate(310deg) brightness(1.26)'},
 {min:250,name:'Crimson',color:'#E94B82',filter:'grayscale(1) sepia(1) saturate(5) hue-rotate(300deg) brightness(1.18)'},
 {min:100,name:'Mythic',color:'#B875F5',filter:'grayscale(1) sepia(1) saturate(5) hue-rotate(238deg) brightness(1.13)'},
 {min:50,name:'Inferno',color:'#30C8FF',filter:'grayscale(1) sepia(1) saturate(6) hue-rotate(163deg) brightness(1.18)'},
 {min:25,name:'Golden',color:'#F4C34F',filter:'grayscale(1) sepia(1) saturate(5) hue-rotate(10deg) brightness(1.16)'},
 {min:10,name:'Blazing',color:'#FF5733',filter:'grayscale(1) sepia(1) saturate(6) hue-rotate(-25deg) brightness(1.13)'},
 {min:5,name:'Ignited',color:'#FF8A32',filter:'grayscale(1) sepia(1) saturate(6) hue-rotate(-10deg) brightness(1.12)'}
];
function rl213FireMarkup(n){
 const tier=RL_STREAK_TIERS.find(t=>n>=t.min);if(!tier)return '';
 return `<span class="rl-streak-fire rl-fire-${tier.min}" style="--fire:${tier.color};--flame-filter:${tier.filter}" title="${n} consecutive wins · ${tier.name}"><b>${n.toLocaleString()}</b> <span class="rl-fire-symbol" aria-label="${tier.name} flame">🔥</span></span>`;
}
function rlFire(t,s,w){return rl213FireMarkup(rlStreakBefore(s,w)[t]||0)}
function rlStreakShowdown(a,b,s,w){
 const runs=rlStreakBefore(s,w),x=runs[a]||0,y=runs[b]||0;
 return Math.min(x,y)>=5&&Math.max(x,y)>=10?'<span class="rl-showdown" title="Both teams have at least five consecutive wins and one has ten or more">⚔ STREAK SHOWDOWN</span>':'';
}
function rlMilestoneVisible(e) {
 return !['Mythic','Godly'].includes(e.tier) || !!db.mythicRevealed?.[e.season];
}
function rlStreakWatch() {
 const data=rlMilestoneData();
 const leaders=Object.values(data.team).filter(t=>t.streak>=5).sort((a,b)=>b.streak-a.streak||rlLabel(a.id).localeCompare(rlLabel(b.id))).slice(0,4);
 const streaks=leaders.length?leaders.map(t=>`<div class="notice"><strong>${rlTitle(t.id)}</strong> <span class="muted">· current winning streak</span> ${rl213FireMarkup(t.streak)}</div>`).join(''):
  '<p class="muted">No active winning streaks of five or more matches.</p>';
 const upcoming=[];
 for (const t of Object.values(data.team)) {
  if (!t.seasons.length) continue;
  for (const [v,label,steps] of [[t.wins,'career wins',[10,25,50,100,250,500,1000]],
    [t.gf,'career goals',[100,250,500,1000,2500]],
    [t.clean,'career clean sheets',[10,25,50,100,250]]]) {
   const target=steps.find(n=>n>v);
   if (target && target-v<=Math.max(5,Math.ceil(target*.1)))
    upcoming.push({team:t.id,label,target,left:target-v});
  }
  for(const [count,label] of [[t.league.length,'total League titles'],[t.champ.length,'total Championships']]){
   const next=[5,10].find(n=>n>count);
   if(next&&next-count<=2) upcoming.push({team:t.id,label,target:next,left:next-count});
  }
 }
 upcoming.sort((a,b)=>a.left-b.left||a.team.localeCompare(b.team));
 const coming=upcoming.slice(0,4).map(x=>`<div class="notice"><strong>${rlTitle(x.team)}</strong> · ${x.target} ${safe(x.label)} · <b>${x.left} to go</b></div>`).join('') ||
  '<p class="muted">No Standard, Major or Legendary count milestones immediately approaching.</p>';
 return `<h4>Top active winning streaks</h4>${streaks}<h4>Approaching milestones</h4>${coming}`;
}
function rlLegacyNumber(value,label) {
 return `<div class="rl-legacy-number"><strong>${safe(value)}</strong><small>${safe(label)}</small></div>`;
}
function rlFilterMilestones() {
 const tier=document.getElementById('rlMilestoneTier')?.value||'All';
 const team=document.getElementById('rlMilestoneTeam')?.value||'All';
 document.querySelectorAll('#rlMilestoneHall [data-milestone-tier]').forEach(x=>{
  x.hidden = (tier!=='All' && x.dataset.milestoneTier!==tier) ||
   (team!=='All' && x.dataset.milestoneTeam!==team);
 });
}
function rlMilestoneCard(e) {
 return `<div class="rl-milestone-card" data-milestone-tier="${safe(e.tier)}" data-milestone-team="${safe(e.t)}" data-career-first="${e.first?'yes':'no'}"><div class="rl-award-names">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong> ${e.first?'<span class="rl-first">№1 Career First</span>':''}</div><p>${rlTitle(e.t)} · Season ${e.season} · Week ${e.week}</p></div>`;
}
function rlFilterLegacyMilestones(){
 const selection=document.getElementById('rlLegacyMilestoneFilter')?.value||'All';
 document.querySelectorAll('#rlLegacyAchievements .rl-milestone-card').forEach(x=>{
  x.hidden = selection!=='All' && (selection==='Career Firsts'
   ? x.dataset.careerFirst!=='yes' : x.dataset.milestoneTier!==selection);
 });
}
function rlMilestonePage() {
 const data=rlMilestoneData(),profiles=Object.values(data.team);
 const selected=window.rlSelectedLegacy||'Custom',r=data.team[selected]||profiles[0];
 const nameOptions=profiles.map(x=>`<option value="${safe(x.id)}" ${r?.id===x.id?'selected':''}>${rlTitle(x.id)}</option>`).join('');
 const shown=r.events.filter(rlMilestoneVisible).slice().reverse();
 const honours=[...r.league.map(id=>({id,type:'League Title'})),...r.champ.map(id=>({id,type:'Championship'}))].sort((a,b)=>a.id-b.id||a.type.localeCompare(b.type));
 const trophies=honours.map(x=>`<button class="notice" onclick="window.rlArchiveSeason=${x.id};showPage('archive')">${x.type==='League Title'?'🥇':'🏆'} ${safe(x.type)} · Season ${x.id}</button>`).join('')||'<p class="muted">No titles yet.</p>';
 const hall=data.events.filter(rlMilestoneVisible).slice().reverse();
 const firsts=r.firsts.filter(rlMilestoneVisible);
 return `<h2>🏅 Milestone Centre</h2><p class="muted">Five achievement tiers · Progress is reconstructed from recorded results · Mythic and Godly awards stay secret until unveiled at the Season Awards Ceremony.</p>
 <h3>Milestone Watch</h3>${rlStreakWatch()}
 <h3>Team Legacy Profiles</h3><label for="rlLegacySelect">Choose team</label><select id="rlLegacySelect" onchange="window.rlSelectedLegacy=this.value;renderOther()">${nameOptions}</select>
 <div class="rl-legacy-header">${rlLegacyIcon(r.id)}<div><h3>${rlTitle(r.id)}</h3><p>${r.seasons.length?r.seasons.length+' seasons participated':'No seasons participated yet'}</p>${r.names.length>1?`<p>Previous names: ${safe(r.names.filter(x=>x!==rlLabel(r.id)).join(' → '))}</p>`:''}</div></div>
 <div class="rl-legacy-numbers">${[
  [r.wins,'Career wins'],[r.losses,'Career losses'],[r.played?(100*r.wins/r.played).toFixed(1)+'%':'—','Career win rate'],[r.gf,'Goals scored'],[r.ga,'Goals conceded'],[r.clean,'Clean sheets'],[r.league.length,'League titles'],[r.champ.length,'Championships'],[r.playoffs.length,'Playoff appearances'],[r.finals.length,'Championship Finals'],[r.best,'Longest win streak'],[firsts.length,'Career Firsts']
 ].map(x=>rlLegacyNumber(...x)).join('')}</div>
 <h4>Trophy Cabinet</h4><div class="rl-trophy-cabinet">${trophies}</div>
 <h4>Milestones Earned (${shown.length})</h4><label>Show <select id="rlLegacyMilestoneFilter" onchange="rlFilterLegacyMilestones()"><option>All</option>${RL_TIERS.map(t=>`<option>${t}</option>`).join('')}<option>Career Firsts</option></select></label><div id="rlLegacyAchievements">${shown.length?shown.map(rlMilestoneCard).join(''):'<p class="muted">No milestones earned yet.</p>'}</div>
 <h4>Career Firsts</h4>${firsts.length?firsts.map(e=>`<p>${rl210FirstBadge(e.tier)} ${safe(e.title)} · Season ${e.season}, Week ${e.week}</p>`).join(''):'<p class="muted">No Career Firsts earned yet.</p>'}
 <h3>Milestone Hall of Fame</h3>
 <div class="rl-filterline"><label>Tier<select id="rlMilestoneTier" onchange="rlFilterMilestones()"><option>All</option>${RL_TIERS.map(x=>`<option>${x}</option>`).join('')}</select></label><label>Team<select id="rlMilestoneTeam" onchange="rlFilterMilestones()"><option>All</option>${profiles.map(x=>`<option value="${safe(x.id)}">${rlTitle(x.id)}</option>`).join('')}</select></label></div>
 <p class="muted">${hall.length} achievements earned across the career, including repeat accomplishments.</p>
 <div id="rlMilestoneHall">${hall.map(rlMilestoneCard).join('')||'<p class="muted">No milestones earned yet.</p>'}</div>`;
}
function rlSeasonArchivePage() {
 const active=window.rlArchiveSeason||db.seasons.at(-1).id;
 const s=db.seasons.find(x=>x.id===active)||db.seasons.at(-1);
 const table=stats(s,latest(s)),finished=latest(s)===s.weeks,champ=finished?playoffChampion(s):null;
 const league=finished?table[0]?.t:null;
 const rounds=finished?playoffRounds(s):[];
 const archive=Array.isArray(s.ceremonyArchiveV2)&&s.ceremonyArchiveV2.length?ceremonyAwards(s):[];
 const match=archive.find(a=>a.title==='MATCH OF THE SEASON');
 const all=rlTimelineForSeason(s);
 const highest=all.slice().sort((a,b)=>(b.x+b.y)-(a.x+a.y)||a.w-b.w)[0];
 const largest=all.slice().sort((a,b)=>Math.abs(b.x-b.y)-Math.abs(a.x-a.y)||a.w-b.w)[0];
 const close=all.filter(x=>Math.abs(x.x-x.y)===1).length;
 const rec=(label,field,desc=false)=>{
  const n=desc?Math.min(...table.map(r=>r[field])):Math.max(...table.map(r=>r[field]));
  return `<div class="notice"><strong>${safe(label)} · ${n}</strong><p>${table.filter(r=>r[field]===n).map(r=>safe(name(r.t,s))).join(', ')}</p></div>`;
 };
 const summary=(g)=>g?`${safe(name(g.a,s))} ${g.x}–${g.y} ${safe(name(g.b,s))} · Week ${g.w}`:'Not available';
 const views=rounds.map((round,roundNo)=>{
  const upperIsQf0=s.playoffCount===6&&roundNo===0&&round.matches[0]?.winner&&rounds[1]?.matches?.[0]?.b===round.matches[0].winner;
  const order=roundNo===0&&s.playoffCount===6?(upperIsQf0?[0,1]:[1,0]):round.matches.map((_,i)=>i);
  return `<div class="notice"><h4>${safe(round.title)} · Week ${s.weeks+roundNo+1}</h4>${order.map(i=>{
   const m=round.matches[i];return `<p>${m.a?safe(name(m.a,s)):'TBD'} ${m.score?m.score[0]:'–'} – ${m.score?m.score[1]:'–'} ${m.b?safe(name(m.b,s)):'TBD'}</p>`;
  }).join('')}</div>`;
 }).join('');
 const archiveChoices=db.seasons.length>180?
  db.seasons.filter(x=>x.id===s.id||x.id<=5||Math.abs(x.id-s.id)<=24||x.id>db.seasons.at(-1).id-14):db.seasons;
 const selection=archiveChoices.map(x=>`<option value="${x.id}" ${s.id===x.id?'selected':''}>Season ${x.id}</option>`).join('');
 const allWeeks=Array.from({length:s.weeks+playoffWeekCount(s)},(_,i)=>i+1);
 return `<h2>📚 Season Archive</h2><p class="muted">Review a season without rewriting results or awards. All names use their original season identity.</p>
 <label>Season <select onchange="window.rlArchiveSeason=Number(this.value);renderOther()">${selection}</select></label> <label class="rl214-archive-jump">Jump to season <input type="number" min="1" max="${db.seasons.at(-1)?.id||1}" value="${s.id}" onchange="rl214JumpArchive(this.value)" onkeydown="if(event.key==='Enter')rl214JumpArchive(this.value)"></label>
 <div class="rl-archive-hero"><h3>Season ${s.id} · ${s.mode}v${s.mode}</h3><p>${latest(s)} of ${s.weeks} regular weeks completed · Top ${s.playoffCount} playoffs</p><p>🥇 League: <strong>${league?safe(name(league,s)):'Not decided'}</strong></p><p>🏆 Championship: <strong>${champ?safe(name(champ,s)):'Not decided'}</strong></p></div>
 <h3>${finished?'Final':'Current'} Standings</h3>
 <div class="career-table-wrap"><table><tr><th>#</th><th>Team</th><th>W</th><th>L</th><th>GF</th><th>GA</th><th>GD</th></tr>${table.map((x,i)=>`<tr><td>${i+1}</td><td>${safe(name(x.t,s))}</td><td>${x.w}</td><td>${x.l}</td><td>${x.gf}</td><td>${x.ga}</td><td>${x.gf-x.ga}</td></tr>`).join('')}</table></div>
 <h3>Season Records</h3><p class="muted">All tied holders are shown. These values are for this season's regular season only (${s.weeks} weeks).</p>
 <div class="rl-archive-records">${rec('Most wins','w')}${rec('Most goals','gf')}${rec('Fewest goals conceded','ga',true)}
 <div class="notice"><strong>One-goal games · ${close}</strong><p>Across completed regular-season and playoff matches</p></div>
 <div class="notice"><strong>Highest-scoring match</strong><p>${summary(highest)}</p></div>
 <div class="notice"><strong>Largest winning margin</strong><p>${summary(largest)}</p></div></div>
 <h3>Playoff Results</h3>${views||'<p class="muted">Playoff bracket unlocks when the regular season finishes.</p>'}
 <h3>Match of the Season</h3>${match?`<div class="notice"><strong>🏆 ${safe(match.detail)}</strong><p>Four nominees:</p>${(match.nominees||[]).map(n=>`<p>${safe(n.label||'')}</p>`).join('')}</div>`:'<p class="muted">Not awarded yet.</p>'}
 <h3>Season Awards</h3>${archive.length?archive.map(a=>`<div class="notice"><strong>${safe(a.title)}</strong><p>${(a.teams||[]).map(t=>safe(name(t,s))).join(' & ')} · ${safe(a.detail||'')}</p></div>`).join(''):'<p class="muted">Not awarded yet.</p>'}
 <h3>Weekly History</h3><div class="rl-filterline"><label>Go to week <select id="rlArchiveWeek">${allWeeks.map(w=>`<option value="${w}">Week ${w}</option>`).join('')}</select></label><button onclick="rlGoToMoment(${s.id},Number(document.getElementById('rlArchiveWeek').value))">View this week</button></div>`;
}
function rlWeeklyMilestonePopups(s,w) {
 const key=`${s.id}:${w}`,all=rlMilestoneData().events.filter(e=>e.season===s.id&&e.week===w&&!['Mythic','Godly'].includes(e.tier));
 db.milestoneNotified ||= {};
 if (db.milestoneNotified[key]||!all.length) return;
 db.milestoneNotified[key]=true;
 persist();
 document.querySelector('.rl-milestone-overlay')?.remove();
 const el=document.createElement('div');
 el.className='rl-milestone-overlay';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label','Milestone celebration');
 el.innerHTML=`<div class="rl-milestone-pop"><div class="rl-milestone-spark">✦ 🏆 ✦</div><div class="ceremony-kicker">CAREER MILESTONES UNLOCKED</div><h2>${all.length===1?'A NEW MILESTONE!':all.length+' NEW MILESTONES!'}</h2><div class="rl-pop-milestones">${all.map(e=>`<div class="rl-milestone-card"><div class="rl-award-names">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong> ${e.first?rl210FirstBadge(e.tier):''}</div><p>${rlTitle(e.t)} · Season ${e.season} · Week ${e.week}</p></div>`).join('')}</div><button class="ceremony-primary" onclick="this.closest('.rl-milestone-overlay').remove()">Okay</button></div>`;
 document.body.appendChild(el);
 el.querySelector('button')?.focus();
}
function rlMythicReveal(s) {
 if (db.mythicRevealed?.[s.id]) return false;
 const all=rlMilestoneData().events.filter(e=>e.season===s.id&&['Mythic','Godly'].includes(e.tier));
 if (!all.length) return false;
 const combined=all.filter(e=>e.title===RL_MYTHICS.dynasty).map(e=>e.t);
 const godly=all.some(e=>e.tier==='Godly');
 const show=all.filter(e=>!combined.includes(e.t)||![RL_MYTHICS.eternal,RL_MYTHICS.kings].includes(e.title));
 $('other').innerHTML=`<div class="ceremony-stage ceremony-final ${godly?'rl212-reveal-godly':''}" role="dialog" aria-modal="true" aria-label="Secret milestone reveal"><div class="ceremony-spotlight one"></div><div class="ceremony-spotlight two"></div><div class="ceremony-top"><span>ROCKET LEAGUE · SEASON ${s.id}</span><span>${godly?'GODLY REVEAL':'MYTHIC REVEAL'}</span></div><div class="ceremony-center"><div class="ceremony-spark">${godly?'☀️ ✦ 👑 ✦ ☀️':'💜 ✦ 💜'}</div><div class="ceremony-kicker">${godly?'THE IMPOSSIBLE HAS BEEN ACHIEVED':'AN EXTRAORDINARY ACHIEVEMENT'}</div>${show.map(e=>`<div class="ceremony-big">${e.tier==='Godly'?'☀️ ':''}${safe(e.title)}</div><p>${rlTitle(e.t)} · Season ${e.season}</p>`).join('')}<p class="muted">A permanent place in career history.</p></div><div class="ceremony-actions"><button class="ceremony-primary" onclick="rlFinishMythicReveal()">Continue ▶</button></div></div>`;
 return true;
}
function rlFinishMythicReveal() {
 db.mythicRevealed ||= {};
 db.mythicRevealed[season().id]=true;
 persist();
 ceremonyState.phase=7;
 renderAwards(season());
}

// Additional career records. This is intentionally separate from the old career
// statistics tables, which still display their original detailed match counts.
function rlCareerRecordExtras() {
 const data=rlMilestoneData(),active=Object.values(data.team).filter(x=>x.played>0);
 const fmtNames=ids=>ids.map(rlTitle).join(' · ')||'—';
 const row=(label,metric)=>{
  const max=Math.max(0,...active.map(x=>metric(x)));
  const held=max>0?active.filter(x=>metric(x)===max).map(x=>x.id):[];
  return `<tr><td>${safe(label)}</td><td>${max}</td><td>${fmtNames(held)}</td></tr>`;
 };
 const matches=rlTimeline();
 let maxTotal=0,maxMargin=0;for(const g of matches){maxTotal=Math.max(maxTotal,g.x+g.y);maxMargin=Math.max(maxMargin,Math.abs(g.x-g.y))}
 const matchFormat=g=>`Season ${g.s.id} · Week ${g.w}: ${safe(name(g.a,g.s))} ${g.x}–${g.y} ${safe(name(g.b,g.s))}`;
 const matchRow=(label,value,items)=>`<tr><td>${safe(label)}</td><td>${value}</td><td>${items.map(matchFormat).join('<br>')||'—'}</td></tr>`;
 let perLength='';
 for(const weeks of [9,18,27,36]) {
  const matching=db.seasons.filter(s=>s.weeks===weeks&&latest(s)===weeks);
  if(!matching.length)continue;
  const r=matching.flatMap(s=>stats(s,weeks).map(x=>({s,...x})));
  const values=[['Most league wins','w'],['Most league goals','gf'],['Fewest league goals conceded','ga']];
  const parts=values.map(([label,key])=>{
   const best=key==='ga'?Math.min(...r.map(x=>x[key])):Math.max(...r.map(x=>x[key]));
   const holders=r.filter(x=>x[key]===best);
   return `<tr><td>${safe(label)}</td><td>${best}</td><td>${holders.map(x=>safe(name(x.t,x.s))+` (Season ${x.s.id})`).join('<br>')}</td></tr>`;
  });
  perLength+=`<h4>${weeks}-week seasons</h4><div class="career-table-wrap"><table><tr><th>Record</th><th>Value</th><th>All holders</th></tr>${parts.join('')}</table></div>`;
 }
 return `<h3>Career Milestone Records</h3><p class="muted">All tied holders are displayed. These are cumulative across regular seasons and playoffs, regardless of team name changes or seasons missed.</p>
 <div class="career-table-wrap"><table><tr><th>Record</th><th>Value</th><th>Holders</th></tr>
 ${row('Most match wins',x=>x.wins)}
 ${row('Most career goals scored',x=>x.gf)}
 ${row('Most career clean sheets',x=>x.clean)}
 ${row('Longest match-winning streak',x=>x.best)}
 ${row('Most playoff appearances',x=>x.playoffs.length)}
 ${row('Most Championship Final appearances',x=>x.finals.length)}
 ${row('Most League titles',x=>x.league.length)}
 ${row('Most Championships',x=>x.champ.length)}
 ${matchRow('Highest combined-score match',maxTotal,matches.filter(g=>g.x+g.y===maxTotal))}
 ${matchRow('Biggest winning margin',maxMargin,matches.filter(g=>Math.abs(g.x-g.y)===maxMargin))}
 </table></div><h3>Season-Length-Specific Records</h3>
 <p class="muted">Season totals are separated by 9, 18, 27 and 36-week formats, so shorter seasons are not unfairly compared with longer ones.</p>${perLength||'<p class="muted">No completed seasons yet.</p>'}`;
}
