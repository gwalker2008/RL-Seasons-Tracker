'use strict';
/* Rocket League Season Tracker v2.1.5 — additive milestone/ceremony reliability.
   No custom artwork, copied saves, scores or prestige assets are replaced. */

// An achievement is earned by verified results, not by the player's decision
// to attend Awards Night. Keep current-season secrets hidden until their reveal;
// a completed older season cannot remain permanently sealed after advancing.
function rl216SeasonUnlocked(id){
 return !!db.mythicRevealed?.[id] || Number(id) < (db.seasons.at(-1)?.id||0);
}
rlMilestoneVisible=function(e){
 return !['Mythic','Godly'].includes(e.tier) || rl216SeasonUnlocked(e.season);
};
// Prestige was previously gated on the ceremonial reveal flag, even when the
// player skipped Awards Night. Compute the exact same prestige from earned,
// legitimately unsealed events instead of mutating thousands of old saves.
rl210Prestige=function(t,seasonId=Infinity,week=Infinity){
 const entries=rl210Data().team[t]?.events||[];let level=null;
 for(const e of entries){
  if(!['Mythic','Godly'].includes(e.tier)||!rl216SeasonUnlocked(e.season))continue;
  if(e.season>seasonId||e.season===seasonId&&e.week>week)continue;
  if(e.tier==='Godly')return 'godly';
  level='mythic';
 }
 return level;
};

// `e.first` means first in league history, not first for *this team*.
// First-time full Mythic cinematics are determined by team + achievement.
let rl216FirstCache=null;
function rl216FirstSecrets(){
 const data=rl210Data();
 if(rl216FirstCache?.data===data)return rl216FirstCache.ids;
 const ids=new Set(),seen=new Set();
 for(const e of data.events){
  if(!['Mythic','Godly'].includes(e.tier))continue;
  const key=e.t+'\u001f'+e.title;
  if(!seen.has(key)){ids.add(e.id);seen.add(key)}
 }
 rl216FirstCache={data,ids};return ids;
}
function rl216ReplayAllowed(e){
 return rl216SeasonUnlocked(e.season) &&
  (e.tier==='Godly'||e.tier==='Mythic'&&rl216FirstSecrets().has(e.id));
}
function rl216RevealSequence(s,isReplay=false){
 const first=rl216FirstSecrets(),ranks=stats(s,s.weeks).map(x=>x.t);
 const all=rl210Data().events.filter(e=>e.season===s.id&&['Mythic','Godly'].includes(e.tier) &&
  (!isReplay || rl216ReplayAllowed(e)));
 const group=tier=>{
  const found=new Map();
  for(const e of all.filter(e=>e.tier===tier)){
   if(!found.has(e.t))found.set(e.t,[]);found.get(e.t).push(e);
  }
  return [...found].map(([t,events])=>({tier,t,events,firstEvents:events.filter(e=>first.has(e.id)),repeatEvents:events.filter(e=>!first.has(e.id))})).sort((a,b)=>
   (tier==='Mythic'?a.events.length-b.events.length:0)||
   ranks.indexOf(b.t)-ranks.indexOf(a.t)||a.t.localeCompare(b.t));
 };
 // Preserve the user's chosen order: Mythic first, Godly as the finale.
 return [...group('Mythic'),...group('Godly')];
}
// The historical replay wrapper is retained but unseals skipped, completed
// seasons and excludes repeat Mythics from full-cinematic replays.
rlMythicReveal=function(s){
 const replay=!!rl214Replay;
 if(replay){if(!rl216SeasonUnlocked(s.id))return false}
 else if(db.mythicRevealed?.[s.id])return false;
 if(!rl210SecretState||rl210SecretState.season!==s.id){
  const groups=rl216RevealSequence(s,replay);
  if(!groups.length)return false;
  rl210SecretState={season:s.id,index:0,groups};
 }
 return rl210RenderSecret();
};

// No secret count, position, or preview of the next rarity. Existing detailed
// prestige and Godly rainbow artwork continue to come from v2.1.0.
rl210RenderSecret=function(){
 const st=rl210SecretState,s=season(),step=st?.groups[st.index];
 if(!step)return false;
 const godly=step.tier==='Godly';
 const repeatOnly=!godly&&!step.firstEvents.length;
 const team=safe(name(step.t,s));
 if(repeatOnly){
  $('other').innerHTML=`<section class="rl216-repeat-screen" role="dialog" aria-modal="true" aria-label="Repeated Mythic achievement notification"><div class="rl216-repeat-panel"><div class="rl216-repeat-heading">◆ MYTHIC ACHIEVEMENT REPEATED</div><div class="rl216-repeat-team">${rl210HistoricalLogo(step.t,s.id,Infinity)}<strong>${team}</strong></div>${step.events.map(e=>`<div class="rl216-repeat-entry"><strong>${safe(e.title)}</strong><small>Earned again in Season ${s.id} · Week ${e.week}</small></div>`).join('')}<p class="muted">Previously earned Mythic achievements remain in the milestone history.</p><button class="ceremony-primary" onclick="rlFinishMythicReveal()">Okay</button><button onclick="ceremonyClose()">Exit Ceremony</button></div></section>`;
  return true;
 }
 const displayLogo=rl210LogoWrap(rl210PlainIcon(step.t),godly?'godly':'mythic');
 const head=godly?step.events:step.firstEvents;
 const extras=!godly&&step.repeatEvents.length?`<div class="rl216-repeat-with-first"><strong>Also repeated this season</strong>${step.repeatEvents.map(e=>`<span>${safe(e.title)}</span>`).join('')}</div>`:'';
 $('other').innerHTML=`<div class="ceremony-stage ceremony-final rl210-secret ${godly?'rl210-secret-godly':'rl210-secret-mythic'}" role="dialog" aria-modal="true" aria-label="Secret ${step.tier} milestone reveal"><div class="ceremony-spotlight one"></div><div class="ceremony-spotlight two"></div><div class="ceremony-top"><span>SEASON ${s.id} · SECRET HONOURS</span></div><div class="ceremony-center"><div class="rl210-reveal-label">${godly?rl210Sun():'◆'} ${step.tier.toUpperCase()} REVEAL</div><div class="rl210-reveal-logo">${displayLogo}</div><div class="ceremony-big">${team}</div><div class="rl210-reveal-achievements">${head.map(e=>`<div class="rl210-reveal-award">${rlTierBadge(e.tier)}<strong>${safe(e.title)}</strong>${e.first?rl210FirstBadge(e.tier):''}</div>`).join('')}</div>${extras}<p class="muted">Permanent achievements are recorded in career history.</p></div><div class="ceremony-actions"><button class="ceremony-primary" onclick="rlFinishMythicReveal()">${godly?'Complete Reveal':'Continue'} ▶</button><button onclick="ceremonyClose()">Exit Ceremony</button></div></div>`;
 return true;
};

// A skipped historical season can now show its already-earned secret honours;
// no award record is created or silently granted merely by reading an archive.
const rl216BaseArchivePage=rlSeasonArchivePage;
rlSeasonArchivePage=function(){
 let html=rl216BaseArchivePage();
 const s=db.seasons.find(x=>x.id===Number(window.rlArchiveSeason))||season();
 if(!rl216SeasonUnlocked(s.id)||db.mythicRevealed?.[s.id])return html;
 const entries=rl210Data().events.filter(e=>e.season===s.id&&['Mythic','Godly'].includes(e.tier));
 if(!entries.length)return html;
 const rendered=entries.map(e=>`<div class="notice">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong><p>${safe(name(e.t,s))} · ${safe(seasonLabel(s.id))} · Week ${e.week}</p></div>`).join('');
 return html.replace('Secret honours from this season remain sealed until their original Awards Night reveal.',`${rendered}`);
};
