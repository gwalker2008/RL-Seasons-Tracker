'use strict';
/* Rocket League Season Tracker v2.1.6 — layout + cinematic replay hotfix.
   No save-schema migration, season edits, award grants, or artwork replacements. */

// The v2.1.5 wrapper accidentally swapped out the original 4-stage cinematic.
// Keep its first-time/repeat-Mythic decision, but restore the timed reveal for
// first-time Mythics and EVERY Godly occurrence (including archived replays).
const rl217PriorSecretRenderer=rl210RenderSecret;
const rl217OriginalRevealPhase=rl213RevealPhase;
rl213RevealPhase=function(phase){
 rl217OriginalRevealPhase(phase);
 if(phase!==4)return;
 const stage=document.querySelector('.rl213-cinema');
 const step=rl210SecretState?.groups?.[rl210SecretState.index];
 if(!stage||!step||step.tier!=='Mythic')return;
 // When a team earns first-time AND repeated Mythics in the same season,
 // celebrate the first-time awards only and acknowledge repeats separately.
 const first=step.firstEvents||step.events;
 const repeats=step.repeatEvents||[];
 const awards=stage.querySelector('.rl213-awards');
 if(!awards)return;
 awards.innerHTML=first.map(e=>`<div class="rl210-reveal-award">${rlTierBadge(e.tier)} <strong>${safe(e.title)}</strong>${e.first?rl210FirstBadge(e.tier):''}</div>`).join('')+
  (repeats.length?`<div class="rl216-repeat-with-first"><strong>Also earned again this season</strong>${repeats.map(e=>`<span>${safe(e.title)}</span>`).join('')}</div>`:'');
};
rl210RenderSecret=function(){
 const st=rl210SecretState,step=st?.groups?.[st.index];
 if(!step)return false;
 if(step.tier==='Mythic'&&!step.firstEvents?.length){
  rl213ClearRevealTimers();
  return rl217PriorSecretRenderer(); // Small repeat notice (never replayable).
 }
 rl213ClearRevealTimers();
 const godly=step.tier==='Godly',s=season();
 const reduced=!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 const particles=Array.from({length:16},(_,i)=>`<i style="--particle:${i};--delay:${(i%7)*.31}s"></i>`).join('');
 $('other').innerHTML=`<div class="ceremony-stage rl213-cinema ${godly?'rl213-godly':'rl213-mythic'}" role="dialog" aria-modal="true" aria-label="Secret milestone reveal" data-phase="0"><div class="rl213-particles">${particles}</div><div class="rl213-beam"></div><div class="ceremony-top"><span>SEASON ${s.id} · SECRET HONOURS</span></div><div class="ceremony-center rl213-cinema-center"><div class="rl213-announcement"></div><div class="rl213-glyph"></div><div class="rl213-team"></div><div class="rl213-awards"></div></div><div class="ceremony-actions rl213-actions"><span>${rl214Replay?'Historical cinematic replay · No awards or progression are changed':'Achievement earned and recorded in career history'}</span><button class="rl213-skip" onclick="rl213SkipSecret()">Skip animation</button><button class="ceremony-primary rl213-next" onclick="rlFinishMythicReveal()" disabled hidden>${rl214Replay?'Finish replay':godly?'Complete reveal':'Continue'} ▶</button></div></div>`;
 const stages=reduced?[0,40,80,120]:godly?[1700,5700,10900,15000]:[900,2900,6100,8700];
 for(const [i,delay] of stages.entries())rl213RevealTimers.push(setTimeout(()=>rl213RevealPhase(i+1),delay));
 return true;
};

// Clear animated phase callbacks when navigating away from Awards Night.
const rl217PriorShowPage=showPage;
showPage=function(page){
 if(page!=='awards')rl213ClearRevealTimers();
 return rl217PriorShowPage(page);
};

// Condense the expansion link in narrow 3-across season cards, while keeping
// the full number of qualifying seasons available on click.
const rl217PriorAllGroups=rl215AllGroups;
rl215AllGroups=function(holderMap){
 return rl217PriorAllGroups(holderMap).replace(/<summary>View all ([\d,]+) occurrences?<\/summary>/g,
  '<summary aria-label="View all $1 occurrences">View all $1</summary>');
};


// v2.1.6: ONE Replay Ceremony action replays the complete regular awards,
// then automatically plays eligible Mythic and Godly cinematics. No separate
// secret replay picker or per-achievement button exists in the interface.
let rl216ReplayFromCurrent=null;
function rl216ReplayWholeCeremony(){
 const current=season();
 if(rl214Replay){
  rl210SecretState=null;
  ceremonyCancel();
  ceremonyState={season:current.id,index:0,phase:0};
  renderAwards(current);
  return;
 }
 rl216ReplayFromCurrent=current.id;
 rl214ReplayCeremony(current.id); // The existing historical engine is read-only.
 if(!rl214Replay)rl216ReplayFromCurrent=null;
}
function rl216ReturnToCurrentAwards(){
 if(!rl214Replay||!rl216ReplayFromCurrent){return rl214ReturnToArchive()}
 const prior=rl214Replay;
 rl214Replay=null;
 db.active=prior.previousActive;
 selectedWeek=prior.previousWeek;
 rl216ReplayFromCurrent=null;
 rl210SecretState=null;
 ceremonyCancel();
 ceremonyState={season:season().id,index:0,phase:7};
 showPage('awards');
}
// When the full replay was initiated from the current season's completion
// screen, offer a way back to that same screen (including Start New Season).
const rl216IntegratedRenderAwards=renderAwards;
renderAwards=function(s){
 const result=rl216IntegratedRenderAwards(s);
 if(rl216ReplayFromCurrent&&rl214Replay&&ceremonyState.phase>=7&&!rl210SecretState){
  const button=$('other')?.querySelector('button[onclick="rl214ReturnToArchive()"]');
  if(button){button.textContent='Back to Season Complete';button.setAttribute('onclick','rl216ReturnToCurrentAwards()')}
 }
 return result;
};
const rl216IntegratedShowPage=showPage;
showPage=function(page){
 if(rl216ReplayFromCurrent&&rl214Replay&&page!=='awards')rl216ReplayFromCurrent=null;
 return rl216IntegratedShowPage(page);
};
