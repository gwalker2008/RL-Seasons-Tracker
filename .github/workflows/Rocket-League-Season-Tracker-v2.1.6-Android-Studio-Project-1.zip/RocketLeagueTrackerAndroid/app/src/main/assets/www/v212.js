'use strict';
// Rocket League Season Tracker v2.0.12. Uses v2.0.11's save and match model.
// New fields are additive; old backups remain readable.
const RL212_CAPS=[100,500,1000,5000,'unlimited'];
let rl212StatsScope='season';
const rl212Num=n=>Number(n||0).toLocaleString();
const rl212Rarity=e=>['Godly','Mythic'].includes(e.tier);
const rl212Logo=t=>rlLegacyIcon(t);
const rl212SeasonText=ids=>!ids?.length?'—':ids.map(seasonLabel).join(', ');
const rl212RecordCard=(heading,value,unit,holders,featured=false)=>`<article class="rl212-record ${featured?'featured':''}"><div class="record-title">${heading}</div><div class="record-number">${rl212Num(value)}</div><div class="record-sub">${safe(unit)}</div>${holders.length?holders.map(h=>`<div class="rl212-holder">${rl212Logo(h.id)}<div class="rl212-holder-info"><strong>${rlTitle(h.id)} ${rl210PrestigeMark(h.id)}</strong><div class="rl211-record-hist">${rl211CompactRecordHistory(h.seasons||'')}</div></div></div>`).join(''):'<p class="muted">No qualifying record yet.</p>'}</article>`;
function rl212Streak(ids){
 let best=0,start=0,end=0,run=0;
 [...ids].sort((a,b)=>a-b).forEach((n,i,arr)=>{run=i>0&&n===arr[i-1]+1?run+1:1;if(run>best){best=run;start=n-run+1;end=n}});
 return {best,start,end};
}
function rl212CareerExtraCards(){
 const data=rl210Data(),active=Object.values(data.team).filter(t=>t.played>0);
 const cumulative=[['Most Match Wins','wins','Wins'],['Most Career Goals','gf','Goals'],['Most Career Clean Sheets','clean','Clean sheets'],['Longest Match-Winning Streak','best','Consecutive wins'],['Most Championship Final Appearances',null,'Finals']];
 const cards=cumulative.map(([label,key,unit])=>{
  const val=t=>key===null?t.finals.length:t[key];const max=Math.max(0,...active.map(val));
  return rl212RecordCard(label,max,unit,max?active.filter(t=>val(t)===max).map(t=>({id:t.id,seasons: key===null?rl212SeasonText(t.finals):key==='best'?'Career best':'Across all recorded matches'})):[]);
 });
 const games=rlTimeline();
 for(const [label,metric,unit] of [['Highest-Scoring Match',g=>g.x+g.y,'Combined goals'],['Biggest Winning Margin',g=>Math.abs(g.x-g.y),'Goal margin']]){
  let max=0;for(const g of games)max=Math.max(max,metric(g));
  const ties=games.filter(g=>metric(g)===max&&max>0);
  const tile=`<article class="rl212-record"><div class="record-title">${label}</div><div class="record-number">${max}</div><div class="record-sub">${unit}</div>${ties.slice(0,8).map(g=>`<div class="rl212-holder"><div class="rl212-holder-info"><strong>${safe(name(g.a,g.s))} ${g.x}–${g.y} ${safe(name(g.b,g.s))}</strong><small>Season ${g.s.id}, Week ${g.w}</small></div></div>`).join('')||'<p class="muted">No matches yet.</p>'}${ties.length>8?`<small>${ties.length-8} additional ties in the Season Archive</small>`:''}</article>`;
  cards.push(tile);
 }
 const formats=[9,18,27,36].map(weeks=>{
  const seasons=db.seasons.filter(s=>s.weeks===weeks&&latest(s)===s.weeks);
  if(!seasons.length)return '';
  const rows=seasons.flatMap(s=>stats(s,s.weeks).map(x=>({s,...x})));
  const rec=(label,key,lowest=false)=>{
   const best=lowest?Math.min(...rows.map(x=>x[key])):Math.max(...rows.map(x=>x[key]));
   return rl212RecordCard(label,best,'In one '+weeks+'-week season',rows.filter(x=>x[key]===best).map(x=>({id:x.t,seasons:seasonLabel(x.s.id)})));
  };
  return `<details class="rl212-panel"><summary>${weeks}-Week Season Records (${seasons.length} seasons)</summary><div class="rl212-record-grid">${rec('Most League Wins','w')}${rec('Most League Goals','gf')}${rec('Fewest Goals Conceded','ga',true)}</div></details>`;
 }).filter(Boolean).join('');
 return `<div class="rl212-record-grid">${cards.join('')}</div>${formats}`;
}
function rl212CareerPage(){
 const data=rl210Data(),completed=rlFinishedSeasons();
 const team=Object.fromEntries(Object.values(data.team).map(x=>[x.id,{id:x.id,league:x.league,champ:x.champ,playoffs:x.playoffs,runner:[],records:x}]));
 for(const s of completed){const final=playoffRounds(s).at(-1)?.matches?.[0];if(final?.winner&&final?.a&&final?.b){const loser=final.winner===final.a?final.b:final.a;if(team[loser])team[loser].runner.push(s.id)}}
 const active=Object.values(team).filter(x=>x.records.seasons.length);
 const maxH=(project,withYears=true)=>{
  const peak=Math.max(0,...active.map(x=>project(x).n));
  return {peak,holders:peak?active.filter(x=>project(x).n===peak).map(x=>({id:x.id,seasons:project(x).label})):[]};
 };
 const count=(key)=>maxH(x=>({n:x[key].length,label:rl212SeasonText(x[key])}));
 const streak=(key)=>maxH(x=>{const z=rl212Streak(x[key]);return {n:z.best,label:z.best?z.start===z.end?seasonLabel(z.start):seasonLabel(z.start)+' – '+seasonLabel(z.end):'—'}});
 const champ=count('champ'),league=count('league'),runner=count('runner'),chS=streak('champ'),leS=streak('league'),plS=streak('playoffs');
 const records=[rl212RecordCard('Most Championships 🏆',champ.peak,'Championship titles',champ.holders,true),rl212RecordCard('Most League Titles',league.peak,'League titles',league.holders),rl212RecordCard('Most Championship Runner-Ups 🥈',runner.peak,'Runner-up finishes',runner.holders),rl212RecordCard('Longest Championship Streak',chS.peak,'Consecutive Championships',chS.holders),rl212RecordCard('Longest League Title Streak',leS.peak,'Consecutive League titles',leS.holders),rl212RecordCard('Longest Playoff Qualification Streak',plS.peak,'Consecutive playoff seasons',plS.holders)];
 const ordered=active.sort((a,b)=>(b.champ.length+b.league.length)-(a.champ.length+a.league.length));
 const hall=ordered.map(x=>`<div class="rl212-holder">${rl212Logo(x.id)}<div class="rl212-holder-info"><strong>${rlTitle(x.id)} ${rl210PrestigeMark(x.id)}</strong><small>${x.league.length} League · ${x.champ.length} Championships · ${x.league.filter(n=>x.champ.includes(n)).length} Doubles</small></div></div>`).join('');
 const past=completed.slice(-12).reverse().map(s=>`<div class="rl212-holder"><div class="rl212-holder-info"><strong>Season ${s.id}</strong><small>League: ${safe(name(stats(s,s.weeks)[0]?.t,s))} · Championship: ${safe(name(playoffChampion(s),s))}</small></div><button onclick="window.rlArchiveSeason=${s.id};showPage('archive')">Open</button></div>`).join('');
 const selectSeasons=completed.length>180?[...completed.slice(0,5),...completed.slice(-85)]:completed;
 const choices=selectSeasons.map(x=>`<option value="${x.id}">Season ${x.id}</option>`).join('');
 const comparisonJump=completed.length>180?`<small class="muted">Showing first five and latest 85 seasons. Type any earlier season number to compare it.</small> <label>Season A # <input type="number" min="1" onchange="rl214CompareJump('rlCompareA',this.value)"></label><label>Season B # <input type="number" min="1" onchange="rl214CompareJump('rlCompareB',this.value)"></label>`:'';
 return `<h2>🏆 Career Records</h2><p class="muted">${completed.length} completed seasons · All tied holders shown · Renamed teams keep one identity.</p><div class="rl212-record-grid">${records.join('')}</div>
 <details class="rl212-panel"><summary>League Hall of Fame (${active.length} teams)</summary>${hall||'<p>No teams recorded yet.</p>'}</details>
 <details class="rl212-panel"><summary>Season Comparison</summary>${completed.length>=2?`<div class="row"><label>Season A<select id="rlCompareA" onchange="rlCompareRender()">${choices}</select></label><label>Season B<select id="rlCompareB" onchange="rlCompareRender()">${selectSeasons.map(x=>`<option value="${x.id}" ${x.id===completed.at(-1).id?'selected':''}>Season ${x.id}</option>`).join('')}</select></label></div>${comparisonJump}<div id="rlCompareResult"></div>`:'<p>Complete two seasons to compare them.</p>'}</details>
 <details class="rl212-panel"><summary>Recent Career Timeline</summary>${past||'<p>No completed seasons yet.</p>'}<button onclick="showPage('archive')">Explore full Season Archive</button></details>
 <details class="rl212-panel" ontoggle="rl211LoadCareerExtras(this)"><summary>Additional Historical Records</summary><div class="rl211-lazy-content"><p class="muted">Expand to calculate additional historical records.</p></div></details>`;
}
// Return the same counts whether the underlying data is manual or simulated.
function rl212AllPlayerStats(scope='season'){
 const seasons=scope==='career'?db.seasons:[season()];const players=new Map();const matches=[];
 const empty=()=>({goals:0,assists:0,saves:0,shots:0,matches:0,best:{goals:0,assists:0,saves:0,shots:0},history:[],sim:0,manual:0});
 for(const s of seasons){
  const persons=roster(s);
  for(let w=1;w<=Math.min(latest(s),s.weeks);w++){
   const p=s.playerStats?.[w];if(!p)continue;
   const source=p.__source==='simulated'?'simulated':'manual';
   const match=fixtures(s,w).findIndex(z=>z.includes('Custom'));const score=s.results[w]?.[match];
   if(!score)continue;
   for(let i=0;i<persons.length;i++){
    const obj=p[i];if(!obj)continue;
    const id=scope==='career'?(i===0?'human':`mate:${persons[i]}`):String(i);
    if(!players.has(id))players.set(id,{...empty(),id,name:i===0?(scope==='career'?roster(season())[0]:persons[i]):persons[i],i});
    const z=players.get(id);z.matches++;z[source==='simulated'?'sim':'manual']++;
    const v={season:s.id,week:w,kind:'Regular',source};
    for(const k of ['goals','assists','saves','shots']){v[k]=Number(obj[k]||0);z[k]+=v[k];z.best[k]=Math.max(z.best[k],v[k])}
    z.history.push(v);
   }
  }
  for(const [week,block] of Object.entries(s.playoffPlayerStats||{})){
   if(!Array.isArray(block)||!block.length)continue;
   for(let i=0;i<persons.length;i++){
    const obj=block[i];if(!obj)continue;
    const id=scope==='career'?(i===0?'human':`mate:${persons[i]}`):String(i);
    if(!players.has(id))players.set(id,{...empty(),id,name:i===0?(scope==='career'?roster(season())[0]:persons[i]):persons[i],i});
    const z=players.get(id);z.matches++;z.sim++;
    const v={season:s.id,week:Number(week),kind:'Playoff',source:'simulated'};
    for(const k of ['goals','assists','saves','shots']){v[k]=Number(obj[k]||0);z[k]+=v[k];z.best[k]=Math.max(z.best[k],v[k])}z.history.push(v);
   }
  }
 }
 return Array.from(players.values());
}
function rl212StatsPage(s){
 const rows=rl212AllPlayerStats(rl212StatsScope);
 const totals=Object.fromEntries(['goals','assists','saves','shots'].map(k=>[k,rows.reduce((n,x)=>n+x[k],0)]));
 const ordered=rows.slice().sort((a,b)=>b[sortStat]-a[sortStat]||a.name.localeCompare(b.name));
 const key=sortStat;
 const players=ordered.map(p=>{
  const rate=p.shots?p.goals/p.shots*100:0;
  const contributions=['goals','assists','saves'].map(k=>`<div class="rl212-watch-item"><p>${k[0].toUpperCase()+k.slice(1)} · ${p[k]} of ${totals[k]} (${totals[k]?(p[k]/totals[k]*100).toFixed(1):'0'}%)</p><div class="rl212-bar"><span style="width:${totals[k]?Math.min(100,100*p[k]/totals[k]):0}%"></span></div></div>`).join('');
  const seq=p.history,first=seq.slice(-10,-5),recent=seq.slice(-5);const avg=a=>a.length?a.reduce((sum,v)=>sum+v[key],0)/a.length:0;const diff=first.length===5?avg(recent)-avg(first):null;
  const development='<div class="rl211-development-content"></div>';
  return `<details class="rl212-panel"><summary>${safe(p.name)} · ${p[key]} ${safe(key)} · ${p.matches} matches</summary>
   <div class="rl212-stat-grid">${[['Goals',p.goals],['Assists',p.assists],['Saves',p.saves],['Shots',p.shots],['Shooting accuracy',rate.toFixed(1)+'%'],['Average goals/game',p.matches?(p.goals/p.matches).toFixed(2):'—']].map(([label,v])=>`<div class="rl212-stat"><b>${v}</b><small>${label}</small></div>`).join('')}</div>
   <h4>Contribution to your team's recorded player stats</h4>${contributions}
   <p><strong>Recent ${safe(key)} trend:</strong> ${diff===null?'Needs 10 recorded matches':`${diff>=0?'+':''}${diff.toFixed(2)} per match, last 5 vs previous 5`}</p>
   <p><strong>Personal bests:</strong> ${p.best.goals} goals · ${p.best.assists} assists · ${p.best.saves} saves · ${p.best.shots} shots</p>
   <p class="muted">${p.manual} manually entered · ${p.sim} simulated performances${p.unrecorded?` · ${p.unrecorded} games with no archived individual stats (appearance counted, performance not invented)`:``}</p>
   <details data-player-id="${safe(p.id)}" ontoggle="rl211LoadDevelopment(this)"><summary>Season-by-season development</summary>${development}</details>
  </details>`;
 }).join('');
 const leader=key=>rows.length?[...rows].sort((a,b)=>b[key]-a[key])[0]:null;
 const top=`<div class="rl212-stat-grid">${[['⚽ Top scorer','goals'],['🎯 Top playmaker','assists'],['🛡️ Most saves','saves']].map(([title,key])=>{const p=leader(key);return `<div class="rl212-stat"><small>${title}</small><b style="font-size:19px">${p?safe(p.name):'—'}</b><small>${p?p[key]+' '+key:'No data'}</small></div>`}).join('')}</div>`;
 return `<h2>📊 Player & Teammate Performance</h2><p class="muted">Games count actual completed Custom-team matches for the recorded lineup. Goals, assists, saves and shots use available individual stat records only; missing performances are never invented.</p>
 <div class="row"><label>View<select onchange="rl212StatsScope=this.value;renderOther()"><option value="season" ${rl212StatsScope==='season'?'selected':''}>Season ${s.id}</option><option value="career" ${rl212StatsScope==='career'?'selected':''}>Entire career</option></select></label>
 <label>Compare by<select onchange="sortStat=this.value;renderOther()">${['goals','assists','saves','shots'].map(k=>`<option value="${k}" ${k===sortStat?'selected':''}>${k[0].toUpperCase()+k.slice(1)}</option>`).join('')}</select></label></div>
 ${top}
 ${ordered.length?`<h3>Teammate Comparison</h3>${ordered.map(p=>`<div class="rl212-watch-item"><p>${safe(p.name)} · ${p[key]} ${safe(key)} · ${p.matches} games</p><div class="rl212-bar"><span style="width:${ordered[0][key]?p[key]/ordered[0][key]*100:0}%"></span></div></div>`).join('')}<h3>Individual Player Analysis</h3>${players}`:'<p class="notice">No individual player statistics have been recorded yet. Enter your stats on Home or simulate matches from Settings.</p>'}`;
}
// Stats creation: simulated output is marked; actual manual entries are never rewritten.
function rl212GeneratedStats(s,teamGoals,oppositionGoals){
 const result={__source:'simulated'},total=Math.max(1,Number(s.mode)||1),weights=Array.from({length:total},()=>.4+Math.random()*1.4),pick=avoid=>{
  const eligible=weights.map((x,i)=>i===avoid?0:x);let n=Math.random()*eligible.reduce((a,b)=>a+b,0);
  for(let i=0;i<eligible.length;i++){n-=eligible[i];if(n<=0)return i}return eligible.findIndex(x=>x>0);
 };
 for(let i=0;i<total;i++)result[i]={goals:0,assists:0,saves:0,shots:0};
 for(let g=0;g<teamGoals;g++){const i=pick(-1);result[i].goals++;if(total>1&&Math.random()<.68){const a=pick(i);if(a>=0)result[a].assists++}}
 for(let i=0;i<total;i++){
  const p=result[i];p.shots=p.goals+testPoisson(Math.max(.3,1.7+weights[i]*.5));
  p.saves=testPoisson(Math.max(.2,.65+Math.max(0,oppositionGoals)*.2+weights[i]*.3));
 }
 return result;
}
function rl212AssignPlayerStats(s,w){
 if(s.playerStats?.[w]&&Object.keys(s.playerStats[w]).length)return;
 const index=fixtures(s,w).findIndex(([a,b])=>a==='Custom'||b==='Custom');
 if(index<0||!s.results[w]?.[index])return;
 const [a,b]=fixtures(s,w)[index],score=s.results[w][index];
 const ours=a==='Custom'?score[0]:score[1],theirs=a==='Custom'?score[1]:score[0];
 s.playerStats[w]=rl212GeneratedStats(s,ours,theirs);
}
function rl212AssignPlayoffStats(s,w,score,m){
 if(![m.a,m.b].includes('Custom'))return;
 const mine=m.a==='Custom'?score[0]:score[1],theirs=m.a==='Custom'?score[1]:score[0];
 s.playoffPlayerStats ||= {};
 s.playoffPlayerStats[w]=rl212GeneratedStats(s,mine,theirs);
}
// The completed-season marker is deliberately distinct from displayed rarity events.
// It does not reveal a recipient, achievement name, or Mythic progress in the UI.
function rl212HuntAllRecords(){return Array.isArray(db.huntHistory)?db.huntHistory:[]}
function rl212HuntStatistics(){
 return ['Mythic','Godly'].map(kind=>{
  const runs=rl212HuntAllRecords().filter(x=>!x.sealed&&(x.target===kind||x.target==='either'));
  const won=runs.filter(x=>x.success && (kind==='Mythic'?x.rarity==='Mythic'||x.rarity==='Godly':x.rarity==='Godly'));
  const avg=won.length?won.reduce((n,x)=>n+x.seasons,0)/won.length:null;
  // Mixed-target hunts stop on either rarity and therefore are censored for the other rarity.
  const valid=runs.filter(x=>x.target===kind);
  const successful=valid.filter(x=>x.success).length;
  return {kind,avg,n:won.length,total:valid.length,success:valid.length?(100*successful/valid.length).toFixed(1)+'%':'—'};
 });
}
let rl212Hunt=null,rl212HuntMessage='No hunt running.';
function rl212HuntSettingsHTML(){
 const cap=RL212_CAPS.includes(db.huntCap)?db.huntCap:1000,target=['Mythic','Godly','either'].includes(db.huntTarget)?db.huntTarget:'either';
 const stats=rl212HuntStatistics();
 const running=!!rl212Hunt,done=rl212Hunt?.seasons||0,percent=rl212Hunt&&rl212Hunt.cap!=='unlimited'?Math.min(100,100*done/rl212Hunt.cap):0;
 return `<section class="rl212-panel" id="rl212HuntSection"><h3>☀️ Mythic & Godly Hunt Simulator</h3><p class="muted">Advances your actual career until a NEW rarity milestone occurrence is earned. The award name and recipient remain secret until Awards Night. Finishes the current season, including playoffs, then stops before the ceremony.</p>
 <div class="rl212-hunt-controls"><label>Target rarity<select id="rl212HuntTarget" onchange="db.huntTarget=this.value;persist()" ${running?'disabled':''}><option value="either" ${target==='either'?'selected':''}>Mythic or Godly (default)</option><option value="Mythic" ${target==='Mythic'?'selected':''}>Mythic only</option><option value="Godly" ${target==='Godly'?'selected':''}>Godly only</option></select></label>
 <label>Season safety cap<select id="rl212HuntCap" onchange="db.huntCap=this.value==='unlimited'?'unlimited':Number(this.value);persist()" ${running?'disabled':''}>${RL212_CAPS.map(n=>`<option value="${n}" ${String(n)===String(cap)?'selected':''}>${n==='unlimited'?'Unlimited':Number(n).toLocaleString()+' seasons'}${n===1000?' (default)':''}</option>`).join('')}</select></label></div>
 <div class="rl212-hunt-actions">${running?'<button onclick="rl212StopHunt()">Stop / Cancel</button>':'<button onclick="rl212StartHunt()">Start hunt</button>'}<button onclick="exportData()">Export backup</button></div>
 <p id="rl212HuntStatus" class="rl212-hunt-status" aria-live="polite">${safe(rl212HuntMessage)}</p><progress id="rl212HuntProgress" class="rl212-hunt-progress" max="100" value="${percent}" ${!running||rl212Hunt.cap==='unlimited'?'hidden':''}></progress>
 <h4>Average Seasons to Discovery</h4><div class="rl212-stat-grid">${stats.map(x=>`<div class="rl212-stat"><small>${x.kind}</small><b>${x.avg===null?'—':x.avg.toFixed(1)}</b><small>${x.avg===null?'Not enough data':'Avg. seasons · '+x.n+' successful hunts'}</small><p class="muted">${x.total} dedicated hunts · ${x.success} success rate</p></div>`).join('')}</div><p class="muted">Averages use successful completed hunts. Capped and cancelled hunts are excluded from the simple average; success rates reflect completed dedicated runs. Mixed hunts may stop at the other rarity and are not equivalent to dedicated hunts.</p>
 </section>`;
}
function rl212HuntStatus(message){rl212HuntMessage=message;const p=document.getElementById('rl212HuntStatus');if(p)p.textContent=message;const bar=document.getElementById('rl212HuntProgress');if(bar&&rl212Hunt){bar.hidden=rl212Hunt.cap==='unlimited';bar.value=rl212Hunt.cap==='unlimited'?0:Math.min(100,100*rl212Hunt.seasons/rl212Hunt.cap)}}
function rl212HuntInitStreaks(){
 // Reuse bounded-memory backward history, not a 3-million-match timeline.
 const s=db.seasons.at(-1);
 return rlStreakBefore(s,Infinity);
}
function rl212HuntStrength(s,w,history){
 const rows=stats(s,w),power={},attack={},defense={};
 for(const x of rows){const t=x.t,h=history[t]||{w:0,l:0,gf:0,ga:0,n:0},n=x.w+x.l;
  const historical=((h.w||0)+10)/((h.w||0)+(h.l||0)+20),current=(x.w+10)/(n+20),blend=Math.min(.82,n/(n+18)),prob=(1-blend)*historical+blend*current;
  const form=(x.form||[]).slice(-5).reduce((v,r)=>v+(r==='W'?1:-1),0)/5;
  power[t]=Math.log(prob/(1-prob))+.1*form*blend;
  const weight=Math.min(10,h.n||0);
  attack[t]=Math.log((x.gf+(h.n?h.gf/h.n*weight:0)+2.4*12)/(n+weight+12)/2.4);
  defense[t]=Math.log((x.ga+(h.n?h.ga/h.n*weight:0)+2.4*12)/(n+weight+12)/2.4);
 }return {power,attack,defense};
}
function rl212HuntNewSeason(prev){
 const pool=[...AI];for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]]}const pick=pool.slice(0,9);
 const s=makeSeason(pick,prev.mode);
 s.weeks=prev.weeks;s.playoffCount=prev.playoffCount;s.humanName=prev.humanName;s.botNames=[...prev.botNames];s.badge=prev.badge;s.customName=db.customName;
 s.id=db.seasons.at(-1).id+1;
 db.seasons.push(s);db.active=db.seasons.length-1;return s;
}
function rl212HuntTrackMatch(h,a,b,x,y){
 for(const [t,gf,ga] of [[a,x,y],[b,y,x]]){h.streaks[t]=gf>ga?(h.streaks[t]||0)+1:0;if(h.streaks[t]===100)h.mythicThisSeason=true}
}
function rl212HuntSeasonRarities(h,s){
 if(latest(s)!==s.weeks||!playoffChampion(s))return [];
 const league=stats(s,s.weeks)[0]?.t,champ=playoffChampion(s),found=[];
 if(h.mythicThisSeason)found.push('Mythic');
 // Compact Turbo Hunter history: the worker receives 40 recent seasons plus
 // exact title-streak counters seeded from the entire career. It must detect
 // milestone multiples even when the run began thousands of seasons earlier.
 if(h.runs){
  const advance=(kind,t,qualified)=>{
   if(!qualified||!t)return 0;
   const prior=h.runs[kind],len=prior&&prior.t===t&&prior.id===s.id-1?prior.len+1:1;
   h.runs[kind]={id:s.id,t,len};return len;
  };
  const leagueN=advance('league',league,!!league);
  const champN=advance('champ',champ,!!champ);
  const doubleN=advance('doubles',champ,league===champ);
  let perfect=false;
  if(league===champ){
   const games=rlTimelineForSeason(s).filter(g=>g.a===champ||g.b===champ);
   perfect=games.length===s.weeks+2&&games.every(g=>{const [gf,ga]=rlResultFrom(g,champ);return gf>ga&&ga===0});
  }
  const perfectN=advance('perfect',champ,perfect);
  if(perfect)found.push('Mythic');
  if([leagueN,champN,doubleN].some(n=>n>=10&&n%10===0))found.push('Mythic');
  if(perfectN>=10&&perfectN%10===0)found.push('Godly');
  return [...new Set(found)];
 }
 const games=league===champ?rlTimelineForSeason(s).filter(g=>g.a===champ||g.b===champ):[];
 if(games.length===s.weeks+2 && games.every(g=>{const [gf,ga]=rlResultFrom(g,champ);return gf>ga&&ga===0}))found.push('Mythic');
 // Option B: a continuously-held title is recognised at EXACTLY 10,20,30…
 // seasons, never at 11/12 etc. This MUST match rlMilestoneData().
 const recentConsecutive=(test)=>{
  let n=0,expected=s.id;
  for(let i=db.seasons.length-1;i>=0;i--){
   const x=db.seasons[i];if(x.id!==expected || !test(x))break;
   n++;expected--;
  }
  return n;
 };
 // Computing title and championship streaks once for each currently eligible
 // winner avoids 12 * 18,000 full-history scans per simulated season.
 if(league){const n=recentConsecutive(x=>latest(x)===x.weeks&&stats(x,x.weeks)[0]?.t===league);
  if(n>=10&&n%10===0)found.push('Mythic');}
 if(champ){const n=recentConsecutive(x=>playoffChampion(x)===champ);
  if(n>=10&&n%10===0)found.push('Mythic');}
 if(league===champ){
  const n=recentConsecutive(x=>latest(x)===x.weeks&&stats(x,x.weeks)[0]?.t===champ&&playoffChampion(x)===champ);
  if(n>=10&&n%10===0)found.push('Mythic');
  const perfect=recentConsecutive(x=>{
   if(latest(x)!==x.weeks||stats(x,x.weeks)[0]?.t!==champ||playoffChampion(x)!==champ)return false;
   const all=rlTimelineForSeason(x).filter(g=>g.a===champ||g.b===champ);
   return all.length===x.weeks+2 && all.every(g=>{const [gf,ga]=rlResultFrom(g,champ);return gf>ga&&ga===0});
  });
  if(perfect>=10&&perfect%10===0)found.push('Godly');
 }
 return [...new Set(found)];
}
function rl212HuntFinish(success,rarity,reason){
 const h=rl212Hunt;if(!h)return;
 rl212Hunt=null;
 if(success){
  db.huntHistory ||= [];db.huntHistory.push({target:h.target,seasons:h.seasons,success:true,rarity,seasonId:season().id,sealed:true});
  // Prevent awards from opening automatically. Match results and trophy data remain saved.
  selectedWeek=season().weeks+playoffWeekCount(season())+1;
  rl212HuntMessage='Target reached — ceremony ready. No spoiler! Open Awards Night when you are ready.';
 }else{db.huntHistory ||= [];db.huntHistory.push({target:h.target,seasons:h.seasons,success:false,reason});rl212HuntMessage=reason||'Hunt stopped safely.'}
 if(!persist())rl212HuntMessage+=' Warning: browser storage is full. Export a backup immediately.';
 renderOther();if(currentPage==='settings')rl212HuntStatus(rl212HuntMessage);
}
function rl212StopHunt(){if(!rl212Hunt)return;rl212Hunt.stopped=true;rl212HuntStatus('Stopping after the current season finishes…')}
function rl212StartHunt(){
 if(rl212Hunt||worker||testBatchRunning||calibrationWorker||scenarioWorker)return;
 if(!confirm('MYTHIC & GODLY HUNT\n\nThis permanently simulates matches and future seasons in your current career. Existing recorded results are preserved. A large run can fill browser storage. Export a full JSON backup first.\n\nStart now?'))return;
 const target=['Mythic','Godly','either'].includes(db.huntTarget)?db.huntTarget:'either';
 const cap=RL212_CAPS.includes(db.huntCap)?db.huntCap:1000;
 const s=season();
 if(s!==db.seasons.at(-1)){db.active=db.seasons.length-1;}
 // A previously finished season must not immediately trigger an already-earned rarity.
 rl212Hunt={target,cap,streaks:rl212HuntInitStreaks(),seasons:0,mythicThisSeason:false,stopped:false,history:null};
 rl212HuntStatus('Hunt started. No rarity results will be revealed until Awards Night.');renderOther();setTimeout(rl212HuntTick,0);
}
function rl212HuntTick(){
 const h=rl212Hunt;if(!h)return;
 if(h.stopped&&playoffChampion(season())){rl212HuntFinish(false,null,'Cancelled by user after '+h.seasons+' completed seasons.');return}
 try{
  let s=season();if(s!==db.seasons.at(-1)){db.active=db.seasons.length-1;s=season()}
  if(playoffChampion(s)){
   if(h.cap!=='unlimited'&&h.seasons>=h.cap){rl212HuntFinish(false,null,'Safety cap reached after '+h.seasons+' seasons without a qualifying rarity.');return}
   s=rl212HuntNewSeason(s);h.mythicThisSeason=false;h.history=null;
  }
  if(!h.history)h.history=careerEvidence(s);
  // One regular-season week per batch; yield to Android UI between batches.
  if(latest(s)<s.weeks){
   const w=latest(s)+1,ratings=rl212HuntStrength(s,w-1,h.history);
   const scores=fixtures(s,w).map(([a,b])=>testScore(a,b,ratings));
   s.results[w]=scores;rl212AssignPlayerStats(s,w);
   fixtures(s,w).forEach(([a,b],i)=>rl212HuntTrackMatch(h,a,b,...scores[i]));
  }else{
   let guard=0;
   while(!playoffChampion(s)&&guard++<8){
    const rounds=playoffRounds(s);let pending=null;
    for(let r=0;r<rounds.length&&!pending;r++)for(let i=0;i<rounds[r].matches.length;i++){
     const m=rounds[r].matches[i];if(m.a&&m.b&&!m.winner){pending={r,i,m};break}
    }
    if(!pending)break;
    const {r,i,m}=pending,score=testScore(m.a,m.b,rl212HuntStrength(s,s.weeks,h.history));
    s.playoffs||=[];s.playoffs[r]||=[];s.playoffs[r][i]={a:m.a,b:m.b,score};
    rl212HuntTrackMatch(h,m.a,m.b,...score);
    rl212AssignPlayoffStats(s,s.weeks+r+1,score,m);
   }
   s.champion=playoffChampion(s);
   if(!s.champion){rl212HuntFinish(false,null,'Playoff bracket could not be completed.');return}
   h.seasons++;
   const found=rl212HuntSeasonRarities(h,s);
   const qualifies=found.includes('Godly')&&(h.target==='Godly'||h.target==='either') || found.includes('Mythic')&&(h.target==='Mythic'||h.target==='either');
   if(qualifies&&!h.stopped){db.active=db.seasons.length-1;rl212HuntFinish(true,found.includes('Godly')?'Godly':'Mythic');return}
   // Persist each completed season; stop safely on full browser storage.
   if(!persist()){rl212HuntFinish(false,null,'Browser storage limit reached. Export a backup.');return}
   h.history=null;h.mythicThisSeason=false;
  }
  if(h.stopped&&playoffChampion(s)){rl212HuntFinish(false,null,'Cancelled by user after '+h.seasons+' completed seasons.');return}
  if(h.cap!=='unlimited'&&h.seasons>=h.cap){rl212HuntFinish(false,null,'Safety cap reached after '+h.seasons+' seasons without a qualifying rarity.');return}
  if(currentPage==='settings'&&latest(s)%3===0)rl212HuntStatus(`Simulating Season ${s.id} · ${h.seasons} completed this hunt${h.cap==='unlimited'?'':` / ${h.cap}`} · rarity remains secret`);
  setTimeout(rl212HuntTick,0);
 }catch(e){console.error('Mythic & Godly Hunt failed',e);rl212HuntFinish(false,null,'Hunt stopped due to an error: '+e.message)}
}
// Milestone Centre: compact profile and trophy cabinet, 75% watch, paged Hall.
function rl212Watch(data){
 const approaching=[];
 for(const r of Object.values(data.team)){
  if(!r.seasons.length)continue;
  for(const [label,n,steps] of [['Career wins',r.wins,[10,25,50,100,250,500,1000]],['Career goals',r.gf,[100,250,500,1000,2500]],['Clean sheets',r.clean,[10,25,50,100,250]],['League titles',r.league.length,[5,10]],['Championship titles',r.champ.length,[5,10]]]){
   const next=steps.find(t=>t>n);if(next&&n/next>=.75)approaching.push({id:r.id,label,n,next});
  }
  // Visible winning-streak awards are safe to track. Never expose the
  // hidden 100-win Mythic threshold or any Godly ten-season condition.
  if(r.seasons.at(-1)===season().id){
   const next=[5,10,25,50].find(t=>t>r.streak);
   if(next&&r.streak/next>=.75)approaching.push({id:r.id,label:'Current winning streak',n:r.streak,next});
  }
 }
 approaching.sort((a,b)=>b.n/b.next-a.n/a.next||rlLabel(a.id).localeCompare(rlLabel(b.id)));
 return `<h3>Approaching Milestones</h3>${approaching.length?approaching.slice(0,12).map(x=>`<div class="rl212-watch-item"><p>${rl212Logo(x.id)} <strong>${rlTitle(x.id)}</strong> · ${safe(x.label)} · <b>${x.n}/${x.next} (${(x.n/x.next*100).toFixed(1)}%)</b></p><div class="rl212-bar"><span style="width:${100*x.n/x.next}%"></span></div></div>`).join(''):'<p class="muted">No visible milestones have reached 75% completion yet.</p>'}`;
}
function rl212Trophies(r){
 const doubles=r.league.filter(id=>r.champ.includes(id));
 const groups=[['🏆 Championship Titles',r.champ],['🥇 League Titles',r.league],['💎 Doubles',doubles]];
 return `<div class="rl212-stat-grid">${groups.map(([title,ids])=>`<details class="rl212-stat"><summary><b>${ids.length}</b><small>${title}</small></summary><p>${ids.length?rl212SeasonText(ids):'None earned yet'}</p></details>`).join('')}</div>`;
}
let rl212HallPage=0;
rlMilestonePage=function(){
 const data=rlMilestoneData(),profiles=Object.values(data.team);
 const selected=window.rlSelectedLegacy||'Custom',r=data.team[selected]||profiles[0];
 const hall=data.events.filter(rlMilestoneVisible).slice().reverse();const perPage=80;
 const pages=Math.max(1,Math.ceil(hall.length/perPage));rl212HallPage=Math.min(rl212HallPage,pages-1);
 const visible=hall.slice(rl212HallPage*perPage,(rl212HallPage+1)*perPage);
 const firsts=r.firsts.filter(rlMilestoneVisible);
 const names=profiles.map(x=>`<option value="${safe(x.id)}" ${r.id===x.id?'selected':''}>${rlTitle(x.id)}</option>`).join('');
 return `<h2>🏅 Milestone Centre</h2><p class="muted">Five rarities, from Godly to Standard. Secret achievements stay hidden until their Awards Ceremony reveal.</p>
 ${rl212Watch(data)}
 <h3>Team Legacy Profiles</h3><label>Choose team<select onchange="window.rlSelectedLegacy=this.value;renderOther()">${names}</select></label>
 <div class="rl-legacy-header">${rl212Logo(r.id)}<div><h3>${rlTitle(r.id)}</h3><p>${r.seasons.length} seasons participated</p>${r.names.length>1?`<p class="muted">Historical names: ${safe(r.names.join(' → '))}</p>`:''}</div></div>
 <div class="rl-legacy-numbers">${[[r.wins,'Wins'],[r.losses,'Losses'],[r.gf,'Goals scored'],[r.ga,'Goals conceded'],[r.clean,'Clean sheets'],[r.playoffs.length,'Playoff qualifications'],[r.finals.length,'Finals reached'],[r.best,'Longest win streak']].map(x=>rlLegacyNumber(...x)).join('')}</div>
 <h3>🏆 Trophy Cabinet</h3>${rl212Trophies(r)}
 <details class="rl212-panel"><summary>Career Firsts (${firsts.length})</summary>${firsts.map(e=>`<p>№1 ${safe(e.title)} · Season ${e.season}, Week ${e.week}</p>`).join('')||'<p>No firsts recorded yet.</p>'}</details>
 <h3>Milestone Hall of Fame</h3><p class="muted">Complete earned history: ${hall.length} revealed milestone occurrences. Filtering applies to the current page of ${perPage}; navigate pages to inspect the full record.</p>
 <div class="rl-filterline"><label>Tier<select id="rlMilestoneTier" onchange="rlFilterMilestones()"><option>All</option>${RL_TIERS.map(t=>`<option>${t}</option>`).join('')}</select></label><label>Team<select id="rlMilestoneTeam" onchange="rlFilterMilestones()"><option>All</option>${profiles.map(x=>`<option value="${safe(x.id)}">${rlTitle(x.id)}</option>`).join('')}</select></label></div>
 <div class="row"><button onclick="rl212HallPage--;renderOther()" ${rl212HallPage===0?'disabled':''}>← Newer</button><span>Page ${rl212HallPage+1} of ${pages}</span><button onclick="rl212HallPage++;renderOther()" ${rl212HallPage>=pages-1?'disabled':''}>Older →</button></div>
 <div id="rlMilestoneHall">${visible.map(rlMilestoneCard).join('')||'<p>No milestones earned yet.</p>'}</div>`;
};
// Settings injection: the existing page remains intact, Hunt appears directly below auto-simulation testing.
const rl212BaseRenderOther=renderOther;
renderOther=function(){rl212BaseRenderOther();if(currentPage==='settings'){
 const el=$('other');const title=el.querySelector('h3');
 if(title){const marker=document.createElement('div');marker.innerHTML=rl212HuntSettingsHTML();
  const next=Array.from(el.querySelectorAll('h3')).find(x=>x.textContent.includes('Monte Carlo Calibration'));
  if(next)next.before(marker);else el.append(marker);
 }
 }};
