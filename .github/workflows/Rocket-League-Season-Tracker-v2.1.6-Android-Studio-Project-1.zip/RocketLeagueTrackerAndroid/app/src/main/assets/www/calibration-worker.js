// v0.9.2: calibration uses the same frozen strength priors, latent drift,
// scoring and playoff model as sim-worker.js (v4). Read-only worker.
self.onmessage=e=>{
 const {runs,teams,games,history={},playoffCount=6,preseason=[],baseline=[]}=e.data;
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 const sigmoid=x=>1/(1+Math.exp(-x));
 const prior=Object.fromEntries(preseason.map(x=>[x.t,x]));
 const base=Object.fromEntries(baseline.map(x=>[x.t,x]));
 const count=Object.fromEntries(teams.map(t=>[t,{title:0,top:0,champ:0}]));
 const power={},attack={},defense={};
 for(const t of teams){
  const x=base[t]||{w:0,l:0,gf:0,ga:0,form:[]},h=history[t]||{w:0,l:0,gf:0,ga:0,n:0},n=x.w+x.l;
  const historical=((h.w||0)+10)/((h.w||0)+(h.l||0)+20),current=(x.w+10)/(n+20);
  const blend=clamp(n/(n+18),0,.82),p=(1-blend)*historical+blend*current;
  const form=(x.form||[]).slice(-5).reduce((v,r)=>v+(r==='W'?1:-1),0)/5;
  power[t]=Math.log(p/(1-p))+.10*form*blend;
  const weight=Math.min(10,h.n||0);
  attack[t]=Math.log((x.gf+(h.n?h.gf/h.n*weight:0)+2.4*12)/(n+weight+12)/2.4);
  defense[t]=Math.log((x.ga+(h.n?h.ga/h.n*weight:0)+2.4*12)/(n+weight+12)/2.4);
 }
 const chance=(a,b,latent)=>clamp(sigmoid((power[a]-power[b])*.85+latent[a]-latent[b]),.07,.93);
 function poisson(mean){let L=Math.exp(-mean),p=1,k=0;do{k++;p*=Math.random()}while(p>L&&k<30);return k-1}
 function play(a,b,st,latent){
  const diff=power[a]-power[b]+latent[a]-latent[b];
  const ma=clamp(2.4*Math.exp(.20*diff+.17*(attack[a]-defense[b])),.65,5.4);
  const mb=clamp(2.4*Math.exp(-.20*diff+.17*(attack[b]-defense[a])),.65,5.4);
  let ga=poisson(ma),gb=poisson(mb);
  if(ga===gb){if(Math.random()<chance(a,b,latent))ga++;else gb++}
  const A=st[a],B=st[b];A.gf+=ga;A.ga+=gb;B.gf+=gb;B.ga+=ga;
  if(ga>gb)A.w++;else B.w++;
 }
 const winner=(a,b,latent)=>Math.random()<chance(a,b,latent)?a:b;
 let iter=0;
 function batch(){
  const end=Math.min(runs,iter+10);
  for(;iter<end;iter++){
   const st=Object.fromEntries(teams.map(t=>{const x=base[t]||{w:0,gf:0,ga:0};return[t,{t,w:x.w,gf:x.gf,ga:x.ga}]}));
   const latent=Object.fromEntries(teams.map(t=>[t,(Math.random()+Math.random()+Math.random()-1.5)*.12]));
   let lastWeek=0;
   for(const g of games){
    if(g.w!==lastWeek){
     for(const t of teams)latent[t]=clamp(.94*latent[t]+(Math.random()+Math.random()+Math.random()-1.5)*.06,-.45,.45);
     lastWeek=g.w;
    }
    play(g.a,g.b,st,latent);
   }
   const sorted=Object.values(st).sort((a,b)=>b.w-a.w||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||a.t.localeCompare(b.t));
   count[sorted[0].t].title++;
   for(let i=0;i<playoffCount;i++)count[sorted[i].t].top++;
   let sf1,sf2;
   if(playoffCount===4){sf1=winner(sorted[0].t,sorted[3].t,latent);sf2=winner(sorted[1].t,sorted[2].t,latent)}
   else{const q1=winner(sorted[2].t,sorted[5].t,latent),q2=winner(sorted[3].t,sorted[4].t,latent);sf1=winner(sorted[0].t,q2,latent);sf2=winner(sorted[1].t,q1,latent)}
   count[winner(sf1,sf2,latent)].champ++;
  }
  postMessage({progress:iter});
  if(iter<runs){setTimeout(batch,0);return}
  postMessage({done:true,runs,playoffCount,modelVersion:4,rows:teams.map(t=>({t,title:100*count[t].title/runs,top:100*count[t].top/runs,champ:100*count[t].champ/runs,predTitle:prior[t]?.title??null,predTop:prior[t]?.top6??null,predChamp:prior[t]?.champ??null})).sort((a,b)=>b.title-a.title)});
 }
 batch();
};
