'use strict';
/* v2.1.4 Career Record Book. Additive read-only historical calculations;
   original v2.1.3 data, awards, season simulations and saves are unchanged. */
const RL215_FORMATS=[9,18,27,36];
const RL215_SEASON_RECORDS=[
 {key:'w',title:'Most Wins',short:'Wins',icon:'🏆',color:'#F4C34F',minimum:false},
 {key:'gf',title:'Most Goals',short:'Goals',icon:'⚽',color:'#30C8FF',minimum:false},
 {key:'gaMin',title:'Fewest Conceded',short:'Conceded',icon:'🛡',color:'#19C878',minimum:true},
 {key:'l',title:'Most Losses',short:'Losses',icon:'↘',color:'#FF7777',minimum:false},
 {key:'gfMin',title:'Least Goals',short:'Goals',icon:'◌',color:'#E6A0A1',minimum:true},
 {key:'ga',title:'Most Conceded',short:'Conceded',icon:'⚠',color:'#FF8A32',minimum:false}
];
const RL215_CAREER_RECORDS=[
 {key:'champ',title:'Most Championships',icon:'🏆',color:'#F4C34F'},
 {key:'gf',title:'Most Career Goals',icon:'⚽',color:'#30C8FF'},
 {key:'best',title:'Longest Win Streak',icon:'🔥',color:'#B875F5'},
 {key:'clean',title:'Most Clean Sheets',icon:'🛡',color:'#19C878'},
 {key:'wins',title:'Most Match Wins',icon:'✦',color:'#8DD9FC'},
 {key:'league',title:'Most League Titles',icon:'🥇',color:'#F4C34F'},
 {key:'playoffs',title:'Most Playoff Appearances',icon:'🏟',color:'#8DD9FC'},
 {key:'finals',title:'Most Championship Final Appearances',icon:'🥈',color:'#C1D4F0'},
 {key:'runner',title:'Most Championship Runner-Ups',icon:'🥈',color:'#C1D4F0',yearsKey:'runnerYears'},
 {key:'champRun',title:'Longest Championship Streak',icon:'🏆',color:'#F4C34F',yearsKey:'champRunSeason'},
 {key:'leagueRun',title:'Longest League Title Streak',icon:'🥇',color:'#F4C34F',yearsKey:'leagueRunSeason'},
 {key:'playoffRun',title:'Longest Playoff Qualification Streak',icon:'🏟',color:'#8DD9FC',yearsKey:'playoffRunSeason'}
];
let rl215Cache=null,rl215Revision=0,rl215JobId=0;
const rl215BeforeInvalidate=rl211Invalidate;
rl211Invalidate=function(){rl215Revision++;rl215Cache=null;return rl215BeforeInvalidate()};
const rl215OriginalCareerPage=rl212CareerPage;
rl212CareerPage=function(){
 const old=rl215OriginalCareerPage(),marker='<details class="rl212-panel"><summary>League Hall of Fame';
 const i=old.indexOf(marker);
 if(i<0)return old;
 let rest=old.slice(i);
 // The huge former table is no longer a second, hidden historical panel.
 rest=rest.replace(/<details class="rl212-panel" ontoggle="rl211LoadCareerExtras\(this\)"><summary>Additional Historical Records<\/summary><div class="rl211-lazy-content"><p class="muted">Expand to calculate additional historical records\.<\/p><\/div><\/details>/,'');
 return `<section class="rl215-book"><header class="rl215-book-head"><div><h2>🏆 Career Record Book</h2><p class="muted">All-time achievements · Official records update at the following preseason</p></div></header><div id="rl215RecordBook" role="region" aria-label="Career Record Book"><p class="rl215-loading" role="status">Loading historical records…</p></div></section>`+rest;
};
const rl215OriginalRenderOther=renderOther;
renderOther=function(){
 const out=rl215OriginalRenderOther();
 if(currentPage==='career')rl215LoadRecords();
 return out;
};
function rl215Blank(minimum=false){return {value:minimum?Infinity:-Infinity,holders:new Map()}}
function rl215Track(r,value,team,seasonId){
 if(!Number.isFinite(value))return;
 const better=r.minimum?value<r.value:value>r.value;
 if(better){r.value=value;r.holders=new Map()}
 if(value===r.value){
  let rec=r.holders.get(team);if(!rec){rec=[];r.holders.set(team,rec)}
  // Each team/season occurs once even if raw results are reprocessed.
  if(rec.at(-1)!==seasonId)rec.push(seasonId);
 }
}
function rl215InitialRecord(minimum){const r=rl215Blank(minimum);r.minimum=minimum;return r}
function rl215NewData(){
 const formats=Object.fromEntries(RL215_FORMATS.map(n=>[n,{count:0,records:Object.fromEntries(RL215_SEASON_RECORDS.map(x=>[x.key,rl215InitialRecord(x.minimum)]))}]));
 return {formats,teams:new Map(),matches:{combined:rl215InitialRecord(false),margin:rl215InitialRecord(false)},matchHolders:{combined:[],margin:[]},completed:0};
}
function rl215Team(data,id){
 let t=data.teams.get(id);
 if(!t){t={id,wins:0,losses:0,gf:0,ga:0,clean:0,best:0,run:0,bestSeason:[],league:0,champ:0,playoffs:0,finals:0,runner:0,runnerYears:[],champRun:0,leagueRun:0,playoffRun:0,champRunSeason:[],leagueRunSeason:[],playoffRunSeason:[],_lastChamp:0,_lastLeague:0,_lastPlayoff:0,_curChamp:0,_curLeague:0,_curPlayoff:0};data.teams.set(id,t)}
 return t;
}
function rl215ProcessSeason(data,s){
 const n=s.weeks,block=data.formats[n];if(!block)return;
 const members=teams(s);const seasonRows=Object.fromEntries(members.map(t=>[t,{t,w:0,l:0,gf:0,ga:0}]));
 const games=rlTimelineForSeason(s);
 for(const g of games){
  const diff=Math.abs(g.x-g.y),combined=g.x+g.y;
  const label={season:s.id,week:g.w,a:g.a,b:g.b,x:g.x,y:g.y,playoff:g.playoff,n:s.weeks};
  for(const [key,value] of [['combined',combined],['margin',diff]]){
   const r=data.matches[key];
   if(value>r.value){r.value=value;data.matchHolders[key]=[label]}
   else if(value===r.value){data.matchHolders[key].push(label)}
  }
  for(const [id,gf,ga] of [[g.a,g.x,g.y],[g.b,g.y,g.x]]){
   const t=rl215Team(data,id);t.gf+=gf;t.ga+=ga;t.wins+=gf>ga?1:0;t.losses+=gf<ga?1:0;t.clean+=ga===0?1:0;
   t.run=gf>ga?t.run+1:0;
   if(t.run>t.best){t.best=t.run;t.bestSeason=[s.id]}
   else if(t.run===t.best&&t.best>0&&t.bestSeason.at(-1)!==s.id)t.bestSeason.push(s.id);
   if(!g.playoff){const row=seasonRows[id];if(!row)continue;row.gf+=gf;row.ga+=ga;row.w+=gf>ga?1:0;row.l+=gf<ga?1:0}
  }
 }
 const league=Object.values(seasonRows).sort((a,b)=>b.w-a.w||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||name(a.t,s).localeCompare(name(b.t,s)));
 if(league.length){rl215Team(data,league[0].t).league++;
  for(const row of league.slice(0,s.playoffCount))rl215Team(data,row.t).playoffs++;
 }
 const final=playoffRounds(s).at(-1)?.matches?.[0];
 if(final?.winner){rl215Team(data,final.winner).champ++;if(final.a)rl215Team(data,final.a).finals++;if(final.b)rl215Team(data,final.b).finals++}
 // Restore the three historical consecutive-season records and runners-up.
 // Every streak is keyed to season IDs, so an absent team breaks its run.
 const champion=playoffChampion(s),qualifiers=new Set(league.slice(0,s.playoffCount).map(r=>r.t));
 if(final?.winner&&final.a&&final.b){const loser=final.winner===final.a?final.b:final.a;rl215Team(data,loser).runner++;rl215Team(data,loser).runnerYears.push(s.id)}
 for(const id of members){
  const t=rl215Team(data,id);
  for(const [field,last,current,years,qualifies] of [
   ['champRun','_lastChamp','_curChamp','champRunSeason',id===champion],
   ['leagueRun','_lastLeague','_curLeague','leagueRunSeason',id===league[0]?.t],
   ['playoffRun','_lastPlayoff','_curPlayoff','playoffRunSeason',qualifiers.has(id)]
  ]){
   if(!qualifies){t[current]=0;continue}
   t[current]=t[last]===s.id-1?t[current]+1:1;t[last]=s.id;
   if(t[current]>t[field]){t[field]=t[current];t[years]=[s.id]}
   else if(t[current]===t[field]&&t[years].at(-1)!==s.id)t[years].push(s.id);
  }
 }
 block.count++;data.completed++;
 for(const row of Object.values(seasonRows))for(const def of RL215_SEASON_RECORDS){
  const val=def.key==='gaMin'?row.ga:def.key==='gfMin'?row.gf:row[def.key];
  rl215Track(block.records[def.key],val,row.t,s.id);
 }
}
function rl215CacheKey(active){
 return `${rl215Revision}:${db.seasons.length}:${db.seasons.at(-1)?.id||0}:${active.id}:${active.weeks}`;
}
function rl215LoadRecords(){
 const container=document.getElementById('rl215RecordBook');if(!container)return;
 const active=season(),key=rl215CacheKey(active);
 if(rl215Cache?.db===db&&rl215Cache.key===key){container.innerHTML=rl215Render(rl215Cache.data,active);return}
 const id=++rl215JobId;
 // Completed official seasons only. A finished active season is held back until
 // a new preseason starts. Historic views cannot see future records.
 const past=db.seasons.filter(s=>s.id<active.id&&RL215_FORMATS.includes(s.weeks));
 const data=rl215NewData();let i=0;
 function step(){
  if(id!==rl215JobId||!container.isConnected)return;
  try{
   const begun=performance.now();let done=0;
   while(i<past.length&&done<48&&performance.now()-begun<12){
    const s=past[i++];done++;
    if(latest(s)===s.weeks&&playoffChampion(s))rl215ProcessSeason(data,s);
   }
   if(i<past.length){
    if(done&&i%240<48)container.innerHTML=`<p class="rl215-loading" role="status">Calculating career records… ${Math.round(i*100/past.length)}% · ${i.toLocaleString()} / ${past.length.toLocaleString()} seasons</p>`;
    setTimeout(step,0);return;
   }
   rl215Cache={db,key,data};container.innerHTML=rl215Render(data,active);
  }catch(e){console.error('Record Book calculation failed',e);container.innerHTML=`<p class="notice" role="alert">Could not calculate the records: ${safe(e.message||e)}. <button onclick="rl215Cache=null;rl215LoadRecords()">Retry</button></p>`}
 }
 setTimeout(step,0);
}
function rl215Logo(id){return rl210PlainIcon(id)}
function rl215TeamSort(a,b){return b[1].length-a[1].length||rlLabel(a[0]).localeCompare(rlLabel(b[0]))}
function rl215Grouped(holders){return [...holders.entries()].sort(rl215TeamSort)}
function rl215Seasons(years){return years.map(n=>safe(seasonLabel(n))).join(', ')}
function rl215GroupLine(id,seasons,short=false){
 const all=short&&seasons.length>2?seasons.slice(0,2):seasons;
 return `<div class="rl215-holder"><span class="rl215-logo">${rl215Logo(id)}</span><div class="rl215-holder-text"><strong>${rlTitle(id)}</strong><span class="rl215-years"> — ${rl215Seasons(all)}${all.length<seasons.length?' …':''}</span></div></div>`;
}
function rl215AllGroups(holderMap){
 const groups=rl215Grouped(holderMap);
 if(!groups.length)return '<p class="muted">No qualifying record yet.</p>';
 const preview=groups.slice(0,1).map(([id,years])=>rl215GroupLine(id,years,true)).join('');
 const extra=groups.length>1?`<div class="rl215-more-teams">+${groups.length-1} tied team${groups.length===2?'':'s'}</div>`:'';
 const more=groups.length>1||groups.some(([,years])=>years.length>2);
 return preview+extra+(more?`<details class="rl215-tied"><summary>View all ${groups.reduce((n,[,years])=>n+years.length,0).toLocaleString()} occurrence${groups.reduce((n,[,years])=>n+years.length,0)===1?'':'s'}</summary><div class="rl215-tied-body">${groups.map(([id,years])=>rl215GroupLine(id,years)).join('')}</div></details>`:'');
}
function rl215LifetimeHolders(data,key,value){
 const m=new Map();
 for(const team of data.teams.values()){
  if(team[key]!==value)continue;
  m.set(team.id,key==='best'?team.bestSeason:[]);
 }
 return [...m.keys()].sort((a,b)=>rlLabel(a).localeCompare(rlLabel(b)));
}
function rl215LifetimeYears(team,def){
 const years=team[def.yearsKey||'bestSeason']||[];
 const peak=Number(team[def.key])||0;
 const short=years.slice(0,3).map(end=>
  def.yearsKey&&def.key!=='runner'&&peak>1
   ?`${safe(seasonLabel(end-peak+1))}–${safe(seasonLabel(end))}`
   :safe(seasonLabel(end)));
 return short.join(', ')+(years.length>3?'…':'');
}
function rl215LifetimeCard(data,def,featured){
 const teams=[...data.teams.values()],peak=Math.max(0,...teams.map(t=>t[def.key]));
 const holders=peak||data.completed?rl215LifetimeHolders(data,def.key,peak):[];
 const teamHTML=holders.slice(0,2).map(id=>`<span class="rl215-career-person">${rl215Logo(id)} <strong>${rlTitle(id)}</strong>${(def.key==='best'||def.yearsKey)?`<small class="rl215-best-years">${rl215LifetimeYears(data.teams.get(id),def)} </small>`:''}</span>`).join('');
 const extra=holders.length>2?`<span class="rl215-plus">+${holders.length-2} tied</span>`:'';
 const more=holders.length>2?`<details class="rl215-tied"><summary>All ${holders.length} tied holders</summary><div class="rl215-tied-body">${holders.map(id=>`<div class="rl215-career-person">${rl215Logo(id)} ${rlTitle(id)}</div>`).join('')}</div></details>`:'';
 return `<article class="${featured?'rl215-feature-card':'rl215-small-row'}" style="--accent:${def.color}">
  ${featured?`<div class="rl215-card-label"><span>${def.icon}</span> ${safe(def.title)}</div><div class="rl215-card-value">${holders.length?peak.toLocaleString():'—'}</div><div class="rl215-career-holders">${teamHTML}${extra}</div>${more}`:
  `<div class="rl215-small-name"><span>${def.icon}</span> ${safe(def.title)}</div><strong class="rl215-small-number">${holders.length?peak.toLocaleString():'—'}</strong><div class="rl215-small-owners">${teamHTML}${extra}${more}</div>`}</article>`;
}
function rl215SeasonCard(def,record){
 const exists=Number.isFinite(record.value),people=rl215Grouped(record.holders);
 return `<article class="rl215-season-card" style="--accent:${def.color}">
  <div class="rl215-season-label"><span class="rl215-season-icon">${def.icon}</span><span>${safe(def.title)}</span></div>
  <strong class="rl215-season-value">${exists?record.value.toLocaleString():'—'}</strong>
  ${exists?rl215AllGroups(record.holders):'<span class="muted">No completed seasons</span>'}
 </article>`;
}
function rl215MatchDetails(data,key){
 const r=data.matches[key],ties=data.matchHolders[key];if(r.value===-Infinity)return '<div class="rl215-small-row"><span class="muted">No recorded matches</span></div>';
 const prefix=key==='combined'?'Highest Combined-Score Match':'Biggest Winning Margin';
 const summary=ties[0];const desc=g=>`<div class="rl216-match-detail"><div class="rl216-match-scoreline"><span class="rl215-match-team">${rl215Logo(g.a)} <span>${rlTitle(g.a)}</span></span><strong class="rl216-match-score">${g.x}–${g.y}</strong><span class="rl215-match-team">${rl215Logo(g.b)} <span>${rlTitle(g.b)}</span></span></div><small class="rl216-match-when">${safe(seasonLabel(g.season))} · ${g.playoff?'Playoff Week '+(g.week-g.n):'Week '+g.week}</small></div>`;
 return `<div class="rl215-small-row rl215-match-row"><div class="rl215-small-name">${key==='combined'?'⚽':'↔'} ${prefix}</div><strong class="rl215-small-number">${r.value.toLocaleString()}</strong><div class="rl215-small-owners"><div>${desc(summary)}</div>${ties.length>1?`<details class="rl215-tied"><summary>View all ${ties.length.toLocaleString()} tied matches</summary><div class="rl215-tied-body">${ties.map(g=>`<div>${desc(g)}</div>`).join('')}</div></details>`:''}</div></div>`;
}
function rl215Render(data,active){
 const format=data.formats[active.weeks],n=format?.count||0;
 return `<div class="rl215-feature-grid">${RL215_CAREER_RECORDS.slice(0,4).map(r=>rl215LifetimeCard(data,r,true)).join('')}</div>
  <h3 class="rl215-minor-title">Additional Historical Records</h3>
  <div class="rl215-minor-list">${RL215_CAREER_RECORDS.slice(4).map(r=>rl215LifetimeCard(data,r,false)).join('')}${rl215MatchDetails(data,'combined')}${rl215MatchDetails(data,'margin')}</div>
  <div class="rl215-section-title"><div><h3>📅 Season Records</h3><p class="muted">${active.weeks}-week seasons · ${n.toLocaleString()} completed · Regular season only</p></div><span class="rl215-format-chip">${active.weeks} WEEKS</span></div>
  <div class="rl215-season-grid">${RL215_SEASON_RECORDS.map(def=>rl215SeasonCard(def,format?format.records[def.key]:rl215InitialRecord(def.minimum))).join('')}</div>
  <p class="rl215-footnote">Records are announced as they happen, then added to this official book when the following preseason begins. Only seasons completed before ${safe(seasonLabel(active.id))} are included.</p>`;
}

// Live benchmarks use prior, *officially completed* seasons of the same length.
// Cache by target season: a completed earlier career is unchanged as the active
// season advances from Week 1 to Week 36. Repeated 18,000-season rescans during
// normal score entry would otherwise freeze a mobile browser.
let rl215LiveBaseline=null;
function rl215GetLiveBaseline(s){
 const id=`${db.seasons.length}:${s.id}:${s.weeks}`;
 if(rl215LiveBaseline?.db===db&&rl215LiveBaseline.id===id)return rl215LiveBaseline.data;
 const baseline={w:-Infinity,l:-Infinity,gf:-Infinity,ga:-Infinity,gfMin:Infinity,gaMin:Infinity,combined:-Infinity,margin:-Infinity,count:0};
 const fromBook=rl215Cache?.db===db&&rl215Cache.key===rl215CacheKey(s)?rl215Cache.data:null;
 if(fromBook){
  const r=fromBook.formats[s.weeks];
  for(const k of ['w','l','gf','ga','gfMin','gaMin'])baseline[k]=r.records[k].value;
  baseline.count=r.count;
  baseline.combined=fromBook.matches.combined.value;
  baseline.margin=fromBook.matches.margin.value;
 }else{
  for(const p of db.seasons){
   if(p.id>=s.id||p.weeks!==s.weeks||latest(p)!==p.weeks||!playoffChampion(p))continue;
   baseline.count++;
   for(const r of stats(p,p.weeks)){
    for(const k of ['w','l','gf','ga'])baseline[k]=Math.max(baseline[k],r[k]);
    baseline.gfMin=Math.min(baseline.gfMin,r.gf);
    baseline.gaMin=Math.min(baseline.gaMin,r.ga);
   }
  }
  // Match records are career-wide rather than per-season-format.
  for(const p of db.seasons){
   if(p.id>=s.id||latest(p)!==p.weeks||!playoffChampion(p))continue;
   for(const g of rlTimelineForSeason(p)){
    baseline.combined=Math.max(baseline.combined,g.x+g.y);
    baseline.margin=Math.max(baseline.margin,Math.abs(g.x-g.y));
   }
  }
 }
 rl215LiveBaseline={db,id,data:baseline};return baseline;
}
// Negative totals (fewest goals/conceded) can only be finalized in Week N.
recordMilestones=function(s,w){
 if(!Number.isInteger(w)||w<1||w>s.weeks||latest(s)<w)return [];
 const baseline=rl215GetLiveBaseline(s);
 const names={w:'Most Wins',gf:'Most Goals',gaMin:'Fewest Conceded',l:'Most Losses',gfMin:'Least Goals',ga:'Most Conceded'};
 const messages=[];
 const rows=stats(s,w),previous=stats(s,w-1),old=Object.fromEntries(previous.map(r=>[r.t,r]));
 for(const t of rows){for(const def of RL215_SEASON_RECORDS){
  if(!baseline.count||def.minimum&&w!==s.weeks)continue;
  const key=def.key,metric=key==='gfMin'?'gf':key==='gaMin'?'ga':key;
  const v=t[metric],oldValue=old[t.t]?.[metric]??0,baselineValue=baseline[key];
  const improved=def.minimum?v<baselineValue:v>baselineValue;
  const equalled=v===baselineValue;
  // For maxima, only announce when the current week's result crosses a
  // threshold (or improves a previous already-breaking value).
  if(!def.minimum&&v===oldValue)continue;
  if(improved)messages.push(`NEW ${names[key]} RECORD · ${name(t.t,s)} · ${v} (${seasonLabel(s.id)}, Week ${w}; previous ${baselineValue})`);
  else if(equalled&&(!def.minimum&&oldValue<baselineValue||def.minimum))messages.push(`RECORD EQUALED · ${names[key]} · ${name(t.t,s)} · ${v} (${seasonLabel(s.id)}, Week ${w})`);
 }}
 // Single-game records are also announced as soon as a new highest score or
 // margin appears; playoff results remain part of the all-time match records.
 let highestCombined=baseline.combined,highestMargin=baseline.margin;
 for(const g of rlTimelineForSeason(s)){
  if(g.w>=w)continue;
  highestCombined=Math.max(highestCombined,g.x+g.y);
  highestMargin=Math.max(highestMargin,Math.abs(g.x-g.y));
 }
 for(const [i,[a,b]] of fixtures(s,w).entries()){
  const score=s.results[w]?.[i];if(!Array.isArray(score)||score.length!==2)continue;
  const [x,y]=score;
  for(const [value,current,kind] of [[x+y,highestCombined,'Highest Combined-Score Match'],[Math.abs(x-y),highestMargin,'Biggest Winning Margin']]){
   if(value>current)messages.push(`NEW ${kind.toUpperCase()} RECORD · ${name(a,s)} ${x}–${y} ${name(b,s)} · ${value} (${seasonLabel(s.id)}, Week ${w})`);
   else if(value===current&&current>0)messages.push(`RECORD EQUALED · ${kind} · ${name(a,s)} ${x}–${y} ${name(b,s)} (${seasonLabel(s.id)}, Week ${w})`);
  }
  highestCombined=Math.max(highestCombined,x+y);
  highestMargin=Math.max(highestMargin,Math.abs(x-y));
 }
 return messages.slice(0,10);
}
const rl215BeforeNotice=showRecordNotice;
showRecordNotice=function(messages){
 if(!messages?.length)return;
 const isSeason=messages.some(m=>typeof m==='string'&&(/RECORD|Most Wins|Most Goals/.test(m)));
 if(!isSeason)return rl215BeforeNotice(messages);
 const el=document.createElement('div');el.className='record-toast rl215-record-notice';el.setAttribute('role','status');
 el.innerHTML=`<strong>🏆 ${messages.some(m=>String(m).startsWith('NEW'))?'NEW ALL-TIME RECORD!':'RECORD MILESTONE!'}</strong><p>${messages.slice(0,8).map(m=>safe(m)).join('<br>')}</p><button onclick="this.parentElement.remove()">Dismiss</button>`;
 document.body.appendChild(el);setTimeout(()=>el.remove(),14000);
};

// Give the streak its own named badge, leaving previous-season medals beside
// the team name and retaining the exact existing nine-tier flame artwork.
const rl215BeforeLeagueHTML=leagueTableHTML;
leagueTableHTML=function(s,w){
 const html=rl215BeforeLeagueHTML(s,w);
 // Only team-column streaks: fixture flame markup is untouched.
 return html.replace(/(<span class="rl-streak-fire[^>]*>.*?<\/span><\/span>)/g,match=>{
   const color=match.match(/--fire:([^;" ]+)/)?.[1]||'#FF8A32';
   return `<span class="rl215-streak-badge" style="--fire:${color}">${match}</span>`;
 });
};

// Playoff scores may also set the two all-time single-match records.
// Compare the saved result before/after editing without touching the records
// calculation or the existing playoff/ceremony flow.
const rl215BeforeSavePlayoff=savePlayoff;
savePlayoff=function(round,index){
 const s=season(),prior=rl215GetLiveBaseline(s);
 let beforeTotal=prior.combined,beforeMargin=prior.margin;
 for(const g of rlTimelineForSeason(s)){
  beforeTotal=Math.max(beforeTotal,g.x+g.y);
  beforeMargin=Math.max(beforeMargin,Math.abs(g.x-g.y));
 }
 const before=s.playoffs?.[round]?.[index]?.score?.join(',');
 const result=rl215BeforeSavePlayoff(round,index);
 const score=s.playoffs?.[round]?.[index]?.score;
 if(!Array.isArray(score)||score.join(',')===before)return result;
 const m=playoffRounds(s)[round]?.matches?.[index];
 if(!m?.a||!m?.b)return result;
 const [x,y]=score,messages=[];
 if(x+y>beforeTotal)messages.push(`NEW HIGHEST COMBINED-SCORE MATCH RECORD · ${name(m.a,s)} ${x}–${y} ${name(m.b,s)} · ${x+y} (${seasonLabel(s.id)}, Playoffs)`);
 if(Math.abs(x-y)>beforeMargin)messages.push(`NEW BIGGEST WINNING MARGIN RECORD · ${name(m.a,s)} ${x}–${y} ${name(m.b,s)} · ${Math.abs(x-y)} (${seasonLabel(s.id)}, Playoffs)`);
 if(messages.length)showRecordNotice(messages);
 return result;
};

// Turbo Hunter never interrupts an automated run with record popups. After it
// stops, compare its newly confirmed, completed seasons with the pre-Hunt
// historical record book in small time slices. Keep a bounded message summary.
let rl215HuntCutoff=null,rl215HuntReviewId=0;
const rl215OriginalStartHunt=rl212StartHunt;
rl212StartHunt=async function(){
 // Only fully completed, crowned seasons belong to the original benchmark.
 rl215HuntCutoff=db.seasons.filter(s=>latest(s)===s.weeks&&!!playoffChampion(s)).at(-1)?.id||0;
 return rl215OriginalStartHunt();
};
function rl215ReviewHunt(cutoff){
 if(cutoff===null)return;
 const current=++rl215HuntReviewId,old=db.seasons.filter(s=>s.id<=cutoff),newer=db.seasons.filter(s=>s.id>cutoff);
 if(!newer.some(s=>playoffChampion(s)))return;
 const data=rl215NewData();let i=0,phase='baseline',total=0,count=0,examples=[];
 function step(){
  if(current!==rl215HuntReviewId)return;
  try{
   const now=performance.now();let processed=0;
   while(performance.now()-now<12&&processed<32){
    if(phase==='baseline'){
     if(i>=old.length){phase='new';i=0;continue}
     const s=old[i++];if(latest(s)===s.weeks&&playoffChampion(s)&&RL215_FORMATS.includes(s.weeks))rl215ProcessSeason(data,s);
    }else{
     if(i>=newer.length){
      if(total){
       const node=document.createElement('div');node.className='record-toast rl215-record-notice';node.setAttribute('role','status');
       node.innerHTML=`<strong>🏆 Turbo Hunt record recap</strong><p>${total.toLocaleString()} record-breaking season or match metric${total===1?'':'s'} detected across ${newer.length.toLocaleString()} simulated seasons.</p>${examples.length?`<p>${examples.map(safe).join('<br>')}</p>`:''}<button onclick="this.parentElement.remove()">Dismiss</button>`;
       document.body.appendChild(node);setTimeout(()=>node.remove(),24000);
      }
      return;
     }
     const s=newer[i++];
     if(latest(s)===s.weeks&&playoffChampion(s)&&RL215_FORMATS.includes(s.weeks)){
      const block=data.formats[s.weeks],hadHistory=block.count>0;
      const before=Object.fromEntries(RL215_SEASON_RECORDS.map(def=>[def.key,block.records[def.key].value]));
      const combined=data.matches.combined.value,margin=data.matches.margin.value;
      rl215ProcessSeason(data,s);
      if(hadHistory)for(const def of RL215_SEASON_RECORDS){
       const next=block.records[def.key].value;
       if(def.minimum?next<before[def.key]:next>before[def.key]){
        total++;if(examples.length<6)examples.push(`${def.title}: ${next} (${seasonLabel(s.id)})`);
       }
      }
      for(const [kind,oldValue,newValue] of [['Highest-scoring match',combined,data.matches.combined.value],['Biggest winning margin',margin,data.matches.margin.value]]){
       if(Number.isFinite(oldValue)&&newValue>oldValue){total++;if(examples.length<6)examples.push(`${kind}: ${newValue} (${seasonLabel(s.id)})`)}
      }
     }
    }
    processed++;
   }
   setTimeout(step,0);
  }catch(e){console.error('Turbo Hunt record recap unavailable',e)}
 }
 setTimeout(step,0);
}
const rl215OriginalFinishHunt=rl213Finish;
rl213Finish=function(run,outcome){
 const cutoff=rl215HuntCutoff;rl215HuntCutoff=null;
 const result=rl215OriginalFinishHunt(run,outcome);
 if(cutoff!==null)rl215ReviewHunt(cutoff);
 return result;
};
