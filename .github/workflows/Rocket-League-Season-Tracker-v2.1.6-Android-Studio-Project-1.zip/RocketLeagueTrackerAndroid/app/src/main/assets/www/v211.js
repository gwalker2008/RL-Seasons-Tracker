'use strict';
/* v2.1.1 performance rescue. All persisted schema fields and scoring rules
   remain compatible with v2.1.0. No history is discarded. */

// Closed history panels do not pay the cost of rendering their full contents.
function rl211LoadCareerExtras(el){
 if(!el.open||el.dataset.loaded==='yes')return;
 const node=el.querySelector('.rl211-lazy-content');if(!node)return;
 node.innerHTML=rl212CareerExtraCards();el.dataset.loaded='yes';
}
function rl211CondenseRows(rows,renderItem,unit='entries'){
 if(rows.length<10)return rows.map(renderItem).join('');
 const first=rows.slice(0,5).map(renderItem).join('');
 return first+`<details class="rl211-more"><summary>Show all ${rows.length.toLocaleString()} ${safe(unit)}</summary><div class="rl211-history-scroll">${rows.slice(5).map(renderItem).join('')}</div></details>`;
}
function rl211TrophyYears(ids){
 const newest=ids.slice().sort((a,b)=>b-a);
 return rl211CondenseRows(newest,n=>`<span class="rl211-year">${safe(seasonLabel(n))}</span>`,'winning seasons');
}
function rl211CompactRecordHistory(value){
 const str=String(value||'');
 const bits=str.split(', ').filter(Boolean);
 if(bits.length<10)return safe(str);
 const recent=bits.slice(-5).reverse();
 return `<span class="rl211-recent-years">${safe(recent.join(', '))}</span> <details class="rl211-more"><summary>Show all ${bits.length.toLocaleString()} seasons</summary><span class="rl211-history-scroll">${safe(bits.slice().reverse().join(', '))}</span></details>`;
}
function rl211DevelopmentMarkup(player){
 // Avoid injecting thousands of <p> elements into a collapsed Stats card.
 const seq=player.history;
 const bySeason=new Map();
 for(const v of seq){
  let rec=bySeason.get(v.season);
  if(!rec){rec={matches:0,goals:0,assists:0,saves:0,shots:0};bySeason.set(v.season,rec)}
  rec.matches++;
  for(const k of ['goals','assists','saves','shots'])rec[k]+=v[k];
 }
 const rows=[...bySeason].sort((a,b)=>b[0]-a[0]);
 return rl211CondenseRows(rows,([id,rec])=>`<p>Season ${id} · ${rec.matches} matches · ${rec.goals} goals, ${rec.assists} assists, ${rec.saves} saves, ${rec.shots} shots</p>`,'seasons');
}

// Rarity histories remain fully available, but their DOM is built only when
// the player expands a rarity. Closed Godly/Mythic/Legendary/Major/Standard
// sections add almost no DOM nodes even after tens of thousands of seasons.
function rl211LoadRarity(el){
 if(!el.open||el.dataset.loaded==='yes')return;
 const tier=RL_TIERS.find(x=>x.toLowerCase()===el.dataset.tier),id=el.dataset.team;
 const team=rl210Data().team[id];if(!tier||!team)return;
 const byName=new Map();
 for(const e of team.events){
  if(e.tier!==tier||!rlMilestoneVisible(e))continue;
  if(!byName.has(e.title))byName.set(e.title,[]);
  byName.get(e.title).push(e);
 }
 const entries=[...byName].map(([title,history])=>({title,history:history.sort((a,b)=>b.season-a.season||b.week-a.week)}))
  .sort((a,b)=>b.history[0].season-a.history[0].season||b.history[0].week-a.history[0].week||a.title.localeCompare(b.title));
 const cards=entries.map(entry=>{
  const latest=entry.history[0],hist=rl211CondenseRows(entry.history,e=>`<div class="rl210-history-line"><span>Season ${e.season} · Week ${e.week}</span>${e.first?rl210FirstBadge(e.tier):''}</div>`,'occurrences');
  return `<details class="rl210-achievement"><summary><span class="rl210-achievement-main"><strong>${safe(entry.title)}</strong><small>Latest: Season ${latest.season} · Week ${latest.week}</small></span><span class="rl210-repeat">${entry.history.length}×</span>${entry.history.some(e=>e.first)?rl210FirstBadge(tier):''}</summary><div class="rl210-history"><strong>Earned history</strong>${hist}</div></details>`;
 }).join('');
 const node=el.querySelector('.rl210-rarity-content');if(!node)return;
 node.innerHTML=cards||'<p class="muted">Not earned yet.</p>';
 el.dataset.loaded='yes';
}
function rl211LoadDevelopment(el){
 if(!el.open||el.dataset.loaded==='yes')return;
 const p=rl212AllPlayerStats(rl212StatsScope).find(x=>x.id===el.dataset.playerId);
 const node=el.querySelector('.rl211-development-content');
 if(!p||!node)return;
 node.innerHTML=rl211DevelopmentMarkup(p);
 el.dataset.loaded='yes';
}

// A cached milestone aggregation is valid until results or awards change.
// In v2.1.0 every page render invalidated this cache (even tab navigation).
let rl211PlayerCache=null;
function rl211Invalidate(){rl211PlayerCache=null;rl211HuntEvidence=null}
const rl211BaseAllPlayerStats=rl212AllPlayerStats;
rl212AllPlayerStats=function(scope='season'){
 if(scope!=='career')return rl211BaseAllPlayerStats(scope);
 if(!rl211PlayerCache||rl211PlayerCache.db!==db){
  rl211PlayerCache={db,rows:rl211BaseAllPlayerStats('career')};
 }
 return rl211PlayerCache.rows;
};

// During a Hunt, identical historical evidence is updated incrementally.
// This implements the same 0.65 recency decay and season contribution formula
// as careerEvidence(), but without rescanning ~1,500 seasons every new year.
const rl211OriginalEvidence=careerEvidence;
let rl211HuntEvidence=null;
function rl211ContributionForSeason(s){
 const out={};
 const byTeam=stats(s,latest(s));
 for(const row of byTeam){
  const n=row.w+row.l;if(!n)continue;
  const weight=Math.min(1,n/18)*12;
  out[row.t]={w:weight*row.w/n,l:weight*row.l/n,gf:weight*row.gf/n,ga:weight*row.ga/n,n:weight};
 }
 return out;
}
function rl211InitialEvidence(s){
 const sum=Object.fromEntries(['Custom',...AI].map(t=>[t,{w:0,l:0,gf:0,ga:0,n:0}]));
 for(const old of db.seasons){
  if(old===s||Number(old.id)>=Number(s.id))continue;
  const decay=Math.pow(.65,Math.max(0,s.id-old.id-1));
  if(decay===0)continue;
  const contribution=rl211ContributionForSeason(old);
  for(const [t,x] of Object.entries(contribution)){
   const dst=sum[t];for(const k of ['w','l','gf','ga','n'])dst[k]+=decay*x[k];
  }
 }
 return sum;
}
careerEvidence=function(s){
 if(!rl212Hunt)return rl211OriginalEvidence(s);
 if(rl211HuntEvidence?.db===db&&rl211HuntEvidence.id===s.id)return rl211HuntEvidence.sum;
 if(rl211HuntEvidence?.db===db&&rl211HuntEvidence.id===s.id-1){
  const adjacent=db.seasons.at(-2);
  const prev=adjacent?.id===s.id-1?adjacent:db.seasons.find(x=>x.id===s.id-1);
  if(prev){
   const contribution=rl211ContributionForSeason(prev),sum={};
   for(const t of ['Custom',...AI]){
    const prior=rl211HuntEvidence.sum[t]||{w:0,l:0,gf:0,ga:0,n:0},extra=contribution[t]||{w:0,l:0,gf:0,ga:0,n:0};
    sum[t]={};for(const k of ['w','l','gf','ga','n'])sum[t][k]=.65*prior[k]+extra[k];
   }
   rl211HuntEvidence={db,id:s.id,sum};return sum;
  }
 }
 const sum=rl211InitialEvidence(s);rl211HuntEvidence={db,id:s.id,sum};return sum;
};

// Avoid rescanning completed seasons on every render; a finished season is
// immutable in the Hunt and season switches. Manual correction invalidates on persist.
const rl211BaseStats=stats;
const rl211FinishedStats=new WeakMap();
let rl211StatsVersion=0;
const rl211BaseInvalidate=rl211Invalidate;
rl211Invalidate=function(){rl211BaseInvalidate();rl211StatsVersion++};
stats=function(s,w){
 if(w<s.weeks||latest(s)!==s.weeks)return rl211BaseStats(s,w);
 const hit=rl211FinishedStats.get(s);
 if(hit&&hit.version===rl211StatsVersion)return hit.rows;
 const rows=rl211BaseStats(s,w);
 rl211FinishedStats.set(s,{version:rl211StatsVersion,rows});
 return rows;
};

// Streak decorations previously regenerated every one of ~272,000 historical
// matches for EACH team in a single Home-screen fixture list. Walk backwards
// instead and stop per team at its first loss. A weeks-long streak needs only
// weeks of work, even in a multi-thousand-season career.
let rl211StreakCache=null;
const rl211BaseStreakBefore=rlStreakBefore;
rlStreakBefore=function(s,w){
 const key=`${Number(s.id)}:${Number(w)}`;
 if(rl211StreakCache?.db===db&&rl211StreakCache.key===key)return rl211StreakCache.rows;
 const all=[...new Set(['Custom',...AI,...db.seasons.flatMap(x=>x.ai||[])])];
 const out=Object.fromEntries(all.map(t=>[t,0]));
 const unresolved=new Set(all);
 const sorted=db.seasons.slice().sort((a,b)=>a.id-b.id);
 for(let i=sorted.length-1;i>=0&&unresolved.size;i--){
  const old=sorted[i];if(Number(old.id)>Number(s.id))continue;
  const games=rlTimelineForSeason(old);
  for(let j=games.length-1;j>=0&&unresolved.size;j--){
   const g=games[j];if(Number(old.id)===Number(s.id)&&g.w>=w)continue;
   if(unresolved.has(g.a)){
    if(g.x>g.y)out[g.a]++;else unresolved.delete(g.a);
   }
   if(unresolved.has(g.b)){
    if(g.y>g.x)out[g.b]++;else unresolved.delete(g.b);
   }
  }
 }
 rl211StreakCache={db,key,rows:out};return out;
};
const rl211InvalidateBeforeStreak=rl211Invalidate;
rl211Invalidate=function(){rl211InvalidateBeforeStreak();rl211StreakCache=null};

// "Career milestones" in the Home news feed previously replayed every
// regular-season match TWICE every time the week was redrawn. Build small
// season-start checkpoints once and examine only the current week's fixtures.
let rl211MilestonePrefix=null;
const rl211BaseHomeMilestones=rlMilestones;
function rl211MilestoneAccumulator(into,g){
 for(const [t,goals,won] of [[g.a,g.x,g.x>g.y],[g.b,g.y,g.y>g.x]]){
  const rec=into[t]||(into[t]={goals:0,wins:0});
  rec.goals+=goals;rec.wins+=Number(won);
 }
}
function rl211CopyTotals(v){return Object.fromEntries(Object.entries(v).map(([t,r])=>[t,{goals:r.goals,wins:r.wins}]))}
function rl211BuildMilestonePrefix(){
 const before=new Map(),running={};
 for(const s of db.seasons.slice().sort((a,b)=>a.id-b.id)){
  before.set(Number(s.id),rl211CopyTotals(running));
  for(const g of analyticsGames(s,latest(s)))rl211MilestoneAccumulator(running,g);
 }
 rl211MilestonePrefix={db,count:db.seasons.length,last:db.seasons.at(-1)?.id,before};
}
rlMilestones=function(s,w){
 if(w<1||!complete(s,w))return '';
 if(!rl211MilestonePrefix||rl211MilestonePrefix.db!==db||
    rl211MilestonePrefix.count!==db.seasons.length||
    rl211MilestonePrefix.last!==db.seasons.at(-1)?.id)rl211BuildMilestonePrefix();
 const base=rl211MilestonePrefix.before.get(Number(s.id))||{};
 const before=rl211CopyTotals(base),after=rl211CopyTotals(base);
 for(const g of analyticsGames(s,w)){
  rl211MilestoneAccumulator(after,g);
  if(g.w<w)rl211MilestoneAccumulator(before,g);
 }
 const out=[];
 for(const [t,a] of Object.entries(after)){
  const b=before[t]||{goals:0,wins:0};
  for(const [key,unit,step] of [['wins','career wins',50],['goals','career goals',100]]){
   const n=Math.floor(a[key]/step)*step;
   if(n>=step&&b[key]<n)out.push(`${t==='Custom'?db.customName:t} reached ${n} ${unit}.`);
  }
 }
 return out.length?`<div class="notice"><strong>Career Milestones</strong>${out.map(x=>`<p>${safe(x)}</p>`).join('')}</div>`:'';
};
const rl211InvalidateBeforePrefix=rl211Invalidate;
rl211Invalidate=function(){rl211InvalidateBeforePrefix();rl211MilestonePrefix=null};

function rl211HuntGuard(){if(!rl212Hunt)return false;alert('Finish or stop the Hunt Simulator before changing your career. Your recorded seasons will be preserved.');return true}

// Browsing an old season is a view-state change, not a 14MB career edit.
// Persist the selection in a tiny cursor record, retaining it on reload.
function rl211SaveCursor(){
 try{localStorage.setItem('rl211_cursor_v1',JSON.stringify({id:season().id,count:db.seasons.length,last:db.seasons.at(-1)?.id}))}catch(e){}
}
function rl211LoadCursor(){
 try{
  const c=JSON.parse(localStorage.getItem('rl211_cursor_v1')||'null');
  if(c&&c.count===db.seasons.length&&c.last===db.seasons.at(-1)?.id){
   const idx=db.seasons.findIndex(s=>s.id===c.id);
   if(idx>=0)db.active=idx;
  }
 }catch(e){}
}
chooseSeason=function(){
 const idx=Number($('seasonPick').value);
 if(!Number.isInteger(idx)||idx<0||idx>=db.seasons.length)return;
 db.active=idx;selectedWeek=Math.min(selectedWeek,maxViewWeek(season()));
 rl211SaveCursor();render();
};
rlGoToMoment=function(id,w){
 const idx=db.seasons.findIndex(s=>s.id===id);if(idx<0)return;
 db.active=idx;selectedWeek=Math.min(w,maxViewWeek(season()));
 rl211SaveCursor();showPage('home');
};

// The Hunt retains the exact testScore, ratings, fixture and milestone logic.
// We change only how much work runs between UI yields, and save one completed
// season to the crash-safe IDB journal instead of stringifying the entire career.
let rl211HuntStarted=0,rl211HuntLastStatus=0;
const rl211BaseStartHunt=rl212StartHunt;
rl212StartHunt=function(){
 const prior=rl212Hunt;
 rl211BaseStartHunt();
 if(!prior&&rl212Hunt){rl211HuntStarted=performance.now();rl211HuntLastStatus=0;rl211HuntEvidence=null;rl211JournalFailed=false;}
};
function rl211HuntStep(){
 const h=rl212Hunt;if(!h)return false;
 if(rl211JournalFailed){rl212HuntFinish(false,null,'A season could not be saved. Export a backup.');return false}
 if(h.stopped&&playoffChampion(season())){rl212HuntFinish(false,null,'Cancelled by user after '+h.seasons+' completed seasons.');return false}
 let s=season();
 if(s!==db.seasons.at(-1)){db.active=db.seasons.length-1;s=season()}
 if(playoffChampion(s)){
  if(h.cap!=='unlimited'&&h.seasons>=h.cap){rl212HuntFinish(false,null,'Safety cap reached after '+h.seasons+' seasons without a qualifying rarity.');return false}
  s=rl212HuntNewSeason(s);h.mythicThisSeason=false;h.history=null;
 }
 if(!h.history)h.history=careerEvidence(s);
 if(latest(s)<s.weeks){
  const w=latest(s)+1,ratings=rl212HuntStrength(s,w-1,h.history);
  const scores=fixtures(s,w).map(([a,b])=>testScore(a,b,ratings));
  s.results[w]=scores;rl212AssignPlayerStats(s,w);
  fixtures(s,w).forEach(([a,b],i)=>rl212HuntTrackMatch(h,a,b,...scores[i]));
 }else{
  let guard=0;
  while(!playoffChampion(s)&&guard++<8){
   const rounds=playoffRounds(s);let pending=null;
   for(let r=0;r<rounds.length&&!pending;r++)for(let i=0;i<rounds[r].matches.length;i++){
    const m=rounds[r].matches[i];if(m.a&&m.b&&!m.winner){pending={r,i,m};break}
   }
   if(!pending)break;
   const {r,i,m}=pending,score=testScore(m.a,m.b,rl212HuntStrength(s,s.weeks,h.history));
   s.playoffs ||= [];s.playoffs[r] ||= [];s.playoffs[r][i]={a:m.a,b:m.b,score};
   rl212HuntTrackMatch(h,m.a,m.b,...score);
   rl212AssignPlayoffStats(s,s.weeks+r+1,score,m);
  }
  s.champion=playoffChampion(s);
  if(!s.champion){rl212HuntFinish(false,null,'Playoff bracket could not be completed.');return false}
  h.seasons++;
  const found=rl212HuntSeasonRarities(h,s);
  const qualifies=(found.includes('Godly')&&(h.target==='Godly'||h.target==='either'))||
                  (found.includes('Mythic')&&(h.target==='Mythic'||h.target==='either'));
  if(qualifies&&!h.stopped){db.active=db.seasons.length-1;rl212HuntFinish(true,found.includes('Godly')?'Godly':'Mythic');return false}
  // One tiny, atomic season write instead of 14 MB full-career serialization.
  if(!rl211JournalSeason(s)&&!persist()){
   rl212HuntFinish(false,null,'Browser storage limit reached. Export a backup.');return false;
  }
  // Checkpoint occasionally so an unlimited Hunt never needs thousands of
  // separately replayed journal records. This is one full snapshot per 100
  // completed seasons, not one per season as in v2.1.0.
  if(h.seasons%100===0&&rl212DbHandle){
   try{rl212QueueWrite(JSON.stringify(db),s.id)}
   catch(e){console.warn('Hunt checkpoint deferred',e)}
  }
  h.history=null;h.mythicThisSeason=false;
  if(h.stopped){rl212HuntFinish(false,null,'Cancelled by user after '+h.seasons+' completed seasons.');return false}
  if(h.cap!=='unlimited'&&h.seasons>=h.cap){rl212HuntFinish(false,null,'Safety cap reached after '+h.seasons+' seasons without a qualifying rarity.');return false}
 }
 return true;
}
rl212HuntTick=function(){
 const h=rl212Hunt;if(!h)return;
 if(rl211JournalPending>=3){setTimeout(rl212HuntTick,12);return}
 try{
  const started=performance.now();let count=0;
  do{
   if(!rl211HuntStep())return;
   count++;
  }while(rl212Hunt&&count<22&&performance.now()-started<22);
  const now=performance.now();
  if(currentPage==='settings'&&(now-rl211HuntLastStatus>350)){
   const elapsed=Math.max(.001,(now-rl211HuntStarted)/1000),speed=h.seasons/elapsed;
   rl212HuntStatus(`Season ${season().id} · ${h.seasons.toLocaleString()} completed${h.cap==='unlimited'?'':` / ${h.cap}`} · ${speed.toFixed(1)} seasons/sec · rarity remains secret`);
   rl211HuntLastStatus=now;
  }
  setTimeout(rl212HuntTick,0);
 }catch(e){console.error('Fast Hunt error',e);rl212HuntFinish(false,null,'Hunt stopped due to an error: '+e.message)}
};
