// v0.8.3: adapted from the earlier Python Monte Carlo approach.
// Neutral teams on a fresh career; historical results form priors for later seasons.
self.onmessage=e=>{
const {teams,games,baseline,w,runs,playoffCount=6,history={}}=e.data;
const counts=Object.fromEntries(teams.map(t=>[t,{title:0,top6:0,champ:0,bye:0,final:0,seeds:Array(playoffCount).fill(0)}]));
const prior=Object.fromEntries(baseline.map(x=>[x.t,x]));
const future=games.filter(g=>g.w>w);
const sigmoid=x=>1/(1+Math.exp(-x));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const power={},attack={},defense={};
for(const t of teams){
 const x=prior[t],h=history[t]||{w:0,l:0,gf:0,ga:0,n:0},n=x.w+x.l;
 // Historical evidence counts as at most 12 effective matches per previous season.
 // Neutral prior of 20 games: a brand-new save has identical starting ability.
 const hw=h.w||0,hl=h.l||0;
 const historical=(hw+10)/(hw+hl+20);
 const current=(x.w+10)/(n+20);
 const blend=clamp(n/(n+18),0,.82);
 const p=(1-blend)*historical+blend*current;
 const form=(x.form||[]).slice(-5).reduce((v,r)=>v+(r==='W'?1:-1),0)/5;
 power[t]=Math.log(p/(1-p))+.10*form*blend;
 // Goals per match regularized strongly toward neutral 2.4 for early weeks.
 const weight=Math.min(10,h.n||0);
 attack[t]=Math.log((x.gf+(h.n?h.gf/(h.n)*weight:0)+2.4*12)/(n+weight+12)/2.4);
 defense[t]=Math.log((x.ga+(h.n?h.ga/(h.n)*weight:0)+2.4*12)/(n+weight+12)/2.4);
}
function chance(a,b,latent){return clamp(sigmoid((power[a]-power[b])*.85+(latent[a]-latent[b])),.07,.93)}
function poisson(mean){let L=Math.exp(-mean),p=1,k=0;do{k++;p*=Math.random()}while(p>L&&k<30);return k-1}
function play(a,b,st,latent){
 const diff=power[a]-power[b]+latent[a]-latent[b];
 const ma=clamp(2.4*Math.exp(.20*diff+.17*(attack[a]-defense[b])),.65,5.4);
 const mb=clamp(2.4*Math.exp(-.20*diff+.17*(attack[b]-defense[a])),.65,5.4);
 let ga=poisson(ma),gb=poisson(mb);
 if(ga===gb){if(Math.random()<chance(a,b,latent))ga++;else gb++}
 const A=st[a],B=st[b];A.gf+=ga;A.ga+=gb;B.gf+=gb;B.ga+=ga;
 if(ga>gb)A.w++;else B.w++;
}
function winner(a,b,latent){return Math.random()<chance(a,b,latent)?a:b}
for(let iter=0;iter<runs;iter++){
 const st=Object.fromEntries(teams.map(t=>{const x=prior[t];return[t,{t,w:x.w,gf:x.gf,ga:x.ga}]}));
 const latent=Object.fromEntries(teams.map(t=>[t,(Math.random()+Math.random()+Math.random()-1.5)*.12]));
 let lastWeek=w;
 for(const g of future){
  if(g.w!==lastWeek){
   // Modest, persistent performance drift, allowing teams to improve or slump.
   for(const t of teams)latent[t]=clamp(.94*latent[t]+(Math.random()+Math.random()+Math.random()-1.5)*.06,-.45,.45);
   lastWeek=g.w;
  }
  play(g.a,g.b,st,latent);
 }
 const sorted=Object.values(st).sort((a,b)=>b.w-a.w||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||a.t.localeCompare(b.t));
 counts[sorted[0].t].title++;
 for(let i=0;i<playoffCount;i++){counts[sorted[i].t].top6++;counts[sorted[i].t].seeds[i]++}
 for(let i=0;i<2;i++)counts[sorted[i].t].bye++;
 let sf1,sf2;
 if(playoffCount===4){sf1=winner(sorted[0].t,sorted[3].t,latent);sf2=winner(sorted[1].t,sorted[2].t,latent)}
 else{const q1=winner(sorted[2].t,sorted[5].t,latent),q2=winner(sorted[3].t,sorted[4].t,latent);sf1=winner(sorted[0].t,q2,latent);sf2=winner(sorted[1].t,q1,latent)}
 counts[sf1].final++;counts[sf2].final++;counts[winner(sf1,sf2,latent)].champ++;
 if(iter%10000===9999)postMessage({progress:iter+1});
}
postMessage({done:true,modelVersion:4,rows:teams.map(t=>({t,...Object.fromEntries(Object.entries(counts[t]).map(([k,v])=>[k,Array.isArray(v)?v.map(x=>100*x/runs):100*v/runs]))}))});
};
