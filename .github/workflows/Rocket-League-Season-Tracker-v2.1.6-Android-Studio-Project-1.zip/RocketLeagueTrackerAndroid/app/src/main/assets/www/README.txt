LATEST: v2.1.6 — Ceremony & Mobile Record Book Hotfix.
See RELEASE-NOTES-v2.1.6.txt for changes and TEST-REPORT-v2.1.6.txt
for verification. Export a JSON backup before deploying. Do not clear site
storage, change the Cloudflare Pages domain, or move any original asset paths.

COMPLETE CLOUDFLARE PAGES FLAT-ROOT WEBSITE
1. The ZIP contains the entire website, not a patch.
2. Extract and upload ALL enclosed contents to the root of the SAME site.
   Keep index.html, all *.js files, manifest.json, icons/, badges/ and
   team-logos/ in their original relative locations.
3. Do NOT clear browser data or uninstall the existing PWA.
4. Reopen the site or reload after deployment to update the service worker.
5. Store a verified JSON career backup outside the browser before uploading.

PREVIOUSLY ADDED IN v2.1.4
- Career Record Book is visible directly on the Career tab, not in a collapsed
  "Additional Historical Records" section or a click-to-calculate placeholder.
- Featured career records: Championships, Career Goals, Best Winning Streak,
  Clean Sheets. Four cards (2 x 2), followed by six compact historical rows.
- Season records: 2 rows x 3 cards, on mobile and desktop.
  Row 1: Most Wins | Most Goals | Fewest Conceded
  Row 2: Most Losses | Least Goals | Most Conceded
- The six cards display data for the CURRENTLY SELECTED season's 9-, 18-, 27-
  or 36-week format, automatically. Records from other formats are preserved.
- Every tied record holder keeps all qualifying seasons. Holders are grouped by
  team, then season number (chronological). Team logos appear beside names.
  Long tie lists expand within the card; the main record book stays visible.
- Uses Settings > Career Records Display > Compact or Full season numbering.
  Compact: S1234, S1235. Full: Season 1234, Season 1235.
- Season statistics include regular-season matches only, no playoff games.
  Career match and cumulative records include completed playoff matches.
- Official career records update only after a COMPLETE season and playoffs,
  once the next preseason has begun. Historical views exclude future seasons.
- Live record announcements detect new/equalled records during the season,
  including high-scoring matches and biggest winning margins. A saved season's
  improved final figure appears once in the official book in the next preseason.
- Turbo Hunter uses a non-interrupting, end-of-Hunt summary of broken records;
  calculations are performed in time slices after the Hunt stops.
- Leaderboard medals stay beside names. A separate STREAK badge retains the
  original emoji flame artwork and all nine v2.1.3 winning-streak colours.
- Corrects bogus zero values for highest combined-score match and greatest
  winning margin when real saved results are available. Missing data is shown
  as unavailable rather than treated as an achieved record.
- Historical calculations are incremental and time-sliced; they do not build
  one giant intermediate array of all career matches.

PRESERVED
All v2.1.3 milestones, historical ceremony replays, nine flame tiers,
existing match and playoff rules, Turbo Hunter, stats, season archive,
custom team, existing logos, offline support and JSON career format.
No rivalries were added back. Android APK is NOT part of this release.

NOTES / IMPORTANT LIMITATIONS
- This build was tested in a JavaScript runtime with the supplied 10- and
  1,511-season career files. It has NOT been browser-tested on Samsung Internet,
  nor with an actual 18,467-season backup.
- Very large career backups, IndexedDB quotas and mobile browser tab crashes
  are hardware/browser-dependent; this build does not guarantee those issues
  are fully resolved. Keep reliable external JSON backups.
- The previous v2.1.3 native emoji flames are preserved. Their recolouring may
  vary across operating systems because emoji glyphs are system-rendered.
- If a season's results or playoff history were not saved, unavailable match
  details cannot be reliably invented.
