/* v2.0.12: load the large-career IndexedDB copy before showing the website.
   Existing v2.0.11 JSON/localStorage saves remain fully supported. */
(async function rlStart(){
 try {
  const stored=typeof rl212LoadDatabase==='function'?await rl212LoadDatabase():null;
  if(stored)db=stored;
  if(hadSave||!!stored){
   db.seasons.forEach(initSeason);
   rlRecalculateHistoricalMatches.updatedCount=rlRecalculateHistoricalMatches();
   rl211LoadCursor();
   db.active=Math.max(0,Math.min(Number(db.active)||0,db.seasons.length-1));
   selectedWeek=Math.max(0,Math.min(db.seasons[db.active].weeks,latest(db.seasons[db.active])+1));
   if(!stored||rlRecalculateHistoricalMatches.updatedCount>0)persist();closeWizard();render();
  }else{
   openMenu();
   if(saveLoadError){
    const warning=document.createElement('p');warning.className='notice';
    warning.textContent='A previous save could not be loaded. Do not start a new career until you check your JSON backup or browser storage.';
    $('wizard').prepend(warning);
   }
  }
 }catch(error){
  console.error('Tracker startup failed:',error);
  const warning=document.createElement('div');warning.className='panel notice';warning.setAttribute('role','alert');
  warning.textContent='Unable to display the career. Your saved data has not been deleted. Export your JSON backup if possible, then reload. Error: '+(error?.message||error);
  document.body.prepend(warning);
 }
 if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();
