ROCKET LEAGUE SEASON TRACKER v2.1.6 — ANDROID APP PROJECT

This is an Android Studio project containing the complete v2.1.6 tracker website bundled locally inside an Android WebView app. It is designed to run offline and keep its data in the app's own browser storage. It is NOT a Trusted Web Activity and does not require a public website or Digital Asset Links.

BUILD AN APK (Windows)
1. Install Android Studio (current stable) and allow it to install Android SDK Platform 35 and Android SDK Build-Tools.
2. Open the folder named RocketLeagueTrackerAndroid in Android Studio.
3. Allow Gradle sync and accept any Android SDK licence prompts. Use JDK 17 (Android Studio's bundled JBR is suitable).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location, normally app/build/outputs/apk/debug/app-debug.apk.
6. Copy that APK to your Android phone and install it. If prompted, allow installation from that file manager.

COMMAND LINE (after Android Studio has installed SDK + Gradle)
From this project folder run: gradle assembleDebug
The APK is app/build/outputs/apk/debug/app-debug.apk.

IMPORTANT
- Export your career JSON from the current browser-based tracker before switching. Browser/PWA storage and this Android app's storage are separate; use the tracker's JSON export/import to move your career.
- The APK contains a bundled copy of v2.1.6. Website updates do not automatically update the APK; rebuild a new APK when the tracker changes.
- The app uses WebViewAssetLoader's HTTPS-like local origin so IndexedDB, Web Workers and the service worker can use a secure origin. Actual device testing is still required, especially offline startup, import/export, worker simulations and large career saves.
- The first Gradle build needs internet access to download Android Gradle Plugin and AndroidX dependencies. The finished app itself is bundled for offline use.
- This project is an unsigned/debug build recipe. For distribution, create and securely retain your own release signing key in Android Studio. Never share the keystore or passwords.
